/* ============================================================
   v6-enterprise.js — Compliance, KPI, Heatmap, Media Kit
   ============================================================ */
(function(){
'use strict';

const $ = id => document.getElementById(id);
const lsGet = (k,fb) => { try{ const r=localStorage.getItem(k); return r==null?fb:JSON.parse(r); }catch(e){ return fb; } };
const lsSet = (k,v) => { try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} };
const toBn = n => String(n||0).replace(/[0-9]/g, d => '০১২৩৪৫৬৭৮৯'[+d]);
const esc = s => String(s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const toast = (m,t) => { if(typeof window.toast === 'function') window.toast(m,t); };

const KEYS = {
  AUDIT: 'auditLog',
  CONSENT: 'consentVersion',
  CONSENT_USER: 'userConsent',
  QUEUE: 'syncQueue',
  ENC_KEY: 'cryptoKey'
};

/* ═══════════════════════════════════════════════════════════
   §১. AES-256-GCM ENCRYPTION (Web Crypto)
   ═══════════════════════════════════════════════════════════ */
const Crypto = (function(){
  let keyPromise = null;
  async function getKey(){
    if(keyPromise) return keyPromise;
    keyPromise = (async () => {
      let raw = lsGet(KEYS.ENC_KEY, null);
      if(!raw){
        const bytes = crypto.getRandomValues(new Uint8Array(32));
        raw = Array.from(bytes);
        lsSet(KEYS.ENC_KEY, raw);
      }
      const keyBytes = new Uint8Array(raw);
      return crypto.subtle.importKey('raw', keyBytes, {name:'AES-GCM'}, false, ['encrypt','decrypt']);
    })();
    return keyPromise;
  }
  async function encrypt(plain){
    if(!plain) return plain;
    try{
      const key = await getKey();
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const enc = new TextEncoder().encode(String(plain));
      const cipher = await crypto.subtle.encrypt({name:'AES-GCM', iv}, key, enc);
      return 'enc:' + btoa(String.fromCharCode(...iv)) + ':' +
             btoa(String.fromCharCode(...new Uint8Array(cipher)));
    }catch(e){ return plain; }
  }
  async function decrypt(str){
    if(!str || typeof str !== 'string' || !str.startsWith('enc:')) return str;
    try{
      const parts = str.split(':');
      const iv = Uint8Array.from(atob(parts[1]), c=>c.charCodeAt(0));
      const data = Uint8Array.from(atob(parts[2]), c=>c.charCodeAt(0));
      const key = await getKey();
      const dec = await crypto.subtle.decrypt({name:'AES-GCM', iv}, key, data);
      return new TextDecoder().decode(dec);
    }catch(e){ return ''; }
  }
  return { encrypt, decrypt };
})();

/* ═══════════════════════════════════════════════════════════
   §২. AUDIT LOG
   ═══════════════════════════════════════════════════════════ */
const Audit = (function(){
  const MAX = 200;
  function log(action, target, note, severity){
    const entry = { id:'a'+Date.now()+Math.random().toString(36).slice(2,6), at:Date.now(), actor:'system', action, target:target||'', note:note||'', severity:severity||'info' };
    const arr = lsGet(KEYS.AUDIT, []);
    arr.unshift(entry);
    if(arr.length > MAX) arr.length = MAX;
    lsSet(KEYS.AUDIT, arr);
    if(window.FIREBASE_ENABLED && window.firebase){
      try{ firebase.firestore().collection('auditLog').add(entry); }catch(e){}
    }
    return entry;
  }
  function all(){ return lsGet(KEYS.AUDIT, []); }
  function clear(){ lsSet(KEYS.AUDIT, []); }
  return { log, all, clear };
})();

/* ═══════════════════════════════════════════════════════════
   §৩. CONSENT TRACKING
   ═══════════════════════════════════════════════════════════ */
const CONSENT_VERSION = '2025-01-v1';
const CONSENT_ITEMS = [
  'আমার নাম, ফোন নম্বর ও এলাকা রক্তদানের প্রয়োজনে অন্য ব্যবহারকারীদের দেখতে দিতে সম্মত।',
  'শুধু রক্তদান সংক্রান্ত যোগাযোগের জন্য আমার ফোন ব্যবহার করা হবে।',
  'আমি নিশ্চিত করছি আমার দেওয়া তথ্য সঠিক ও সত্য।',
  'আমি জানি যেকোনো সময় অ্যাকাউন্ট ডিলিট করতে পারব।'
];
function needsConsent(){
  const saved = lsGet(KEYS.CONSENT_USER, null);
  return !saved || saved.version !== CONSENT_VERSION;
}
function showConsent(){
  if(!needsConsent()) return false;
  const html = '<div class="mhdr"><div class="mt">✅ সম্মতি প্রয়োজন</div></div>' +
    '<div class="consent-modal">' +
      '<h3>শর্তাবলী আপডেট</h3>' +
      '<div class="ver">সংস্করণ ' + CONSENT_VERSION + '</div>' +
      '<p style="font-size:12.5px;color:var(--text2);line-height:1.6">চালিয়ে যেতে নিচের শর্তে সম্মতি দিন:</p>' +
      '<ul>' + CONSENT_ITEMS.map(t => '<li>' + t + '</li>').join('') + '</ul>' +
      '<div class="accept-row"><input type="checkbox" id="v6ConsentChk"><label for="v6ConsentChk" style="font-size:12.5px;line-height:1.5">আমি সব শর্ত পড়েছি এবং সম্মতি দিচ্ছি</label></div>' +
      '<button class="btn btn-p" onclick="v6AcceptConsent()">✅ সম্মতি দিন</button>' +
      '<button class="btn btn-gh" style="margin-top:8px" onclick="closeModal()">❌ এখন না</button>' +
    '</div>';
  if(typeof window.openModal === 'function') window.openModal(html);
  return true;
}
window.v6AcceptConsent = function(){
  const chk = $('v6ConsentChk');
  if(!chk || !chk.checked){ toast('চেকবক্সে টিক দিন','error'); return; }
  lsSet(KEYS.CONSENT_USER, { version: CONSENT_VERSION, acceptedAt: Date.now() });
  Audit.log('CONSENT_ACCEPTED', 'user', CONSENT_VERSION);
  if(typeof closeModal === 'function') closeModal();
  toast('✅ ধন্যবাদ!','success');
};

/* ═══════════════════════════════════════════════════════════
   §৪. OFFLINE SYNC QUEUE
   ═══════════════════════════════════════════════════════════ */
const Queue = (function(){
  function enqueue(action){
    const arr = lsGet(KEYS.QUEUE, []);
    action.id = 'q' + Date.now() + Math.random().toString(36).slice(2,6);
    action.queuedAt = Date.now();
    arr.push(action);
    if(arr.length > 100) arr.shift();
    lsSet(KEYS.QUEUE, arr);
    return action.id;
  }
  function size(){ return lsGet(KEYS.QUEUE, []).length; }
  function clear(){ lsSet(KEYS.QUEUE, []); }
  return { enqueue, size, clear };
})();

/* ═══════════════════════════════════════════════════════════
   §৫. KPI COMPUTE
   ═══════════════════════════════════════════════════════════ */
function computeKPIs(){
  const donors = window.donors || [];
  const reqs = window.requests || [];
  const now = Date.now();
  const verified = donors.filter(d => d.verified).length;
  const active30 = donors.filter(d => (d.lastDonation && (now - new Date(d.lastDonation).getTime()) < 90*86400000)).length;
  const completed = reqs.filter(r => r.status === 'completed').length;
  const fulfillRate = reqs.length ? Math.round((completed / reqs.length) * 100) : 0;
  const retained = donors.filter(d => (d.donations||0) >= 1).length;
  const retentionRate = donors.length ? Math.round((retained / donors.length) * 100) : 0;
  const new30 = donors.filter(d => d.createdAt && (now - d.createdAt) < 30*86400000).length;
  return {
    totalDonors: donors.length,
    verified, verifiedPct: donors.length ? Math.round((verified/donors.length)*100) : 0,
    active30,
    totalRequests: reqs.length,
    completed, fulfillRate,
    avgResponseMin: null,
    retentionRate,
    new30
  };
}

window.v6RenderKPI = function(){
  const c = $('v6KpiRoot'); if(!c) return;
  const k = computeKPIs();
  const bn = toBn;
  c.innerHTML =
    '<div class="kpi-grid">' +
      '<div class="kpi-card g"><div class="kpi-val g">' + bn(k.fulfillRate) + '%</div><div class="kpi-lbl">Fulfillment Rate</div></div>' +
      '<div class="kpi-card b"><div class="kpi-val b">' + bn(k.verifiedPct) + '%</div><div class="kpi-lbl">Verified Donors</div></div>' +
      '<div class="kpi-card"><div class="kpi-val">' + bn(k.retentionRate) + '%</div><div class="kpi-lbl">Donor Retention</div></div>' +
      '<div class="kpi-card a"><div class="kpi-val a">+' + bn(k.new30) + '</div><div class="kpi-lbl">নতুন (৩০ দিন)</div></div>' +
      '<div class="kpi-card"><div class="kpi-val">' + bn(k.active30) + '</div><div class="kpi-lbl">Active (৯০ দিন)</div></div>' +
      '<div class="kpi-card g"><div class="kpi-val g">' + bn(k.completed) + '</div><div class="kpi-lbl">সম্পন্ন দান</div></div>' +
    '</div>';
};

/* ═══════════════════════════════════════════════════════════
   §৬. HEATMAP
   ═══════════════════════════════════════════════════════════ */
window.v6RenderHeatmap = function(){
  const c = $('v6HeatmapRoot'); if(!c) return;
  const donors = window.donors || [];
  const reqs = window.requests || [];
  const districts = {};
  (window.DISTRICTS ? Object.keys(window.DISTRICTS) : []).forEach(d => {
    districts[d] = { name: d, donors: 0, requests: 0 };
  });
  donors.forEach(d => {
    if(!districts[d.district]) districts[d.district] = { name: d.district, donors: 0, requests: 0 };
    districts[d.district].donors++;
  });
  reqs.forEach(r => {
    if(districts[r.district]) districts[r.district].requests++;
  });
  const list = Object.values(districts).map(d => {
    const ratio = d.donors ? d.requests / d.donors : 0;
    let level = 'lo';
    if(ratio > 0.5 || d.requests >= 3) level = 'hi';
    else if(ratio > 0.15 || d.requests >= 1) level = 'md';
    return Object.assign({}, d, { ratio, level });
  }).sort((a,b) => b.ratio - a.ratio);

  const maxD = Math.max(1, ...list.map(l => l.donors));
  c.innerHTML =
    '<div class="chart-box"><h4>🗺️ জেলা-ভিত্তিক চাহিদা হিটম্যাপ</h4>' +
    '<div class="heatmap-grid">' +
    list.map(d =>
      '<div class="heat-cell">' +
        '<span class="level ' + d.level + '"></span>' +
        '<div class="name">📍 ' + esc(d.name) + '</div>' +
        '<div class="bar"><div class="fill" style="width:' + (d.donors/maxD)*100 + '%;background:linear-gradient(90deg,#C62828,#8E0000)"></div></div>' +
        '<div class="nums"><span>👥 ' + toBn(d.donors) + '</span><span>🩸 ' + toBn(d.requests) + '</span></div>' +
      '</div>'
    ).join('') +
    '</div></div>';
};

/* ═══════════════════════════════════════════════════════════
   §৭. AUDIT LOG UI
   ═══════════════════════════════════════════════════════════ */
window.v6RenderAudit = function(){
  const c = $('v6AuditRoot'); if(!c) return;
  const logs = Audit.all();
  if(!logs.length){
    c.innerHTML = '<div class="empty"><div class="empty-ic">📝</div><div class="empty-t">কোনো অডিট এন্ট্রি নেই</div></div>';
    return;
  }
  const icons = { VERIFY_DONOR:'✔', SUSPEND_DONOR:'🚫', COMPLETE_REQUEST:'✅', APPROVE_HOSPITAL:'🏥', RESOLVE_REPORT:'🚩', CONSENT_ACCEPTED:'✅', ADMIN_LOGIN:'🔓', ADMIN_LOGOUT:'🚪' };
  c.innerHTML = logs.slice(0, 100).map(l =>
    '<div class="audit-row ' + (l.severity === 'warn' ? 'warn' : l.severity === 'danger' ? 'danger' : '') + '">' +
      '<span class="ic">' + (icons[l.action] || '📋') + '</span>' +
      '<div class="body"><b>' + esc(l.action) + '</b><span>' + esc(l.target||'') + (l.note ? ' · ' + esc(l.note) : '') + '</span></div>' +
      '<span class="time">' + new Date(l.at).toLocaleString('bn-BD') + '</span>' +
    '</div>'
  ).join('');
};

/* ═══════════════════════════════════════════════════════════
   §৮. MEDIA KIT PAGE
   ═══════════════════════════════════════════════════════════ */
window.v6RenderMediaKit = function(){
  const c = $('screen-media-kit'); if(!c) return;
  const k = computeKPIs();
  c.innerHTML =
    '<div class="st"><span class="em">📰</span> প্রেস ও মিডিয়া কিট</div>' +

    '<div class="mediakit-hero">' +
      '<h2>বরিশাল রক্তদাতা</h2>' +
      '<p>বাংলাদেশের বরিশাল বিভাগের ৬ জেলার সবচেয়ে আধুনিক রক্তদান নেটওয়ার্ক। প্রযুক্তি দিয়ে জীবন বাঁচানোর উদ্যোগ।</p>' +
    '</div>' +

    '<div class="partnership-wall">' +
      '<span class="partnership-badge gov">🏛️ DGHS অনুসরণকারী</span>' +
      '<span class="partnership-badge ngo">🤝 কমিউনিটি পার্টনার</span>' +
      '<span class="partnership-badge med">🏥 হাসপাতাল নেটওয়ার্ক</span>' +
    '</div>' +

    '<div class="mediakit-stats">' +
      '<div class="mediakit-stat"><div class="n">' + toBn(k.totalDonors) + '</div><div class="l">ডোনার</div></div>' +
      '<div class="mediakit-stat"><div class="n">' + toBn(k.verifiedPct) + '%</div><div class="l">Verified</div></div>' +
      '<div class="mediakit-stat"><div class="n">' + toBn(k.fulfillRate) + '%</div><div class="l">Success</div></div>' +
      '<div class="mediakit-stat"><div class="n">' + toBn(k.totalRequests) + '</div><div class="l">মোট অনুরোধ</div></div>' +
      '<div class="mediakit-stat"><div class="n">' + toBn(k.completed) + '</div><div class="l">সম্পন্ন</div></div>' +
      '<div class="mediakit-stat"><div class="n">' + toBn(k.new30) + '</div><div class="l">নতুন (৩০ দিন)</div></div>' +
    '</div>' +

    '<div class="press-block">' +
      '<h4>📄 আমাদের সম্পর্কে</h4>' +
      '<p>বরিশাল রক্তদাতা একটি অলাভজনক কমিউনিটি উদ্যোগ, যা DGHS Safe Blood Transfusion Act 2002 মেনে চলে। আমরা স্বেচ্ছাসেবী রক্তদাতাদের জরুরি প্রয়োজনে রোগীর সাথে সরাসরি সংযুক্ত করি। GPS-ভিত্তিক ম্যাচিং, AI স্কোরিং ও রিয়েল-টাইম নোটিফিকেশন — সবই ফ্রিতে।</p>' +
    '</div>' +

    '<div class="press-block">' +
      '<h4>📦 প্রেস কিট (Downloads)</h4>' +
      '<p>সাংবাদিকদের জন্য প্রস্তুত মিডিয়া অ্যাসেট:</p>' +
      '<div class="assets">' +
        '<button onclick="v6DownloadAsset(\'logo\')">🩸 লোগো (SVG)</button>' +
        '<button onclick="v6DownloadAsset(\'factsheet\')">📄 ফ্যাক্ট শিট</button>' +
        '<button onclick="v6DownloadAsset(\'brandcolors\')">🎨 ব্র্যান্ড গাইড</button>' +
      '</div>' +
    '</div>' +

    '<div class="press-block">' +
      '<h4>🎙️ কথা বলতে চান?</h4>' +
      '<div class="press-contact">' +
        '<p style="margin-bottom:8px"><b>প্রেস ইনকোয়ারি:</b><br>📧 press@barishalrokto.org<br>📞 +880 1700-000000<br>📍 বরিশাল, বাংলাদেশ</p>' +
      '</div>' +
    '</div>' +

    '<div class="press-block">' +
      '<h4>📊 ইমপ্যাক্ট ডেটা (লাইভ)</h4>' +
      '<div style="font-size:12.5px;line-height:1.9;color:var(--text2)">' +
        '• মোট ডোনার: <b>' + toBn(k.totalDonors) + '</b><br>' +
        '• সফল রক্তদান: <b>' + toBn(k.completed) + '</b><br>' +
        '• আনুমানিক জীবন রক্ষা: <b>' + toBn(Math.floor(k.completed * 1.5)) + '</b><br>' +
        '• সক্রিয় ইউজার (৯০ দিন): <b>' + toBn(k.active30) + '</b>' +
      '</div>' +
    '</div>';
};

window.v6DownloadAsset = function(type){
  const assets = {
    logo: { name:'logo.svg', content:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" rx="20" fill="#C62828"/><path d="M50 20 Q50 20 60 45 Q70 65 50 78 Q30 65 40 45 Z" fill="#fff"/></svg>' },
    factsheet: { name:'factsheet.txt', content:'বরিশাল রক্তদাতা\n==================\n\n৬ জেলা, ৪১ উপজেলা\nDGHS Safe Blood Transfusion Act 2002 অনুসরণকারী\n\nযোগাযোগ: press@barishalrokto.org\n' },
    brandcolors: { name:'brand-colors.txt', content:'প্রাইমারি: #C62828\nডার্ক: #8E0000\nলাইট: #FFEBEE\nসাকসেস: #2E7D32\nফন্ট: Hind Siliguri' }
  };
  const a = assets[type]; if(!a) return;
  const blob = new Blob([a.content], {type:'text/plain'});
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = a.name; link.click();
  URL.revokeObjectURL(url);
  toast('📥 ডাউনলোড শুরু','success');
};

/* ═══════════════════════════════════════════════════════════
   §৯. INTEGRATION STATUS
   ═══════════════════════════════════════════════════════════ */
window.v6RenderIntegrations = function(){
  const c = $('v6IntegrationsRoot'); if(!c) return;
  const integrations = [
    { name:'bKash Payment', desc:'Donation/fundraising', logo:'💳', cls:'bkash', status:'pending' },
    { name:'Nagad Payment', desc:'বিকল্প পেমেন্ট', logo:'💳', cls:'nagad', status:'pending' },
    { name:'WhatsApp Business', desc:'Broadcast', logo:'💬', cls:'wa', status:'pending' },
    { name:'NID Verification', desc:'পরিচয় যাচাই', logo:'🆔', cls:'nid', status:'pending' },
    { name:'DGHS Blood Bank', desc:'সরকারি সিঙ্ক', logo:'🏥', cls:'', status:'off' }
  ];
  const statusMap = { ready:'✅ সক্রিয়', pending:'⏳ কনফিগার', off:'⚪ বন্ধ' };
  c.innerHTML = integrations.map(i =>
    '<div class="integration-card">' +
      '<div class="logo ' + i.cls + '">' + i.logo + '</div>' +
      '<div class="info"><b>' + i.name + '</b><span>' + i.desc + '</span></div>' +
      '<span class="status ' + i.status + '">' + statusMap[i.status] + '</span>' +
    '</div>'
  ).join('');
};

/* ═══════════════════════════════════════════════════════════
   §১০. CRYPTO STATUS BADGE
   ═══════════════════════════════════════════════════════════ */
window.v6RenderCryptoStatus = function(){
  const c = $('v6CryptoStatus'); if(!c) return;
  const hasKey = !!lsGet(KEYS.ENC_KEY, null);
  c.innerHTML = '<div class="crypto-status">' +
    '<span class="lock">' + (hasKey ? '🔐' : '🔓') + '</span>' +
    '<div><b>AES-256-GCM এনক্রিপশন ' + (hasKey ? 'সক্রিয়' : 'প্রস্তুত') + '</b><br>' +
    '<span style="font-size:11px;opacity:.8">ফোন নম্বর এনক্রিপ্টেড অবস্থায় সংরক্ষিত</span></div>' +
  '</div>';
};

/* ═══════════════════════════════════════════════════════════
   §১১. SCREEN HOOKS
   ═══════════════════════════════════════════════════════════ */
(function(){
  const orig = window.showScreen;
  if(typeof orig !== 'function') return;
  window.showScreen = function(name){
    const r = orig.apply(this, arguments);
    if(name === 'stats'){
      setTimeout(() => {
        const sc = $('screen-stats');
        if(sc && !$('v6KpiRoot')){
          sc.insertAdjacentHTML('beforeend',
            '<div class="st"><span class="em">📈</span> KPI ড্যাশবোর্ড</div>' +
            '<div id="v6KpiRoot"></div>' +
            '<div class="st"><span class="em">🗺️</span> জেলা হিটম্যাপ</div>' +
            '<div id="v6HeatmapRoot"></div>');
        }
        window.v6RenderKPI();
        window.v6RenderHeatmap();
      }, 200);
    }
    if(name === 'media-kit'){
      setTimeout(() => window.v6RenderMediaKit(), 100);
    }
    return r;
  };
})();

/* ═══════════════════════════════════════════════════════════
   §১২. BOOT
   ═══════════════════════════════════════════════════════════ */
function boot(){
  setTimeout(() => { try{ showConsent(); }catch(e){} }, 3500);
  setTimeout(() => window.v6RenderCryptoStatus(), 2500);
  console.log('%c✅ v6-enterprise.js loaded','color:#1565C0;font-weight:700');
}
if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();

window.V6 = {
  version: '6.0',
  Crypto, Audit, Queue,
  computeKPIs,
  CONSENT_VERSION
};

})();