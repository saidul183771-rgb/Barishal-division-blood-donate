/* ============================================================
   api-client.js — Backend Client (v10)
   ------------------------------------------------------------
   দুই মোডে কাজ করে, স্বয়ংক্রিয়ভাবে:

   ১) REAL BACKEND মোড — যদি /api/... এন্ডপয়েন্ট (Cloudflare Pages
      Functions, দেখুন /functions ফোল্ডার) deploy করা থাকে, তাহলে
      সব রিকোয়েস্ট সরাসরি সেখানে যায়। এতে সব ইউজার/ডিভাইসের মধ্যে
      রিয়েল-টাইম সিঙ্ক হয় (আসল প্রোডাকশন ব্যবহারের জন্য এটাই দরকার)।

   ২) LOCAL মোড (fallback) — যদি ব্যাকএন্ড না থাকে (যেমন প্লেইন
      স্ট্যাটিক হোস্টিং, প্রিভিউ, বা অফলাইন), তাহলে এই ফাইলটি নিজেই
      ব্রাউজারের localStorage-এ একটি সম্পূর্ণ কার্যকরী "mock backend"
      চালায় — OTP, রেজিস্ট্রেশন, রিকোয়েস্ট, হাসপাতাল, রিপোর্ট,
      ব্রডকাস্ট, অ্যাডমিন — সবকিছুর জন্য একই API contract মেনে।
      ফলে অ্যাপটি ব্যাকএন্ড ছাড়াই ১০০% ব্যবহারযোগ্য থাকে (এক ডিভাইসে),
      আবার ব্যাকএন্ড ডিপ্লয় করলে স্বয়ংক্রিয়ভাবে আপগ্রেড হয়ে যায়।

   কোনো স্ক্রিন/module (scripts.js, admin.html) window.BloodAPI-এর
   বাইরে কিছু জানার দরকার নেই — উভয় মোডেই ঠিক একই response shape।
   ============================================================ */
(function(){
'use strict';

const BASE = '';
const REQUEST_TIMEOUT_MS = 4000;

/* ───────────────────────── Real backend transport ───────────────────────── */

async function realReq(path, opts){
  opts = opts || {};
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), REQUEST_TIMEOUT_MS);
  let res;
  try{
    res = await fetch(BASE + path, Object.assign({
      credentials: 'include',
      signal: ctrl.signal,
      headers: Object.assign({ 'Content-Type': 'application/json' }, opts.headers || {})
    }, opts));
  }catch(e){
    clearTimeout(timer);
    throw { noBackend: true };
  }
  clearTimeout(timer);
  const ctype = res.headers.get('content-type') || '';
  if(!ctype.includes('application/json')){
    // Static host with no /api/* function deployed usually returns the
    // SPA fallback HTML (200) or a plain 404 page — never real JSON.
    throw { noBackend: true };
  }
  let data;
  try{ data = await res.json(); }
  catch(e){ throw { noBackend: true }; }
  if(!res.ok && data.success !== false) data.success = false;
  if(!res.ok && !data.message) data.message = 'অনুরোধ ব্যর্থ হয়েছে (' + res.status + ')';
  return data;
}

function qs(params){
  const usp = new URLSearchParams();
  Object.keys(params || {}).forEach(k => { if(params[k] !== undefined && params[k] !== null && params[k] !== '') usp.set(k, params[k]); });
  const s = usp.toString();
  return s ? ('?' + s) : '';
}

/* Remembers (per browser tab session) whether a real backend answered at
   least once, so we don't retry+timeout on every single call after the
   first miss — keeps the local fallback snappy. Re-checked on page load. */
let backendKnownMissing = null;

/* ───────────────────────── LOCAL fallback "server" ───────────────────────── */

const LDB_KEYS = {
  DONORS: 'lb_donors',       // phone -> donor row (server shape)
  OTP: 'lb_otp',             // phone -> { code, expiresAt, attempts }
  SESSIONS: 'lb_sessions',   // token -> { phone, role, createdAt }
  ADMINS: 'lb_admins',       // [ phone, ... ]
  REQUESTS: 'lb_requests',   // [ request rows ]
  RESPONSES: 'lb_responses', // requestId -> [ {phone, status, at} ]
  HOSPITALS: 'lb_hospitals', // [ hospital rows ]
  REPORTS: 'lb_reports',     // [ report rows ]
  BROADCASTS: 'lb_broadcasts', // [ {id, message, at} ]
  AUDIT: 'lb_audit',         // [ {id, action, target, note, at} ]
  MY_TOKEN: 'lb_my_token'    // this browser's current session token
};

function lget(k, fb){ try{ const r = localStorage.getItem(k); return r == null ? fb : JSON.parse(r); }catch(e){ return fb; } }
function lset(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
function uid(prefix){ return (prefix||'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2,8); }
function normPhone(p){ return String(p||'').trim(); }

function ldbAudit(action, target, note){
  const arr = lget(LDB_KEYS.AUDIT, []);
  arr.unshift({ id: uid('a'), action, target: target||'', note: note||'', at: Date.now() });
  if(arr.length > 300) arr.length = 300;
  lset(LDB_KEYS.AUDIT, arr);
}

function currentLocalSession(){
  const token = lget(LDB_KEYS.MY_TOKEN, null);
  if(!token) return null;
  const sessions = lget(LDB_KEYS.SESSIONS, {});
  return sessions[token] ? Object.assign({ token }, sessions[token]) : null;
}

function requireLocalRole(role){
  const s = currentLocalSession();
  if(!s) return { ok:false, res:{ success:false, message:'লগইন প্রয়োজন' } };
  if(role === 'admin' && s.role !== 'admin') return { ok:false, res:{ success:false, message:'শুধু Admin অনুমোদিত' } };
  return { ok:true, session:s };
}

function serverDonorShape(row){
  if(!row) return null;
  return {
    id: row.id, name: row.name, phone: row.phone, blood: row.blood,
    district: row.district, upazila: row.upazila,
    last_donation: row.last_donation || null, age: row.age || null, weight: row.weight || null,
    gender: row.gender || null, emergency: row.emergency || 'yes',
    verified: !!row.verified, blood_verified: !!row.blood_verified,
    nid_rejected: !!row.nid_rejected, nid_reject_reason: row.nid_reject_reason || null,
    suspended: !!row.suspended, suspend_reason: row.suspend_reason || null,
    donations: row.donations || 0, response_rate: row.response_rate || 0,
    created_at: row.created_at || Date.now()
  };
}

const Local = {

  /* ─── OTP + session ─── */
  async sendOtp(phone){
    phone = normPhone(phone);
    if(!/^01[3-9]\d{8}$/.test(phone)) return { success:false, message:'সঠিক ১১-সংখ্যার নম্বর দিন' };
    const store = lget(LDB_KEYS.OTP, {});
    const code = String(Math.floor(100000 + Math.random()*900000));
    store[phone] = { code, expiresAt: Date.now() + 5*60000, attempts: 0 };
    lset(LDB_KEYS.OTP, store);
    // বাস্তব SMS গেটওয়ে না থাকায়, devOTP হিসেবে ফেরত দেওয়া হচ্ছে (dev/local mode)।
    return { success:true, message:'OTP পাঠানো হয়েছে (লোকাল মোড)', devOTP: code };
  },

  async verifyOtp(phone, otp){
    phone = normPhone(phone);
    const store = lget(LDB_KEYS.OTP, {});
    const rec = store[phone];
    if(!rec) return { success:false, message:'আগে OTP পাঠান' };
    if(Date.now() > rec.expiresAt){ delete store[phone]; lset(LDB_KEYS.OTP, store); return { success:false, message:'OTP মেয়াদ শেষ — আবার চেষ্টা করুন' }; }
    rec.attempts = (rec.attempts||0) + 1;
    if(rec.attempts > 5){ delete store[phone]; lset(LDB_KEYS.OTP, store); return { success:false, message:'বার বার ভুল — আবার OTP নিন' }; }
    if(String(otp) !== rec.code){ lset(LDB_KEYS.OTP, store); return { success:false, message:'ভুল OTP কোড' }; }
    delete store[phone]; lset(LDB_KEYS.OTP, store);

    const admins = lget(LDB_KEYS.ADMINS, []);
    const role = admins.includes(phone) ? 'admin' : 'donor';
    const donors = lget(LDB_KEYS.DONORS, {});
    const hasProfile = !!donors[phone];

    const token = uid('tok');
    const sessions = lget(LDB_KEYS.SESSIONS, {});
    sessions[token] = { phone, role, createdAt: Date.now() };
    lset(LDB_KEYS.SESSIONS, sessions);
    lset(LDB_KEYS.MY_TOKEN, token);
    ldbAudit('LOGIN', phone, role);
    return { success:true, role, hasProfile };
  },

  async logout(){
    const token = lget(LDB_KEYS.MY_TOKEN, null);
    if(token){
      const sessions = lget(LDB_KEYS.SESSIONS, {});
      delete sessions[token];
      lset(LDB_KEYS.SESSIONS, sessions);
      lset(LDB_KEYS.MY_TOKEN, null);
    }
    return { success:true };
  },

  async me(){
    const s = currentLocalSession();
    if(!s) return { success:false, message:'সেশন নেই' };
    const donors = lget(LDB_KEYS.DONORS, {});
    const donor = donors[s.phone] || null;
    return { success:true, role: s.role, donor: donor ? serverDonorShape(donor) : null };
  },

  /* ─── donors ─── */
  async registerDonor(payload){
    const s = currentLocalSession();
    if(!s) return { success:false, message:'আগে ফোন verify করুন' };
    const donors = lget(LDB_KEYS.DONORS, {});
    const existing = donors[s.phone];
    const row = Object.assign({
      id: existing ? existing.id : uid('d'),
      phone: s.phone,
      verified: false, blood_verified: false,
      nid_rejected: false, nid_reject_reason: null,
      suspended: false, suspend_reason: null,
      donations: existing ? existing.donations : 0,
      response_rate: existing ? existing.response_rate : 0,
      created_at: existing ? existing.created_at : Date.now()
    }, existing || {}, {
      name: payload.name, blood: payload.blood, district: payload.district, upazila: payload.upazila,
      age: payload.age || null, weight: payload.weight || null, gender: payload.gender || null,
      emergency: payload.emergency || 'yes', last_donation: payload.lastDonation || null,
      nid_number: payload.nidNumber || (existing && existing.nid_number) || null,
      nid_photo: payload.nidPhoto || (existing && existing.nid_photo) || null,
      // re-registration goes back to pending review
      verified: false, nid_rejected: false
    });
    donors[s.phone] = row;
    lset(LDB_KEYS.DONORS, donors);
    ldbAudit(existing ? 'DONOR_UPDATED' : 'DONOR_REGISTERED', s.phone, payload.name);
    return { success:true, id: row.id, status: existing ? 'updated' : 'created' };
  },

  async listDonors(params){
    const donors = Object.values(lget(LDB_KEYS.DONORS, {})).filter(d => !d.suspended);
    let list = donors.map(serverDonorShape);
    if(params){
      if(params.blood) list = list.filter(d => d.blood === params.blood);
      if(params.district) list = list.filter(d => d.district === params.district);
      if(params.upazila) list = list.filter(d => d.upazila === params.upazila);
    }
    return { success:true, donors: list };
  },

  /* ─── requests ─── */
  async createRequest(payload){
    const reqs = lget(LDB_KEYS.REQUESTS, []);
    const row = Object.assign({ id: uid('r'), status:'active', at: Date.now() }, payload);
    reqs.unshift(row);
    lset(LDB_KEYS.REQUESTS, reqs);
    ldbAudit('REQUEST_CREATED', row.id, payload.blood + ' · ' + (payload.upazila||''));
    return { success:true, id: row.id, request: row };
  },

  async listRequests(params){
    let list = lget(LDB_KEYS.REQUESTS, []);
    if(params && params.status) list = list.filter(r => r.status === params.status);
    return { success:true, requests: list };
  },

  async getRequest(id){
    const list = lget(LDB_KEYS.REQUESTS, []);
    const r = list.find(x => x.id === id);
    return r ? { success:true, request:r } : { success:false, message:'পাওয়া যায়নি' };
  },

  async updateRequestStatus(id, status){
    const list = lget(LDB_KEYS.REQUESTS, []);
    const r = list.find(x => x.id === id);
    if(!r) return { success:false, message:'পাওয়া যায়নি' };
    r.status = status;
    r.updatedAt = Date.now();
    lset(LDB_KEYS.REQUESTS, list);
    ldbAudit('REQUEST_STATUS', id, status);
    return { success:true };
  },

  async respondToRequest(id, status){
    const s = currentLocalSession();
    if(!s) return { success:false, message:'লগইন প্রয়োজন' };
    const all = lget(LDB_KEYS.RESPONSES, {});
    const arr = all[id] || [];
    arr.push({ phone: s.phone, status, at: Date.now() });
    all[id] = arr;
    lset(LDB_KEYS.RESPONSES, all);
    return { success:true };
  },

  async listRequestResponses(id){
    const all = lget(LDB_KEYS.RESPONSES, {});
    return { success:true, responses: all[id] || [] };
  },

  /* ─── hospitals ─── */
  async listHospitals(params){
    let list = lget(LDB_KEYS.HOSPITALS, []);
    if(params && params.district) list = list.filter(h => h.district === params.district);
    return { success:true, hospitals: list };
  },

  async addHospital(payload){
    const list = lget(LDB_KEYS.HOSPITALS, []);
    const row = Object.assign({ id: uid('h'), verified:false, createdAt: Date.now() }, payload);
    list.push(row);
    lset(LDB_KEYS.HOSPITALS, list);
    ldbAudit('HOSPITAL_ADDED', row.id, payload.name);
    return { success:true, id: row.id };
  },

  /* ─── reports ─── */
  async fileReport(payload){
    const list = lget(LDB_KEYS.REPORTS, []);
    const row = Object.assign({ id: uid('rep'), status:'open', createdAt: Date.now() }, payload);
    list.unshift(row);
    lset(LDB_KEYS.REPORTS, list);
    ldbAudit('REPORT_FILED', row.id, payload.reason || '');
    return { success:true, id: row.id };
  },

  async listReports(params){
    let list = lget(LDB_KEYS.REPORTS, []);
    if(params && params.status) list = list.filter(r => r.status === params.status);
    return { success:true, reports: list };
  },

  async resolveReport(id, status){
    const check = requireLocalRole('admin'); if(!check.ok) return check.res;
    const list = lget(LDB_KEYS.REPORTS, []);
    const r = list.find(x => x.id === id);
    if(!r) return { success:false, message:'পাওয়া যায়নি' };
    r.status = status;
    lset(LDB_KEYS.REPORTS, list);
    ldbAudit('RESOLVE_REPORT', id, status);
    return { success:true };
  },

  /* ─── broadcasts ─── */
  async listBroadcasts(limit){
    const list = lget(LDB_KEYS.BROADCASTS, []);
    return { success:true, broadcasts: list.slice(0, limit || 20) };
  },

  async sendBroadcast(message){
    const check = requireLocalRole('admin'); if(!check.ok) return check.res;
    const list = lget(LDB_KEYS.BROADCASTS, []);
    list.unshift({ id: uid('bc'), message, at: Date.now() });
    lset(LDB_KEYS.BROADCASTS, list);
    ldbAudit('BROADCAST_SENT', '', message);
    return { success:true };
  },

  /* ─── admin ─── */
  async adminListDonors(filter){
    const check = requireLocalRole('admin'); if(!check.ok) return check.res;
    let list = Object.values(lget(LDB_KEYS.DONORS, {})).map(serverDonorShape);
    if(filter === 'pending') list = list.filter(d => !d.verified && !d.nid_rejected);
    if(filter === 'verified') list = list.filter(d => d.verified);
    if(filter === 'suspended') list = list.filter(d => d.suspended);
    return { success:true, donors: list };
  },

  async adminDonorAction(id, action, reason){
    const check = requireLocalRole('admin'); if(!check.ok) return check.res;
    const donors = lget(LDB_KEYS.DONORS, {});
    const phone = Object.keys(donors).find(p => donors[p].id === id);
    if(!phone) return { success:false, message:'ডোনার পাওয়া যায়নি' };
    const d = donors[phone];
    if(action === 'verify'){ d.verified = true; d.blood_verified = true; d.nid_rejected = false; }
    else if(action === 'suspend'){ d.suspended = true; d.suspend_reason = reason || ''; }
    else if(action === 'unsuspend'){ d.suspended = false; d.suspend_reason = null; }
    else if(action === 'reject_nid'){ d.nid_rejected = true; d.nid_reject_reason = reason || ''; d.verified = false; }
    else return { success:false, message:'অজানা action' };
    lset(LDB_KEYS.DONORS, donors);
    ldbAudit(action === 'verify' ? 'VERIFY_DONOR' : action === 'suspend' ? 'SUSPEND_DONOR' : action.toUpperCase(), phone, reason || '');
    return { success:true };
  },

  async adminListAdmins(){
    const check = requireLocalRole('admin');
    const admins = lget(LDB_KEYS.ADMINS, []);
    // প্রথম কোনো admin না থাকলে (bootstrap অবস্থা) — লগইন ছাড়াই তালিকা দেখা যাবে
    if(!check.ok && admins.length > 0) return check.res;
    return { success:true, admins };
  },

  async adminAddAdmin(phone){
    phone = normPhone(phone);
    const admins = lget(LDB_KEYS.ADMINS, []);
    if(admins.length > 0){
      const check = requireLocalRole('admin'); if(!check.ok) return check.res;
    }
    // bootstrap: প্রথম admin কেউ session ছাড়াই নিজেকে যোগ করতে পারবে
    if(!admins.includes(phone)) admins.push(phone);
    lset(LDB_KEYS.ADMINS, admins);
    // যদি এই ফোনে চালু সেশন থাকে, রোল আপডেট করে দিন
    const sessions = lget(LDB_KEYS.SESSIONS, {});
    Object.keys(sessions).forEach(t => { if(sessions[t].phone === phone) sessions[t].role = 'admin'; });
    lset(LDB_KEYS.SESSIONS, sessions);
    ldbAudit('ADMIN_ADDED', phone, '');
    return { success:true, admins };
  },

  async adminRemoveAdmin(phone){
    const check = requireLocalRole('admin'); if(!check.ok) return check.res;
    let admins = lget(LDB_KEYS.ADMINS, []);
    admins = admins.filter(p => p !== phone);
    lset(LDB_KEYS.ADMINS, admins);
    ldbAudit('ADMIN_REMOVED', phone, '');
    return { success:true, admins };
  },

  async adminHospitalAction(id, action){
    const check = requireLocalRole('admin'); if(!check.ok) return check.res;
    const list = lget(LDB_KEYS.HOSPITALS, []);
    const h = list.find(x => x.id === id);
    if(!h) return { success:false, message:'পাওয়া যায়নি' };
    if(action === 'approve') h.verified = true;
    lset(LDB_KEYS.HOSPITALS, list);
    ldbAudit('APPROVE_HOSPITAL', id, '');
    return { success:true };
  },

  async adminListAudit(limit){
    const check = requireLocalRole('admin'); if(!check.ok) return check.res;
    const list = lget(LDB_KEYS.AUDIT, []);
    return { success:true, log: list.slice(0, limit || 200) };
  }
};

/* ───────────────────────── Public API (auto-switching) ───────────────────────── */

function wrap(realCall, localCall){
  return async function(){
    const args = arguments;
    if(backendKnownMissing !== true){
      try{
        const result = await realCall.apply(null, args);
        backendKnownMissing = false;
        return result;
      }catch(e){
        if(!e || !e.noBackend) throw e;
        backendKnownMissing = true; // পরের কলগুলোতে সাথে সাথে local মোডে যাবে
      }
    }
    return localCall.apply(null, args);
  };
}

window.BloodAPI = {
  isLocalMode: () => backendKnownMissing === true,

  sendOtp: wrap(
    (phone) => realReq('/api/otp/send', { method:'POST', body: JSON.stringify({ phone }) }),
    (phone) => Local.sendOtp(phone)),

  verifyOtp: wrap(
    (phone, otp) => realReq('/api/otp/verify', { method:'POST', body: JSON.stringify({ phone, otp }) }),
    (phone, otp) => Local.verifyOtp(phone, otp)),

  logout: wrap(
    () => realReq('/api/auth/logout', { method:'POST' }),
    () => Local.logout()),

  me: wrap(
    () => realReq('/api/donors/me'),
    () => Local.me()),

  registerDonor: wrap(
    (payload) => realReq('/api/donors/register', { method:'POST', body: JSON.stringify(payload) }),
    (payload) => Local.registerDonor(payload)),

  listDonors: wrap(
    (params) => realReq('/api/donors/list' + qs(params)),
    (params) => Local.listDonors(params)),

  listRequests: wrap(
    (params) => realReq('/api/requests' + qs(params)),
    (params) => Local.listRequests(params)),

  createRequest: wrap(
    (payload) => realReq('/api/requests', { method:'POST', body: JSON.stringify(payload) }),
    (payload) => Local.createRequest(payload)),

  getRequest: wrap(
    (id) => realReq('/api/requests/' + encodeURIComponent(id)),
    (id) => Local.getRequest(id)),

  updateRequestStatus: wrap(
    (id, status) => realReq('/api/requests/' + encodeURIComponent(id), { method:'PATCH', body: JSON.stringify({ status }) }),
    (id, status) => Local.updateRequestStatus(id, status)),

  respondToRequest: wrap(
    (id, status) => realReq('/api/requests/' + encodeURIComponent(id) + '/respond', { method:'POST', body: JSON.stringify({ status }) }),
    (id, status) => Local.respondToRequest(id, status)),

  listRequestResponses: wrap(
    (id) => realReq('/api/requests/' + encodeURIComponent(id) + '/respond'),
    (id) => Local.listRequestResponses(id)),

  listHospitals: wrap(
    (params) => realReq('/api/hospitals' + qs(params)),
    (params) => Local.listHospitals(params)),

  addHospital: wrap(
    (payload) => realReq('/api/hospitals', { method:'POST', body: JSON.stringify(payload) }),
    (payload) => Local.addHospital(payload)),

  fileReport: wrap(
    (payload) => realReq('/api/reports', { method:'POST', body: JSON.stringify(payload) }),
    (payload) => Local.fileReport(payload)),

  listReports: wrap(
    (params) => realReq('/api/reports' + qs(params)),
    (params) => Local.listReports(params)),

  resolveReport: wrap(
    (id, status) => realReq('/api/reports/' + encodeURIComponent(id), { method:'PATCH', body: JSON.stringify({ status }) }),
    (id, status) => Local.resolveReport(id, status)),

  listBroadcasts: wrap(
    (limit) => realReq('/api/broadcasts' + qs({ limit })),
    (limit) => Local.listBroadcasts(limit)),

  sendBroadcast: wrap(
    (message) => realReq('/api/broadcasts', { method:'POST', body: JSON.stringify({ message }) }),
    (message) => Local.sendBroadcast(message)),

  adminListDonors: wrap(
    (filter) => realReq('/api/admin/donors' + qs({ filter })),
    (filter) => Local.adminListDonors(filter)),

  adminDonorAction: wrap(
    (id, action, reason) => realReq('/api/admin/donors', { method:'PATCH', body: JSON.stringify({ id, action, reason }) }),
    (id, action, reason) => Local.adminDonorAction(id, action, reason)),

  adminListAdmins: wrap(
    () => realReq('/api/admin/admins'),
    () => Local.adminListAdmins()),

  adminAddAdmin: wrap(
    (phone) => realReq('/api/admin/admins', { method:'POST', body: JSON.stringify({ phone }) }),
    (phone) => Local.adminAddAdmin(phone)),

  adminRemoveAdmin: wrap(
    (phone) => realReq('/api/admin/admins', { method:'DELETE', body: JSON.stringify({ phone }) }),
    (phone) => Local.adminRemoveAdmin(phone)),

  adminHospitalAction: wrap(
    (id, action) => realReq('/api/admin/hospitals', { method:'PATCH', body: JSON.stringify({ id, action }) }),
    (id, action) => Local.adminHospitalAction(id, action)),

  adminListAudit: wrap(
    (limit) => realReq('/api/admin/audit' + qs({ limit })),
    (limit) => Local.adminListAudit(limit))
};

console.log('%c✅ api-client.js loaded (v10 — auto real/local mode)', 'color:#1565C0;font-weight:700');
})();
