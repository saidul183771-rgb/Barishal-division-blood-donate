/* ============================================================
   বরিশাল রক্তদাতা v9.0 — scripts.js
   পার্ট ১: Core App + v5 Modules + Firebase Sync
   ============================================================ */

/* ═══════════════════════════════════════════════════════════
   MODULE 0: hidden-admin-access.js — গোপন Admin এন্ট্রি
   লোগোতে ৬০০ms-এর মধ্যে ৫ বার ট্যাপ করলে admin.html-এ যাবে,
   না হলে স্বাভাবিক navigation (index.html) হবে।
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
let tapCount = 0, tapTimer = null;
window.handleLogoTap = function(e, normalHref){
  e.preventDefault();
  tapCount++;
  clearTimeout(tapTimer);
  if(tapCount >= 5){
    tapCount = 0;
    window.location.href = 'admin.html';
    return;
  }
  tapTimer = setTimeout(() => {
    if(tapCount > 0) window.location.href = normalHref;
    tapCount = 0;
  }, 600);
};
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 1: app.js — মূল অ্যাপ লজিক
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';

const DEMO_MODE = true;
const BLOOD_GROUPS = ['A+','A-','B+','B-','O+','O-','AB+','AB-'];
const RARE_GROUPS = ['A-','B-','O-','AB-','AB+'];

const DISTRICTS = {
  'বরিশাল':['বরিশাল সদর','বাকেরগঞ্জ','বাবুগঞ্জ','উজিরপুর','বানারীপাড়া','গৌরনদী','আগৈলঝাড়া','মেহেন্দিগঞ্জ','মুলাদী','হিজলা'],
  'পটুয়াখালী':['পটুয়াখালী সদর','বাউফল','দশমিনা','গলাচিপা','কলাপাড়া','মির্জাগঞ্জ','রাঙ্গাবালী','দুমকি'],
  'ভোলা':['ভোলা সদর','বোরহানউদ্দিন','চরফ্যাশন','দৌলতখান','লালমোহন','মনপুরা','তজুমদ্দিন'],
  'পিরোজপুর':['পিরোজপুর সদর','ভান্ডারিয়া','কাউখালী','মঠবাড়িয়া','নাজিরপুর','নেছারাবাদ','জিয়ানগর'],
  'বরগুনা':['বরগুনা সদর','আমতলী','বামনা','বেতাগী','পাথরঘাটা','তালতলী'],
  'ঝালকাঠি':['ঝালকাঠি সদর','কাঠালিয়া','নলছিটি','রাজাপুর']
};
const UPZ_TO_DIST = {};
Object.keys(DISTRICTS).forEach(d => DISTRICTS[d].forEach(u => UPZ_TO_DIST[u] = d));

const HEALTH_TIPS = [
  {t:'🩸 রক্তদানের আগে', d:'ভালো করে খাবার খান এবং ২-৩ গ্লাস পানি পান করুন।'},
  {t:'⏱️ রক্তদানের পর', d:'১০-১৫ মিনিট বিশ্রাম নিন এবং হালকা স্ন্যাকস খান।'},
  {t:'📅 প্রতি ৩ মাসে', d:'পুরুষরা ৩ মাস, মহিলারা ৪ মাস পর পর রক্ত দিতে পারবেন।'},
  {t:'💪 সুস্থ থাকুন', d:'নিয়মিত ব্যায়াম ও আয়রন-সমৃদ্ধ খাবার খান।'},
  {t:'🌙 পর্যাপ্ত ঘুম', d:'রক্তদানের আগের রাতে ৭-৮ ঘণ্টা ঘুমানো জরুরি।'}
];

const KEYS = {
  DONORS: 'donors', REQUESTS: 'requests', PROFILE: 'barishalProfile',
  NOTIFS: 'notifications', THEME: 'theme', LANG: 'lang'
};

const $ = id => document.getElementById(id);
const toBn = n => String(n||0).replace(/[0-9]/g, d => '০১২৩৪৫৬৭৮৯'[+d]);
const escapeHtml = s => String(s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function lsGet(k, fb){ try{ const r = localStorage.getItem(k); return r==null ? fb : JSON.parse(r); }catch(e){ return fb; } }
function lsSet(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
function debounce(fn, ms){ let t; return function(){ clearTimeout(t); const a=arguments, self=this; t = setTimeout(()=>fn.apply(self,a), ms); }; }

window.donors = [];
window.requests = [];
window.notifications = [];
let selectedBloodHome = null;
let selectedBloodSearch = null;
let activeQuickFilter = 'all';
let currentScreen = 'home';

function hideSplash(){
  const s = $('splash');
  if(s){ s.classList.add('hide'); setTimeout(()=>{ s.style.display = 'none'; }, 600); }
}
window.hideSplash = hideSplash;

window.toast = function(msg, type){
  const t = $('toast');
  if(!t){ console.log('[toast]', msg); return; }
  t.className = 'toast ' + (type||'');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(()=>{ t.classList.remove('show'); }, 2600);
};

window.openModal = function(html){
  const m = $('modal'), c = $('modalContent');
  if(!m || !c) return;
  c.innerHTML = html;
  m.classList.add('show');
};
window.closeModal = function(){
  const m = $('modal');
  if(m) m.classList.remove('show');
};

window.showScreen = function(name){
  currentScreen = name;
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const target = $('screen-' + name);
  if(target) target.classList.add('active');
  document.querySelectorAll('.bnav .nitem').forEach(b => {
    b.classList.toggle('active', b.dataset.nav === name);
  });
  window.scrollTo({top:0, behavior:'smooth'});
  if(name === 'profile') renderProfile();
  if(name === 'register' && typeof window.renderRegisterScreen === 'function') window.renderRegisterScreen();
  if(name === 'notifications') renderNotifications();
  if(name === 'requests-list') renderRequestsList();
  if(name === 'ambulance' && window.renderAmbulanceDirectory) window.renderAmbulanceDirectory();
  if(name === 'emergency' && window.renderEmergencyDirectory) window.renderEmergencyDirectory();
  if(name === 'hospitals' && window.renderHospitalsList) window.renderHospitalsList();
  if(name === 'events') renderEventsList();
  if(name === 'stats') renderStatsScreen();
};

window.toggleTheme = function(){
  const cur = document.body.getAttribute('data-theme') || 'light';
  const next = cur === 'dark' ? 'light' : 'dark';
  document.body.setAttribute('data-theme', next);
  lsSet(KEYS.THEME, next);
  const btn = $('themeBtn'); if(btn) btn.textContent = next === 'dark' ? '☀️' : '🌙';
  const st = $('themeStatus'); if(st) st.textContent = next === 'dark' ? 'চালু' : 'বন্ধ';
};

window.toggleLang = function(){
  const cur = document.body.getAttribute('data-lang') || 'bn';
  const next = cur === 'bn' ? 'en' : 'bn';
  document.body.setAttribute('data-lang', next);
  lsSet(KEYS.LANG, next);
  const btn = $('langBtn'); if(btn) btn.textContent = next === 'bn' ? 'EN' : 'বাং';
  const st = $('langStatus'); if(st) st.textContent = next === 'bn' ? 'বাংলা' : 'English';
};

function loadData(){
  window.donors = lsGet(KEYS.DONORS, []);
  window.requests = lsGet(KEYS.REQUESTS, []);
  window.notifications = lsGet(KEYS.NOTIFS, []);
  if(DEMO_MODE && window.donors.length === 0) seedDemoData();
}
function saveDonors(){ lsSet(KEYS.DONORS, window.donors); }
function saveRequests(){ lsSet(KEYS.REQUESTS, window.requests); }
function saveNotifs(){ lsSet(KEYS.NOTIFS, window.notifications); }

// BloodAPI (real backend বা local fallback) থেকে registered/verified ডোনারদের
// এনে window.donors (search/browse cache)-এ merge করে — যাতে registration,
// verify, suspend ইত্যাদির প্রভাব সার্চ স্ক্রিনে সঠিকভাবে দেখা যায়।
async function syncServerDonors(){
  try{
    if(!window.BloodAPI) return;
    const res = await window.BloodAPI.listDonors();
    if(!res || !res.success || !Array.isArray(res.donors)) return;
    let changed = false;
    res.donors.forEach(sd => {
      const mapped = {
        id: sd.id, name: sd.name, phone: sd.phone, blood: sd.blood,
        district: sd.district, upazila: sd.upazila,
        lastDonation: sd.last_donation || null, age: sd.age || null, weight: sd.weight || null,
        gender: sd.gender || null, emergency: sd.emergency || 'yes',
        verified: !!sd.verified, bloodVerified: !!sd.blood_verified,
        suspended: !!sd.suspended, donations: sd.donations || 0,
        responseRate: sd.response_rate || 0, createdAt: sd.created_at || Date.now()
      };
      if(mapped.suspended) return; // সাসপেন্ড হলে পাবলিক লিস্টে দেখানো হয় না
      const idx = window.donors.findIndex(d => d.id === mapped.id || (d.phone && mapped.phone && d.phone === mapped.phone));
      if(idx === -1) window.donors.push(mapped); else window.donors[idx] = Object.assign({}, window.donors[idx], mapped);
      changed = true;
    });
    if(changed){ saveDonors(); if(typeof renderDonors === 'function') renderDonors(); if(typeof renderBloodGrids === 'function') renderBloodGrids(); }
  }catch(e){ /* silent — offline বা backend নেই */ }
}
window.syncServerDonors = syncServerDonors;

// BloodAPI থেকে সার্ভারে জমা হওয়া রিকোয়েস্টও লোকাল requests লিস্টে merge করে
async function syncServerRequests(){
  try{
    if(!window.BloodAPI) return;
    const res = await window.BloodAPI.listRequests();
    if(!res || !res.success || !Array.isArray(res.requests)) return;
    let changed = false;
    res.requests.forEach(sr => {
      const idx = window.requests.findIndex(r => r.id === sr.id);
      if(idx === -1){ window.requests.push(sr); changed = true; }
      else if(window.requests[idx].status !== sr.status){ window.requests[idx].status = sr.status; changed = true; }
    });
    if(changed){
      window.requests.sort((a,b) => (b.at||0) - (a.at||0));
      saveRequests();
      if(typeof renderRequestsList === 'function' && currentScreen === 'requests-list') renderRequestsList();
    }
  }catch(e){ /* silent */ }
}
window.syncServerRequests = syncServerRequests;

function seedDemoData(){
  const names = ['রফিকুল ইসলাম','সাদিয়া আক্তার','তানভীর হাসান','মেহেদী হাসান','ফারজানা রহমান','আরিফ চৌধুরী','নুসরাত জাহান','মামুন হোসেন','রুবিনা আক্তার','জাহিদ হাসান'];
  const groups = ['A+','B+','O+','AB+','O-','A-','B+','O+','A+','B+'];
  const areas = [['বরিশাল','বরিশাল সদর'],['বরিশাল','বাকেরগঞ্জ'],['পটুয়াখালী','পটুয়াখালী সদর'],['ভোলা','ভোলা সদর'],['পিরোজপুর','পিরোজপুর সদর'],['বরগুনা','বরগুনা সদর'],['ঝালকাঠি','ঝালকাঠি সদর'],['বরিশাল','গৌরনদী'],['পটুয়াখালী','বাউফল'],['ভোলা','চরফ্যাশন']];
  const now = Date.now();
  window.donors = names.map((n,i)=>({
    id: 'demo' + i, name: n,
    phone: '01700000' + String(100 + i).slice(-3),
    blood: groups[i], district: areas[i][0], upazila: areas[i][1],
    verified: i < 6, bloodVerified: i < 6,
    donations: [5,3,8,2,12,1,4,6,0,3][i],
    lastDonation: new Date(now - (60 + i*20)*86400000).toISOString().slice(0,10),
    responseRate: [0.8,0.7,0.9,0.4,0.85,0.3,0.6,0.75,0,0.5][i],
    createdAt: now - (200 + i*15)*86400000, demo: true
  }));
  saveDonors();
  window.requests = [
    {id:'r1',patient:'আব্দুল করিম',blood:'B+',district:'বরিশাল',upazila:'বরিশাল সদর',hospital:'শের-ই-বাংলা মেডিকেল',phone:'01700000001',urgency:'critical',bags:2,at:now-3600000,status:'active'},
    {id:'r2',patient:'ফাতেমা বেগম',blood:'O+',district:'পটুয়াখালী',upazila:'পটুয়াখালী সদর',hospital:'পটুয়াখালী মেডিকেল',phone:'01700000002',urgency:'urgent',bags:1,at:now-7200000,status:'active'}
  ];
  saveRequests();
  console.log('✅ Demo data seeded:', window.donors.length, 'donors,', window.requests.length, 'requests');
}

function renderBloodGrids(){
  renderBloodGrid('homeBloodGrid');
  renderBloodGrid('searchBloodGrid');
}
function renderBloodGrid(containerId){
  const c = $(containerId);
  if(!c) return;
  c.innerHTML = BLOOD_GROUPS.map(g => {
    const count = window.donors.filter(d => d.blood === g).length;
    return '<button class="b-chip" data-blood="' + g + '" onclick="__selectBlood(\'' + containerId + '\',\'' + g + '\')">' + g + '<span class="cnt">' + toBn(count) + ' জন</span></button>';
  }).join('');
}
window.__selectBlood = function(containerId, blood){
  const c = $(containerId);
  if(!c) return;
  const isHome = containerId === 'homeBloodGrid';
  const current = isHome ? selectedBloodHome : selectedBloodSearch;
  const next = current === blood ? null : blood;
  if(isHome) selectedBloodHome = next;
  else selectedBloodSearch = next;
  c.querySelectorAll('.b-chip').forEach(chip => { chip.classList.toggle('active', chip.dataset.blood === next); });
  if(isHome){
    const upd = next ? window.donors.filter(d => d.blood === next).length : window.donors.length;
    const el = $('availCount');
    if(el) el.textContent = toBn(upd) + ' উপলব্ধ';
  } else { renderDonors(); }
};

function populateDistricts(){
  const distHtml = '<option value="">সব জেলা</option>' + Object.keys(DISTRICTS).map(d => '<option value="' + d + '">' + d + '</option>').join('');
  const reqDistHtml = '<option value="">নির্বাচন</option>' + Object.keys(DISTRICTS).map(d => '<option value="' + d + '">' + d + '</option>').join('');
  ['homeDistrict','searchDistrict'].forEach(id => { const el=$(id); if(el) el.innerHTML = distHtml; });
  ['reqDistrict','regDistrict'].forEach(id => { const el=$(id); if(el) el.innerHTML = reqDistHtml; });
}

window.updateUpazila = function(distId, upzId){
  const d = $(distId), u = $(upzId);
  if(!d || !u) return;
  const dist = d.value;
  const list = DISTRICTS[dist] || [];
  u.innerHTML = '<option value="">' + (dist ? 'নির্বাচন' : 'সব উপজেলা') + '</option>' + list.map(x => '<option value="' + x + '">' + x + '</option>').join('');
};

function populateBloodDropdowns(){
  const bloodOptions = BLOOD_GROUPS.map(g => '<option value="' + g + '">' + g + '</option>').join('');
  const reqBlood = $('reqBlood');
  if(reqBlood && reqBlood.options.length <= 1){
    reqBlood.innerHTML = '<option value="">গ্রুপ নির্বাচন করুন</option>' + bloodOptions;
    console.log('✅ Blood dropdown populated: reqBlood');
  }
  const regBlood = $('regBlood');
  if(regBlood && regBlood.options.length <= 1){
    regBlood.innerHTML = '<option value="">গ্রুপ নির্বাচন করুন</option>' + bloodOptions;
    console.log('✅ Blood dropdown populated: regBlood');
  }
  const compatGroup = $('compatGroup');
  if(compatGroup && compatGroup.options.length <= 1){
    compatGroup.innerHTML = '<option value="">নির্বাচন করুন</option>' + bloodOptions;
  }
}

function filterDonors(){
  const nameQ = ($('searchName') && $('searchName').value || '').toLowerCase().trim();
  const dist = $('searchDistrict') ? $('searchDistrict').value : '';
  const upz = $('searchUpazila') ? $('searchUpazila').value : '';
  const blood = selectedBloodSearch;
  let list = window.donors.slice();
  if(blood) list = list.filter(d => d.blood === blood);
  if(dist) list = list.filter(d => d.district === dist);
  if(upz) list = list.filter(d => d.upazila === upz);
  if(nameQ) list = list.filter(d => (d.name||'').toLowerCase().includes(nameQ) || (d.phone||'').includes(nameQ));
  if(activeQuickFilter === 'verified') list = list.filter(d => d.verified);
  else if(activeQuickFilter === 'eligible'){ const now = Date.now(); list = list.filter(d => (now - new Date(d.lastDonation||0).getTime()) / 86400000 >= 90); }
  else if(activeQuickFilter === 'rare') list = list.filter(d => RARE_GROUPS.includes(d.blood));
  else if(activeQuickFilter === 'top') list = list.sort((a,b) => (b.donations||0)-(a.donations||0)).slice(0, 20);
  else if(activeQuickFilter === 'online') list = list.filter(d => { const av = window.getDonorAvailability ? window.getDonorAvailability(d) : null; return av && av.status === 'available'; });
  return list;
}

window.renderDonors = function(){
  const c = $('donorResults');
  if(!c) return;
  const list = filterDonors();
  if(!list.length){
    c.innerHTML = '<div class="empty"><div class="empty-ic">🩸</div><div class="empty-t">কোনো ডোনার পাওয়া যায়নি</div><div class="empty-s">ফিল্টার পরিবর্তন করুন</div></div>';
    return;
  }
  c.innerHTML = list.map(d => donorCardHTML(d)).join('');
};

function donorCardHTML(d){
  const initial = (d.name||'?').trim().charAt(0).toUpperCase();
  const trustIcon = d.bloodVerified && (d.donations>=3) ? '⭐' : d.bloodVerified ? '🩸' : (d.phone ? '📱' : '❓');
  const demo = d.demo ? '<span style="font-size:9px;background:var(--purple);color:#fff;padding:1px 6px;border-radius:6px;margin-left:4px">ডেমো</span>' : '';
  return '<div class="d-card" data-donor-id="' + d.id + '">' +
    '<div class="d-av ' + (d.verified?'online':'') + '">' + initial + '</div>' +
    '<div class="d-info">' +
      '<div class="d-nm">' + escapeHtml(d.name||'Anonymous') + ' <span style="font-size:11px">' + trustIcon + '</span>' + demo + '</div>' +
      '<div class="d-meta"><span>📍 ' + escapeHtml(d.upazila||d.district||'—') + '</span><span>🩸 ' + toBn(d.donations||0) + ' দান</span></div>' +
    '</div>' +
    '<div class="d-bdg">' + d.blood + '</div>' +
  '</div>';
}

window.debouncedRenderDonors = debounce(renderDonors, 200);
window.quickFilter = function(type){
  activeQuickFilter = type;
  document.querySelectorAll('.sg-chip').forEach(c => c.classList.toggle('active', false));
  if(event && event.target && event.target.classList) event.target.classList.add('active');
  renderDonors();
};
window.switchTab = function(name, btn){
  document.querySelectorAll('#screen-search .tab').forEach(t => t.classList.remove('active'));
  if(btn) btn.classList.add('active');
  ['tabList','tabMap','tabCompat','tabAI'].forEach(id => { const el = $(id); if(el) el.style.display = 'none'; });
  const target = $('tab' + name.charAt(0).toUpperCase() + name.slice(1));
  if(target) target.style.display = 'block';
  if(name === 'compat') populateCompatGroups();
};

window.searchFromHome = function(){
  if(selectedBloodHome) selectedBloodSearch = selectedBloodHome;
  const hd = $('homeDistrict'), hu = $('homeUpazila');
  const sd = $('searchDistrict'), su = $('searchUpazila');
  if(sd && hd) sd.value = hd.value;
  if(su && hu) su.value = hu.value;
  window.showScreen('search');
  setTimeout(() => {
    document.querySelectorAll('#searchBloodGrid .b-chip').forEach(ch => { ch.classList.toggle('active', ch.dataset.blood === selectedBloodSearch); });
    renderDonors();
  }, 100);
};

window.checkEligibility = function(){
  const w = parseFloat(($('regWeight')||{}).value || 0);
  const msg = $('eligibilityMsg');
  if(!msg) return;
  if(!w){ msg.innerHTML = ''; return; }
  if(w < 50) msg.innerHTML = '<div class="fraud-alert">⚠️ রক্তদানের জন্য কমপক্ষে ৫০ কেজি ওজন দরকার।</div>';
  else msg.innerHTML = '<div style="color:var(--green);font-size:12.5px;padding:8px;background:var(--green-l);border-radius:8px">✅ আপনি ওজনের শর্ত পূরণ করেছেন</div>';
};

// একটা ছবিকে ছোট করে JPEG base64 (data URL) বানায়, 400KB সীমার নিচে রাখার জন্য।
function compressImageToBase64(file, maxWidth, quality){
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('read failed'));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('image load failed'));
      img.onload = () => {
        const scale = Math.min(1, maxWidth / img.width);
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w; canvas.height = h;
        canvas.getContext('2d').drawImage(img, 0, 0, w, h);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}
window.compressImageToBase64 = compressImageToBase64;

// register স্ক্রিন দেখানোর সময় verified phone থাকলে বসিয়ে দেয়, না থাকলে verify বক্স দেখায়।
function renderRegisterScreen(){
  const session = (typeof window.v7GetSession === 'function') ? window.v7GetSession() : null;
  const phoneEl = $('regPhone'), verifyBox = $('regVerifyBox');
  if(session && session.phone){
    if(phoneEl) phoneEl.value = session.phone;
    if(verifyBox) verifyBox.style.display = 'none';
  } else {
    if(phoneEl) phoneEl.value = '';
    if(verifyBox) verifyBox.style.display = '';
  }
}
window.renderRegisterScreen = renderRegisterScreen;

window.registerDonor = async function(){
  const name = ($('regName')||{}).value.trim();
  const blood = ($('regBlood')||{}).value;
  const district = ($('regDistrict')||{}).value;
  const upazila = ($('regUpazila')||{}).value;
  const lastDate = ($('regLastDate')||{}).value;
  const age = parseInt(($('regAge')||{}).value || 0, 10);
  const weight = parseFloat(($('regWeight')||{}).value || 0);
  const gender = ($('regGender')||{}).value;
  const emergency = ($('regEmergency')||{}).value;
  const consent = ($('regConsent')||{}).checked;
  const nidNumber = (($('regNid')||{}).value || '').trim();
  const nidFileInput = $('regNidPhoto');

  if(!window.v7IsSignedIn || !window.v7IsSignedIn()){
    toast('আগে মোবাইল নম্বর OTP দিয়ে verify করুন', 'error');
    if(typeof window.v7StartPhoneAuth === 'function') window.v7StartPhoneAuth();
    return;
  }
  if(!name || !blood || !district || !upazila){ toast('সব * চিহ্নিত ঘর পূরণ করুন', 'error'); return; }
  if(age && (age < 18 || age > 60)){ toast('বয়স ১৮-৬০ এর মধ্যে', 'error'); return; }
  if(weight && weight < 50){ toast('ওজন ৫০+ কেজি দরকার', 'error'); return; }
  if(!consent){ toast('সম্মতি চেকবক্সে টিক দিন', 'error'); return; }
  if(!/^(\d{10}|\d{13}|\d{17})$/.test(nidNumber)){ toast('সঠিক NID নম্বর দিন (১০/১৩/১৭ ডিজিট)', 'error'); return; }

  const existing = lsGet(KEYS.PROFILE, null);
  let nidPhoto = null;
  if(nidFileInput && nidFileInput.files && nidFileInput.files[0]){
    try{ nidPhoto = await compressImageToBase64(nidFileInput.files[0], 900, 0.6); }
    catch(e){ toast('ছবি প্রসেস করতে সমস্যা হয়েছে', 'error'); return; }
  } else if(existing && existing.nidPhoto){
    nidPhoto = existing.nidPhoto; // প্রোফাইল edit করার সময় আগের ছবিই থাকবে
  } else {
    toast('NID-এর ছবি আপলোড করুন', 'error'); return;
  }

  try{
    const res = await window.BloodAPI.registerDonor({
      name, blood, district, upazila, age: age || null, weight: weight || null,
      gender: gender || null, emergency: emergency || 'yes', lastDonation: lastDate || null,
      nidNumber, nidPhoto
    });
    if(!res.success){ toast('❌ ' + (res.message || 'ব্যর্থ'), 'error'); return; }

    const session = window.v7GetSession ? window.v7GetSession() : null;
    const donor = {
      id: res.id || (existing && existing.id), name, phone: session ? session.phone : (existing && existing.phone),
      blood, district, upazila, lastDonation: lastDate || null, age: age || null, weight: weight || null,
      gender: gender || null, emergency: emergency || 'yes', nidPhoto,
      verified: false, bloodVerified: false,
      donations: (existing && existing.donations) || 0, responseRate: (existing && existing.responseRate) || 0,
      createdAt: (existing && existing.createdAt) || Date.now(), availability: null
    };
    const idx = window.donors.findIndex(d => d.id === donor.id);
    if(idx === -1) window.donors.push(donor); else window.donors[idx] = donor;
    saveDonors();
    lsSet(KEYS.PROFILE, donor);
    if(session){ session.hasProfile = true; lsSet('v7Session', session); }
    toast(res.status === 'updated' ? '✅ প্রোফাইল আপডেট হয়েছে — পুনরায় review-এ পাঠানো হয়েছে' : '🎉 রেজিস্ট্রেশন সফল! Admin verify করলে সবাই দেখতে পাবে', 'success');
    showScreen('profile');
    renderDonors();
    syncServerDonors();
  }catch(e){ toast('❌ নেটওয়ার্ক সমস্যা', 'error'); }
};

window.submitRequest = async function(){
  const patient = ($('reqPatient')||{}).value.trim();
  const blood = ($('reqBlood')||{}).value;
  const district = ($('reqDistrict')||{}).value;
  const upazila = ($('reqUpazila')||{}).value;
  const hospital = ($('reqHospital')||{}).value.trim();
  const bags = parseInt(($('reqBags')||{}).value || 1, 10);
  const urgency = ($('reqUrgency')||{}).value;
  const age = ($('reqAge')||{}).value;
  const phone = ($('reqPhone')||{}).value.trim();
  const note = ($('reqNote')||{}).value.trim();
  if(!patient || !blood || !district || !upazila || !hospital || !phone){ toast('সব * পূরণ করুন', 'error'); return; }
  if(!/^01\d{9}$/.test(phone)){ toast('সঠিক মোবাইল দিন', 'error'); return; }
  const last = lsGet('lastRequestAt', 0);
  if(Date.now() - last < 60000){ toast('৬০ সেকেন্ড পর চেষ্টা করুন', 'error'); return; }
  lsSet('lastRequestAt', Date.now());
  const payload = { patient, blood, district, upazila, hospital, bags, urgency, age: age || null, phone, note };
  let reqId = 'r' + Date.now();
  try{
    if(window.BloodAPI){
      const res = await window.BloodAPI.createRequest(payload);
      if(res && res.success && res.id) reqId = res.id;
    }
  }catch(e){ /* offline — local-only request চলবে */ }
  const req = Object.assign({ id: reqId, at: Date.now(), status: 'active' }, payload);
  window.requests.unshift(req);
  saveRequests();
  if(window.FIREBASE_ENABLED && window.firebase){
    try{ firebase.firestore().collection('requests').doc(req.id).set(req); }catch(e){}
  }
  addNotification({ title: '🚨 নতুন অনুরোধ', body: blood + ' · ' + upazila + ', ' + district, icon: '🚨', at: Date.now() });
  toast('✅ অনুরোধ পাঠানো হয়েছে!', 'success');
  showScreen('requests-list');
  ['reqPatient','reqHospital','reqPhone','reqNote','reqAge'].forEach(id => { const el=$(id); if(el) el.value=''; });
  const rb = $('reqBags'); if(rb) rb.value = 1;
};

function renderRequestsList(){
  const c = $('requestList');
  const cnt = $('reqListCount');
  if(cnt) cnt.textContent = toBn(window.requests.length) + ' টি';
  if(!c) return;
  if(!window.requests.length){
    c.innerHTML = '<div class="empty"><div class="empty-ic">📋</div><div class="empty-t">কোনো সক্রিয় অনুরোধ নেই</div></div>';
    return;
  }
  c.innerHTML = window.requests.map(r =>
    '<div class="card" data-req-id="' + r.id + '">' +
      '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;margin-bottom:8px">' +
        '<div>' +
          '<div style="font-weight:700;font-size:15px">' + escapeHtml(r.patient) + '</div>' +
          '<div style="font-size:12px;color:var(--text2);margin-top:2px">📍 ' + escapeHtml(r.upazila) + ', ' + escapeHtml(r.district) + '<br>🏥 ' + escapeHtml(r.hospital) + '</div>' +
        '</div>' +
        '<span class="badge badge-r" style="font-size:14px;padding:6px 12px">' + r.blood + '</span>' +
      '</div>' +
      '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px">' +
        '<span class="badge ' + (r.urgency==='critical'?'badge-r':r.urgency==='urgent'?'badge-gold':'badge-bl') + '">' + (r.urgency==='critical'?'🚨 অতি জরুরি':r.urgency==='urgent'?'⚠️ জরুরি':'সাধারণ') + '</span>' +
        '<span class="badge badge-bl">📦 ' + toBn(r.bags) + ' ব্যাগ</span>' +
        '<span class="badge badge-g">🕒 ' + timeAgo(r.at) + '</span>' +
      '</div>' +
      '<div style="display:flex;gap:8px">' +
        '<a href="tel:' + r.phone + '" class="btn btn-p btn-sm" style="flex:1;text-align:center;text-decoration:none">📞 কল করুন</a>' +
        '<button class="btn btn-o btn-sm" style="flex:1" onclick="v5ShowAcceptModal({id:\'' + r.id + '\',patient:\'' + escapeHtml(r.patient) + '\',blood:\'' + r.blood + '\',upazila:\'' + escapeHtml(r.upazila) + '\',district:\'' + escapeHtml(r.district) + '\',hospital:\'' + escapeHtml(r.hospital) + '\',urgency:\'' + r.urgency + '\'})">✅ আমি দিতে পারব</button>' +
      '</div>' +
    '</div>'
  ).join('');
}

function timeAgo(t){
  const s = Math.floor((Date.now() - t) / 1000);
  if(s < 60) return toBn(s) + ' সেকেন্ড আগে';
  if(s < 3600) return toBn(Math.floor(s/60)) + ' মিনিট আগে';
  if(s < 86400) return toBn(Math.floor(s/3600)) + ' ঘণ্টা আগে';
  return toBn(Math.floor(s/86400)) + ' দিন আগে';
}
window.timeAgo = timeAgo;

function addNotification(n){
  window.notifications.unshift(n);
  if(window.notifications.length > 50) window.notifications.length = 50;
  saveNotifs();
  updateNotifBadge();
}
window.addNotification = addNotification;

function updateNotifBadge(){
  const badge = $('notifCount');
  const unread = window.notifications.filter(n => !n.read).length;
  if(badge){
    badge.textContent = toBn(unread);
    badge.style.display = unread > 0 ? 'flex' : 'none';
  }
}

function renderNotifications(){
  const c = $('notifList');
  if(!c) return;
  if(!window.notifications.length){
    c.innerHTML = '<div class="empty"><div class="empty-ic">🔔</div><div class="empty-t">কোনো নোটিফিকেশন নেই</div></div>';
    return;
  }
  c.innerHTML = window.notifications.map(n =>
    '<div class="ni ' + (n.read?'':'unread') + '">' +
      '<div class="n-ic">' + (n.icon || '🔔') + '</div>' +
      '<div class="n-c">' +
        '<div class="n-t">' + escapeHtml(n.title) + '</div>' +
        '<div class="n-d">' + escapeHtml(n.body||'') + '</div>' +
        '<div class="n-time">' + timeAgo(n.at) + '</div>' +
      '</div>' +
    '</div>'
  ).join('');
  window.notifications.forEach(n => n.read = true);
  saveNotifs();
  updateNotifBadge();
}

window.clearNotifs = function(){
  if(!confirm('সব নোটিফিকেশন মুছে ফেলবেন?')) return;
  window.notifications = [];
  saveNotifs();
  renderNotifications();
  updateNotifBadge();
  toast('✅ মুছে ফেলা হয়েছে', 'success');
};

function renderProfile(){
  const p = lsGet(KEYS.PROFILE, null);
  if(!p){
    const av = $('profileAvatar'); if(av) av.textContent = '?';
    const nm = $('profileName'); if(nm) nm.textContent = 'অতিথি ব্যবহারকারী';
    ['pDonations','pPoints','pBadges','pLives'].forEach(id => { const el=$(id); if(el) el.textContent='০'; });
    return;
  }
  const init = (p.name||'?').trim().charAt(0).toUpperCase();
  const av = $('profileAvatar'); if(av) av.textContent = init;
  const nm = $('profileName'); if(nm) nm.textContent = p.name;
  const loc = $('profileLocation'); if(loc) loc.textContent = '📍 ' + (p.upazila||'') + ', ' + (p.district||'');
  const donations = p.donations || 0;
  const points = donations * 50;
  const lives = Math.max(1, Math.floor(donations * 1.5));
  const pd = $('pDonations'); if(pd) pd.textContent = toBn(donations);
  const pp = $('pPoints'); if(pp) pp.textContent = toBn(points);
  const pb = $('pBadges'); if(pb) pb.textContent = toBn(Math.min(8, donations));
  const pl = $('pLives'); if(pl) pl.textContent = toBn(lives);
  const td = $('tDonations'); if(td) td.textContent = toBn(donations);
  const tl = $('tLives'); if(tl) tl.textContent = toBn(lives);
  const rc = $('referralCode'); if(rc) rc.value = (p.id || 'DONOR').toUpperCase();
  const bi = $('myBloodInfo');
  if(bi){ bi.innerHTML = '<div style="display:flex;align-items:center;gap:12px"><span class="badge badge-r" style="font-size:18px;padding:10px 18px">' + p.blood + '</span><div><div style="font-weight:600">' + escapeHtml(p.name) + '</div><div style="font-size:12px;color:var(--text2)">' + escapeHtml(p.phone) + '</div></div></div>'; }
}

function renderEventsList(){
  const c = $('eventsList');
  if(!c) return;
  const events = [
    {m:'SEP', d:'24', n:'বরিশাল ব্লাড ড্রাইভ ২০২৫', desc:'সকাল ৯টা - বিকেল ৫টা · বরিশাল সদর', tag:'🩸 ওপেন'},
    {m:'OCT', d:'05', n:'পটুয়াখালী ডোনার মিট', desc:'সকাল ১০টা · পটুয়াখালী মেডিকেল', tag:'📢 রেজিস্ট্রেশন চলছে'},
    {m:'OCT', d:'15', n:'বিশ্ব রক্তদাতা দিবস ক্যাম্প', desc:'সারাদিন · ভোলা সদর', tag:'🎗️ ফ্রি চেকআপ'}
  ];
  c.innerHTML = events.map(e => '<div class="event-card"><div class="event-date"><div class="m">' + e.m + '</div><div class="d">' + toBn(e.d) + '</div></div><div class="event-info"><div class="event-name">' + e.n + '</div><div class="event-meta">' + e.desc + '</div><span class="event-tag">' + e.tag + '</span></div></div>').join('');
}

function renderStatsScreen(){
  const d = window.donors, r = window.requests;
  const sd = $('sTotalDonors'); if(sd) sd.textContent = toBn(d.length);
  const st = $('sTotalDonations'); if(st) st.textContent = toBn(d.reduce((s,x)=>s+(x.donations||0),0));
  const sl = $('sLives'); if(sl) sl.textContent = toBn(Math.max(1, Math.floor(d.reduce((s,x)=>s+(x.donations||0),0) * 1.5)));
  const sa = $('sActive'); if(sa) sa.textContent = toBn(r.filter(x=>x.status!=='completed').length);
  const gs = $('groupStats');
  if(gs){
    const byG = {};
    d.forEach(x => byG[x.blood] = (byG[x.blood]||0)+1);
    const max = Math.max(1, ...Object.values(byG));
    gs.innerHTML = Object.entries(byG).sort((a,b)=>b[1]-a[1]).map(([g,n]) =>
      '<div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">' +
        '<span style="width:44px;font-weight:700;color:var(--red)">' + g + '</span>' +
        '<div style="flex:1;height:20px;background:var(--bg);border-radius:6px;overflow:hidden"><div style="width:' + (n/max)*100 + '%;height:100%;background:linear-gradient(90deg,var(--red),var(--red-d));border-radius:6px"></div></div>' +
        '<span style="min-width:40px;text-align:right;font-weight:700">' + toBn(n) + '</span>' +
      '</div>'
    ).join('') || '<p style="font-size:13px;color:var(--text2)">কোনো ডেটা নেই</p>';
  }
  const ds = $('districtStats');
  if(ds){
    const byD = {};
    d.forEach(x => byD[x.district] = (byD[x.district]||0)+1);
    ds.innerHTML = Object.entries(byD).sort((a,b)=>b[1]-a[1]).map(([dd,n]) =>
      '<div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--bd);font-size:13px"><span>' + dd + '</span><strong>' + toBn(n) + '</strong></div>'
    ).join('') || '<p style="font-size:13px;color:var(--text2)">কোনো ডেটা নেই</p>';
  }
  const pv = $('predVal'); if(pv) pv.textContent = toBn(Math.max(1, Math.round(r.length * 1.3)));
}

window.switchHealthTab = function(tab, btn){
  document.querySelectorAll('#screen-health .tab').forEach(t => t.classList.remove('active'));
  if(btn) btn.classList.add('active');
  ['tips','pre','post','bmi'].forEach(t => { const el = $('htab-' + t); if(el) el.style.display = t === tab ? 'block' : 'none'; });
};

function renderHealthTips(){
  const c = $('healthTipsList');
  if(!c) return;
  c.innerHTML = HEALTH_TIPS.map(t => '<div class="health-tip"><div class="ht-title">' + t.t + '</div><div class="ht-desc">' + t.d + '</div></div>').join('');
  const pre = $('preChecklist');
  if(pre){
    const items = ['ভালো করে খাবার খান','পর্যাপ্ত পানি পান করুন','৭-৮ ঘণ্টা ঘুম','পরিচয়পত্র নিন','আগের রক্তদানের তারিখ জানুন','ভয়েস ড্রিংক/কফি এড়িয়ে চলুন','ধূমপান করবেন না','আরামদায়ক পোশাক পরুন'];
    pre.innerHTML = items.map(it => '<div class="check-item" onclick="this.classList.toggle(\'checked\')"><div class="check-box">✓</div><div class="check-text">' + it + '</div></div>').join('');
  }
  const post = $('postCare');
  if(post){
    post.innerHTML = '<div class="health-tip"><div class="ht-title">🩹 রক্তদানের পর ১০ মিনিট</div><div class="ht-desc">বসে বিশ্রাম নিন, হালকা স্ন্যাকস খান।</div></div>' +
      '<div class="health-tip"><div class="ht-title">💧 পরের ২৪ ঘণ্টা</div><div class="ht-desc">প্রচুর পানি পান করুন, ভারী কাজ এড়িয়ে চলুন।</div></div>' +
      '<div class="health-tip"><div class="ht-title">🍎 পরের সপ্তাহ</div><div class="ht-desc">আয়রন-সমৃদ্ধ খাবার (সবুজ শাক, ডাল, মাংস) খান।</div></div>';
  }
}

window.calcBMI = function(){
  const w = parseFloat(($('bmiWeight')||{}).value||0);
  const h = parseFloat(($('bmiHeight')||{}).value||0) / 100;
  const c = $('bmiResult');
  if(!c) return;
  if(!w || !h){ c.innerHTML = ''; return; }
  const bmi = (w / (h*h)).toFixed(1);
  let cls = 'normal', cat = 'স্বাভাবিক';
  if(bmi < 18.5){ cls = 'under'; cat = 'কম'; }
  else if(bmi >= 30){ cls = 'obese'; cat = 'স্থূলতা'; }
  else if(bmi >= 25){ cls = 'over'; cat = 'বেশি'; }
  c.innerHTML = '<div class="bmi-result ' + cls + '"><div class="bmi-val">' + bmi + '</div><div class="bmi-cat">' + cat + '</div></div>';
};

function populateCompatGroups(){
  const sel = $('compatGroup');
  if(!sel || sel.options.length > 1) return;
  BLOOD_GROUPS.forEach(g => { const o = document.createElement('option'); o.value = g; o.textContent = g; sel.appendChild(o); });
}

window.showCompatibility = function(){
  const g = ($('compatGroup')||{}).value;
  const c = $('compatResult');
  if(!c) return;
  if(!g){ c.innerHTML = ''; return; }
  const compat = {
    'A+': {give:['A+','AB+'], receive:['A+','A-','O+','O-']},
    'A-': {give:['A+','A-','AB+','AB-'], receive:['A-','O-']},
    'B+': {give:['B+','AB+'], receive:['B+','B-','O+','O-']},
    'B-': {give:['B+','B-','AB+','AB-'], receive:['B-','O-']},
    'O+': {give:['O+','A+','B+','AB+'], receive:['O+','O-']},
    'O-': {give:['সব গ্রুপ'], receive:['O-']},
    'AB+': {give:['AB+'], receive:['সব গ্রুপ']},
    'AB-': {give:['AB+','AB-'], receive:['AB-','A-','B-','O-']}
  };
  const m = compat[g];
  if(!m) return;
  c.innerHTML = '<div class="cg"><div class="cc"><h4>❤️ রক্ত দিতে পারবেন</h4><div class="cchips">' + m.give.map(x=>'<span class="cchip g">' + x + '</span>').join('') + '</div></div><div class="cc"><h4>💉 রক্ত নিতে পারবেন</h4><div class="cchips">' + m.receive.map(x=>'<span class="cchip">' + x + '</span>').join('') + '</div></div></div>';
};

window.runAIMatch = function(){
  const c = $('aiResult');
  if(!c) return;
  c.innerHTML = '<div style="text-align:center;padding:20px;color:var(--text2)">🤖 বিশ্লেষণ চলছে...</div>';
  setTimeout(() => {
    const ranked = window.v5RankDonors ? window.v5RankDonors(selectedBloodSearch) : window.donors.map(d=>({d,score:50,km:null}));
    if(!ranked.length){ c.innerHTML = '<div class="empty">কোনো ডোনার পাওয়া যায়নি</div>'; return; }
    c.innerHTML = '<div class="st" style="margin-top:6px"><span class="em">✨</span> শীর্ষ ম্যাচ</div>' + ranked.slice(0, 8).map((r,i) =>
      '<div class="d-card"><div class="lr" style="width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:700;background:' + (i===0?'linear-gradient(135deg,#FFD700,#F9A825)':'var(--bg)') + ';color:' + (i===0?'#fff':'var(--text2)') + '">' + toBn(i+1) + '</div><div class="d-info"><div class="d-nm">' + escapeHtml(r.d.name) + ' ' + (r.d.bloodVerified?'🩸':'') + '</div><div class="d-meta"><span>📍 ' + r.d.upazila + '</span>' + (r.km!=null?'<span>📍 ' + (window.v5FmtDist ? window.v5FmtDist(r.km):'') + '</span>':'') + '</div></div><div class="d-bdg" style="background:linear-gradient(135deg,#4CAF50,#2E7D32);color:#fff">' + toBn(r.score) + '</div></div>'
    ).join('');
  }, 800);
};

window.exportData = function(){
  const data = { donors: window.donors, requests: window.requests, profile: lsGet(KEYS.PROFILE, null), notifications: window.notifications, exportedAt: new Date().toISOString() };
  const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'barishal-rokto-backup-' + Date.now() + '.json'; a.click();
  toast('📤 ডাউনলোড শুরু', 'success');
};

window.importData = function(){
  const inp = document.createElement('input');
  inp.type = 'file'; inp.accept = '.json';
  inp.onchange = e => {
    const f = e.target.files[0]; if(!f) return;
    const r = new FileReader();
    r.onload = () => {
      try{
        const d = JSON.parse(r.result);
        if(d.donors) { window.donors = d.donors; saveDonors(); }
        if(d.requests) { window.requests = d.requests; saveRequests(); }
        if(d.profile) lsSet(KEYS.PROFILE, d.profile);
        if(d.notifications) { window.notifications = d.notifications; saveNotifs(); }
        toast('✅ ইমপোর্ট সফল', 'success');
        renderDonors(); renderProfile();
      }catch(err){ toast('❌ ভুল ফাইল', 'error'); }
    };
    r.readAsText(f);
  };
  inp.click();
};

window.clearAllData = function(){
  if(!confirm('সব ডেটা মুছে ফেলবেন?')) return;
  Object.values(KEYS).forEach(k => localStorage.removeItem(k));
  toast('🗑️ মুছে ফেলা হয়েছে', 'success');
  setTimeout(() => location.reload(), 800);
};

window.copyReferral = function(){
  const inp = $('referralCode');
  if(!inp || !inp.value){ toast('আগে রেজিস্ট্রেশন করুন', 'error'); return; }
  try{ navigator.clipboard.writeText(inp.value); toast('📋 কপি হয়েছে', 'success'); }
  catch(e){ prompt('কপি করুন:', inp.value); }
};

window.downloadCert = function(){
  const p = lsGet(KEYS.PROFILE, null);
  if(!p){ toast('আগে রেজিস্ট্রেশন করুন', 'error'); return; }
  const cert = '🎗️ রক্তদান সার্টিফিকেট\n\n' + p.name + '\n' + p.blood + '\n' + p.upazila + ', ' + p.district + '\n\nমোট দান: ' + (p.donations||0) + '\n\nবরিশাল রক্তদাতা v9.0';
  const blob = new Blob([cert], {type:'text/plain'});
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'certificate-' + (p.name||'donor') + '.txt'; a.click();
  toast('🏆 সার্টিফিকেট ডাউনলোড', 'success');
};

window.requestNotifPerm = function(){
  if(!('Notification' in window)){ toast('ব্রাউজার সাপোর্ট নেই', 'error'); return; }
  Notification.requestPermission().then(p => {
    const st = $('notifStatus');
    if(st) st.textContent = p === 'granted' ? '✅ চালু' : '❌ বন্ধ';
    toast(p === 'granted' ? '🔔 চালু' : '❌ অনুমতি দেওয়া হয়নি', p === 'granted' ? 'success' : 'error');
  });
};

window.requestUserLocation = function(){
  if(!navigator.geolocation){ toast('লোকেশন সাপোর্ট নেই', 'error'); return; }
  navigator.geolocation.getCurrentPosition(
    pos => {
      lsSet('userGeo', {lat:pos.coords.latitude, lng:pos.coords.longitude, at:Date.now()});
      const st = $('locStatus'); if(st) st.textContent = '✅ সেট';
      toast('📍 লোকেশন সেট হয়েছে', 'success');
      renderDonors();
    },
    () => toast('লোকেশন অনুমতি প্রয়োজন', 'error'),
    {enableHighAccuracy:true, timeout:10000}
  );
};

window.enableShakeSOS = function(){
  const st = $('shakeStatus');
  if(st && st.textContent === 'চালু'){ st.textContent = 'বন্ধ'; window.__shakeEnabled = false; toast('📳 বন্ধ', 'success'); return; }
  if(st) st.textContent = 'চালু';
  window.__shakeEnabled = true;
  toast('📳 চালু — ফোন ঝাঁকিয়ে SOS', 'success');
  if(window.__shakeListener) window.removeEventListener('devicemotion', window.__shakeListener);
  let lastX=0, lastY=0, lastZ=0, lastShake=0;
  window.__shakeListener = e => {
    const acc = e.accelerationIncludingGravity; if(!acc) return;
    const dx = Math.abs(acc.x - lastX), dy = Math.abs(acc.y - lastY), dz = Math.abs(acc.z - lastZ);
    lastX = acc.x; lastY = acc.y; lastZ = acc.z;
    if(dx+dy+dz > 40 && Date.now() - lastShake > 2000){
      lastShake = Date.now();
      if(navigator.vibrate) navigator.vibrate([200,100,200]);
      toast('🚨 SOS শেক!', 'error');
      showScreen('request');
    }
  };
  window.addEventListener('devicemotion', window.__shakeListener);
};

window.showPrivacyPolicy = function(){
  openModal('<div class="mhdr"><div class="mt">📄 প্রাইভেসি পলিসি</div><button class="cb" onclick="closeModal()">✕</button></div>' +
    '<div style="font-size:13px;line-height:1.7;color:var(--text2)">' +
      '<p><strong style="color:var(--text)">আমরা কী তথ্য সংগ্রহ করি:</strong></p>' +
      '<ul style="margin-left:20px;margin-top:6px"><li>নাম, ফোন, রক্তের গ্রুপ, এলাকা</li><li>শেষ রক্তদানের তারিখ</li><li>বয়স ও ওজন (ঐচ্ছিক)</li></ul>' +
      '<p style="margin-top:12px"><strong style="color:var(--text)">কারা দেখতে পাবে:</strong></p>' +
      '<ul style="margin-left:20px;margin-top:6px"><li>নাম, গ্রুপ, এলাকা — সবাই</li><li>ফোন — শুধু রক্তের অনুরোধের সময়</li><li>সঠিক লোকেশন — কখনো নয়</li></ul>' +
      '<button class="btn btn-p" style="margin-top:16px" onclick="closeModal()">বুঝেছি</button>' +
    '</div>');
};

window.showSyncInfo = function(){
  const dot = document.querySelector('.sync-dot');
  const isOnline = dot && dot.classList.contains('online');
  toast(isOnline ? '☁️ ক্লাউড সিঙ্ক চালু' : '📱 লোকাল মোডে চলছে', isOnline ? 'success' : '');
};

window.toggleChat = function(){
  const w = $('chatWindow');
  if(!w) return;
  w.classList.toggle('show');
  const badge = $('chatBadge');
  if(badge) badge.style.display = 'none';
  if(w.classList.contains('show') && !w.dataset.greeted){
    w.dataset.greeted = '1';
    setTimeout(() => {
      const body = $('chatBody');
      if(body && !body.children.length){
        body.innerHTML = '<div class="chat-m bot">👋 আসসালামু আলাইকুম! আমি রক্ত সহায়ক AI। জিজ্ঞেস করুন যেমন:\n\n• "রক্ত দিতে কত দিন লাগে?"\n• "O+ বরিশাল সদরে ২ ব্যাগ"\n• "AB- কোথায় পাওয়া যাবে?"</div>';
      }
    }, 300);
  }
};

window.quickChat = function(text){
  const inp = $('chatInput');
  if(!inp) return;
  inp.value = text;
  if(window.v5SendChat) window.v5SendChat();
};

window.closeVoiceModal = function(){
  const m = $('voiceModal');
  if(m) m.classList.remove('show');
};

function applySavedPrefs(){
  const theme = lsGet(KEYS.THEME, 'light');
  document.body.setAttribute('data-theme', theme);
  const tb = $('themeBtn'); if(tb) tb.textContent = theme === 'dark' ? '☀️' : '🌙';
  const ts = $('themeStatus'); if(ts) ts.textContent = theme === 'dark' ? 'চালু' : 'বন্ধ';
  const lang = lsGet(KEYS.LANG, 'bn');
  document.body.setAttribute('data-lang', lang);
  const lb = $('langBtn'); if(lb) lb.textContent = lang === 'bn' ? 'EN' : 'বাং';
  const ls = $('langStatus'); if(ls) ls.textContent = lang === 'bn' ? 'বাংলা' : 'English';
}

function updateStats(){
  const sd = $('statDonors'); if(sd) sd.textContent = toBn(window.donors.length);
  const sr = $('statRequests'); if(sr) sr.textContent = toBn(window.requests.length);
  const sa = $('statActive'); if(sa) sa.textContent = toBn(window.donors.filter(d=>{ const av = d.availability; return av && av.status === 'available'; }).length);
  const sl = $('statLives'); if(sl) sl.textContent = toBn(window.donors.reduce((s,d)=>s+(d.donations||0),0));
}

function renderTopDonors(){
  const c = $('topDonors');
  if(!c) return;
  const top = window.donors.slice().sort((a,b)=>(b.donations||0)-(a.donations||0)).slice(0,3);
  if(!top.length){ c.innerHTML = '<div style="font-size:12.5px;color:var(--text2);padding:8px">এখনো কোনো ডোনার নেই</div>'; return; }
  c.innerHTML = top.map((d,i) => '<div class="lr"><div class="lrank t' + (i+1) + '">' + toBn(i+1) + '</div><div class="d-info"><div class="d-nm">' + escapeHtml(d.name) + '</div><div class="d-meta"><span>' + d.blood + '</span><span>🩸 ' + toBn(d.donations||0) + ' দান</span></div></div></div>').join('');
}

function renderLiveFeed(){
  const c = $('liveFeed');
  const cnt = $('liveCount');
  if(cnt) cnt.textContent = toBn(window.requests.length);
  if(!c) return;
  if(!window.requests.length){
    c.innerHTML = '<div class="fi"><div class="fd pulse"></div><div class="ft">অ্যাপ চালু আছে — অপেক্ষা করছি</div><div class="ftime">এখন</div></div>';
    return;
  }
  c.innerHTML = window.requests.slice(0,5).map(r => '<div class="fi"><div class="fd pulse"></div><div class="ft"><strong>' + escapeHtml(r.upazila||'') + '</strong> — ' + r.blood + ' রক্ত প্রয়োজন</div><div class="ftime">' + timeAgo(r.at) + '</div></div>').join('');
}

function renderHealthTipWidget(){
  const c = $('healthTip');
  if(!c) return;
  const t = HEALTH_TIPS[Math.floor(Math.random() * HEALTH_TIPS.length)];
  c.innerHTML = '<div class="health-tip"><div class="ht-title">' + t.t + '</div><div class="ht-desc">' + t.d + '</div></div>';
}

function renderUpcomingEvents(){
  const c = $('upcomingEvents');
  if(!c) return;
  c.innerHTML = '<div class="event-card"><div class="event-date"><div class="m">SEP</div><div class="d">' + toBn(24) + '</div></div><div class="event-info"><div class="event-name">বরিশাল ব্লাড ড্রাইভ</div><div class="event-meta">সকাল ৯টা · বরিশাল সদর</div><span class="event-tag">🩸 ওপেন</span></div></div>';
}

function handleUrlParams(){
  const params = new URLSearchParams(location.search);
  const action = params.get('action');
  const blood = params.get('blood');
  if(action === 'request'){
    setTimeout(() => { showScreen('request'); populateBloodDropdowns(); if(blood && $('reqBlood')) $('reqBlood').value = blood; }, 500);
  }
  if(action === 'register'){
    setTimeout(() => { showScreen('register'); populateBloodDropdowns(); if(blood && $('regBlood')) $('regBlood').value = blood; }, 500);
  }
  if(action === 'search' && blood){
    setTimeout(() => { showScreen('search'); document.querySelectorAll('#searchBloodGrid .b-chip').forEach(chip => { if(chip.dataset.blood === blood) chip.click(); }); }, 500);
  }
}

function init(){
  try{
    applySavedPrefs();
    loadData();
    renderBloodGrids();
    populateDistricts();
    populateBloodDropdowns();
    renderDonors();
    renderTopDonors();
    renderLiveFeed();
    renderHealthTipWidget();
    renderUpcomingEvents();
    renderHealthTips();
    updateStats();
    updateNotifBadge();
    syncServerDonors();
    syncServerRequests();
    console.log('%c✅ app.js loaded — বরিশাল রক্তদাতা v9.0','color:#C62828;font-weight:700');
    console.log('   Donors:', window.donors.length, '| Requests:', window.requests.length);
  }catch(e){
    console.error('❌ app.js init error:', e);
  } finally {
    setTimeout(hideSplash, 1200);
    setTimeout(handleUrlParams, 800);
  }
}

if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
else init();
setTimeout(hideSplash, 4000);

window.BLOOD_GROUPS = BLOOD_GROUPS;
window.DISTRICTS = DISTRICTS;
window.UPZ_TO_DIST = UPZ_TO_DIST;

})();

/* ═══════════════════════════════════════════════════════════
   MODULE 2: v5.js — Availability, GPS, Match Score, Trust
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
const VERSION = '5.0';
const LS = { AVAIL:'donorAvailability', GEO:'userGeo', GEO_PROMPTED:'geoPromptedAt' };
const UPAZILA_GEO = {
'বরিশাল সদর':[22.7010,90.3535],'বাকেরগঞ্জ':[22.5478,90.3372],'বাবুগঞ্জ':[22.8139,90.3186],
'উজিরপুর':[22.7805,90.2408],'বানারীপাড়া':[22.7844,90.1766],'গৌরনদী':[22.9700,90.2107],
'আগৈলঝাড়া':[22.9988,90.1521],'মেহেন্দিগঞ্জ':[22.8280,90.5291],'মুলাদী':[22.9456,90.4228],
'হিজলা':[22.9315,90.5717],'পটুয়াখালী সদর':[22.3596,90.3297],'বাউফল':[22.4211,90.5609],
'দশমিনা':[22.2166,90.5614],'গলাচিপা':[22.1535,90.4244],'কলাপাড়া':[21.9833,90.2436],
'মির্জাগঞ্জ':[22.2716,90.1723],'রাঙ্গাবালী':[21.8500,90.3833],'দুমকি':[22.4561,90.3277],
'ভোলা সদর':[22.6833,90.6500],'বোরহানউদ্দিন':[22.5000,90.7333],'চরফ্যাশন':[22.1833,90.7667],
'দৌলতখান':[22.6167,90.7000],'লালমোহন':[22.2833,90.7333],'মনপুরা':[22.3167,90.9333],
'তজুমদ্দিন':[22.4667,90.8333],'পিরোজপুর সদর':[22.5833,89.9750],'ভান্ডারিয়া':[22.5000,89.9833],
'কাউখালী':[22.6333,90.0500],'মঠবাড়িয়া':[22.2833,89.9500],'নাজিরপুর':[22.7333,89.9500],
'নেছারাবাদ':[22.7333,90.0833],'জিয়ানগর':[22.4167,89.9333],'বরগুনা সদর':[22.1500,90.1167],
'আমতলী':[22.1333,90.2333],'বামনা':[22.2333,90.0833],'বেতাগী':[22.2333,90.0000],
'পাথরঘাটা':[22.0333,89.9833],'তালতলী':[22.0667,90.1500],'ঝালকাঠি সদর':[22.6406,90.2000],
'কাঠালিয়া':[22.4167,90.1333],'নলছিটি':[22.6167,90.2833],'রাজাপুর':[22.5167,90.1167]
};
const DISTRICT_HQ = {'বরিশাল':'বরিশাল সদর','পটুয়াখালী':'পটুয়াখালী সদর','ভোলা':'ভোলা সদর','পিরোজপুর':'পিরোজপুর সদর','বরগুনা':'বরগুনা সদর','ঝালকাঠি':'ঝালকাঠি সদর'};

const $ = id => document.getElementById(id);
const toBn = n => String(n||0).replace(/[0-9]/g, d => '০১২৩৪৫৬৭৮৯'[+d]);
const clamp = (n,a,b) => Math.max(a, Math.min(b, n));
function lsGet(k,fb){ try{const r=localStorage.getItem(k); return r==null?fb:JSON.parse(r);}catch(e){return fb;} }
function lsSet(k,v){ try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} }
function haversineKm(lat1,lon1,lat2,lon2){ const R=6371,T=x=>x*Math.PI/180; const dLat=T(lat2-lat1), dLon=T(lon2-lon1); const a=Math.sin(dLat/2)**2 + Math.cos(T(lat1))*Math.cos(T(lat2))*Math.sin(dLon/2)**2; return 2*R*Math.asin(Math.sqrt(a)); }
function daysSince(iso){ if(!iso) return Infinity; const t=new Date(iso).getTime(); return isNaN(t)?Infinity:(Date.now()-t)/86400000; }
function fmtDist(km){ if(km==null||!isFinite(km)) return ''; if(km<1) return Math.round(km*1000)+' মি'; if(km<10) return km.toFixed(1)+' কিমি'; return Math.round(km)+' কিমি'; }
function toast(m,t){ if(typeof window.toast==='function'){ try{window.toast(m,t);return;}catch(e){} } console.log('[v5]',m); }
function haptic(ms){ if(navigator.vibrate) try{navigator.vibrate(ms||15);}catch(e){} }

const AVAIL_META = {
  available:{dot:'#4CAF50',label:'🟢 Available'},
  maybe:{dot:'#FFB300',label:'🟡 Maybe'},
  unavailable:{dot:'#E53935',label:'🔴 Unavailable'},
  expired:{dot:'#9AA0A6',label:'⚪ Expired'},
  unset:{dot:'#9AA0A6',label:'সেট করুন'}
};
function getMyAvailability(){ const a = lsGet(LS.AVAIL,null); if(!a) return {status:'unset'}; if(a.until && Date.now()>a.until) return {status:'expired',until:a.until}; return a; }
function setMyAvailability(status, hours){ const until = hours ? Date.now() + hours*3600*1000 : null; lsSet(LS.AVAIL, {status,until,at:Date.now()}); try{ if(typeof window.cloudSetAvailability==='function') window.cloudSetAvailability({status,until}); }catch(e){} renderAvailBtn(); updateHomePulse(); try{ if(typeof window.renderDonors==='function') window.renderDonors(); }catch(e){} toast(AVAIL_META[status]?.label||'Saved','success'); haptic(20); }
function renderAvailBtn(){ const a = getMyAvailability(), m = AVAIL_META[a.status]||AVAIL_META.unset; const d=$('availDot'), l=$('availLabel'); if(d) d.style.background=m.dot; if(l) l.textContent=m.label; }
window.openAvailabilitySheet = function(){
  const cur = getMyAvailability().status;
  const row=(cls,s,t,sb)=>'<button class="avail-sheet-row ' + cls + '" onclick="__v5PickAvail(\'' + s + '\')" style="' + (cur===s?'border-color:var(--red);':'') + '"><span class="dot"></span><span class="lbl"><b>' + t + '</b><span>' + sb + '</span></span>' + (cur===s?'<span style="color:var(--red);font-weight:700">✓</span>':'') + '</button>';
  const html = '<div class="mhdr"><div class="mt">আপনার Availability</div><button class="cb" onclick="closeModal()">✕</button></div><p style="font-size:13px;color:var(--text2);margin-bottom:14px;line-height:1.5">এই মুহূর্তে আপনি রক্ত দিতে পারবেন কিনা জানালে, জরুরি অনুরোধ এলে আপনাকে <b>সবার আগে</b> দেখানো হবে।</p>' + row('a','available','🟢 Available','২৪ ঘণ্টার জন্য') + row('m','maybe','🟡 Maybe','৬ ঘণ্টার জন্য') + row('u','unavailable','🔴 Unavailable','২৪ ঘণ্টার জন্য');
  if(typeof window.openModal==='function') window.openModal(html);
};
window.__v5PickAvail = function(status){ const hours = status==='maybe'?6:24; setMyAvailability(status,hours); if(typeof window.closeModal==='function') window.closeModal(); };
window.getDonorAvailability = function(d){ if(!d) return {status:'unset'}; if(d.availability && d.availability.status) return d.availability; return {status:'unset'}; };
window.getAvailability = getMyAvailability;

function getMyGeo(){ return lsGet(LS.GEO,null); }
function requestMyGeo(force){
  return new Promise(resolve=>{
    if(!navigator.geolocation){ resolve(null); return; }
    const cached = getMyGeo();
    if(cached && !force && Date.now()-cached.at<5*60*1000){ resolve(cached); return; }
    navigator.geolocation.getCurrentPosition(
      pos=>{ const g={lat:pos.coords.latitude,lng:pos.coords.longitude,acc:pos.coords.accuracy,at:Date.now()}; lsSet(LS.GEO,g); updateGeoStatus(); updateHomePulse(); try{ if(typeof window.renderDonors==='function') window.renderDonors(); }catch(e){} resolve(g); },
      err=> resolve(null),
      {enableHighAccuracy:true,timeout:10000,maximumAge:60000}
    );
  });
}
window.v5RequestGeo = requestMyGeo;
function updateGeoStatus(){ const el=$('locStatus'); if(!el) return; const g=getMyGeo(); el.textContent = g ? '✔ ' + g.lat.toFixed(3) + ',' + g.lng.toFixed(3) : 'অনুমতি দিন'; }
function donorLatLng(d){ if(d && d.lat!=null && d.lng!=null) return [d.lat,d.lng]; const u=(d && d.upazila)||''; if(UPAZILA_GEO[u]) return UPAZILA_GEO[u]; const dist=(d && d.district)||''; const hq=DISTRICT_HQ[dist]; if(hq && UPAZILA_GEO[hq]) return UPAZILA_GEO[hq]; return null; }
function donorDistanceKm(d){ const me=getMyGeo(), loc=donorLatLng(d); if(!me||!loc) return null; return haversineKm(me.lat, me.lng, loc[0], loc[1]); }
window.v5DonorDistanceKm = donorDistanceKm;
window.v5FmtDist = fmtDist;

function getTrustLevel(d){ if(!d) return {level:0,icon:'❓',label:'Unverified',cls:'badge-r'}; const phone=!!d.phone, bloodV=!!d.bloodVerified; const trusted = phone && bloodV && (d.donations||0)>=3 && (d.responseRate||0)>=0.6; if(trusted) return {level:3,icon:'⭐',label:'Trusted Donor',cls:'badge-gold'}; if(bloodV) return {level:2,icon:'🩸',label:'Blood Verified',cls:'badge-g'}; if(phone) return {level:1,icon:'📱',label:'Mobile Verified',cls:'badge-bl'}; return {level:0,icon:'❓',label:'Unverified',cls:'badge-r'}; }
window.getTrustLevel = getTrustLevel;

function calcMatchScore(d, opts){ opts = opts||{}; let s=0; if(!opts.blood || d.blood===opts.blood) s+=30; else s+=12; if(d.verified || d.bloodVerified) s+=15; const av = window.getDonorAvailability(d).status; if(av==='available') s+=20; else if(av==='maybe') s+=10; else s+=4; const km = donorDistanceKm(d); if(km==null) s+=10; else s += km<2?20:km<5?16:km<10?12:km<25?7:3; const dd = daysSince(d.lastDonation); if(dd>=90) s+=10; else if(dd>=60) s+=5; if((d.responseRate||0)>=0.6) s+=5; return clamp(Math.round(s),0,100); }
window.calcMatchScore = calcMatchScore;

function decorateDonorCard(cardEl){
  if(!cardEl || cardEl.dataset.v5Decorated) return;
  let donor = null;
  const id = cardEl.dataset.donorId || cardEl.dataset.id;
  if(id && Array.isArray(window.donors)) donor = window.donors.find(x => String(x.id)===String(id));
  if(!donor){
    const nameEl = cardEl.querySelector('.d-nm');
    if(nameEl && Array.isArray(window.donors)){ const nm = (nameEl.textContent||'').trim().split('\n')[0].split('📱')[0].trim(); donor = window.donors.find(x => x.name === nm) || null; }
  }
  if(donor){
    const km = donorDistanceKm(donor);
    if(km!=null){ const meta = cardEl.querySelector('.d-meta'); if(meta && !meta.querySelector('.dist-inline')){ const sp = document.createElement('span'); sp.className='dist-inline'; sp.innerHTML='📍 ' + fmtDist(km); meta.appendChild(sp); } }
    const t = getTrustLevel(donor);
    const nm = cardEl.querySelector('.d-nm');
    if(nm && !nm.querySelector('.trust-stack')){ const sp = document.createElement('span'); sp.className='trust-stack'; sp.title=t.label; sp.textContent=t.icon; nm.appendChild(sp); }
    const av = window.getDonorAvailability(donor);
    if(av.status && av.status!=='unset'){ const meta = cardEl.querySelector('.d-meta'); if(meta && !meta.querySelector('.avail-pill')){ const cls = av.status==='available'?'a':av.status==='maybe'?'m':'u'; const sp = document.createElement('span'); sp.className='avail-pill ' + cls; sp.textContent = av.status==='available'?'🟢 Available':av.status==='maybe'?'🟡 Maybe':'🔴 ব্যস্ত'; meta.appendChild(sp); } }
    const prof = readMyProfile();
    const score = calcMatchScore(donor, {blood: prof && prof.blood});
    const avEl = cardEl.querySelector('.d-av');
    if(avEl && !avEl.querySelector('.ms-ring')){
      const r=14, c=2*Math.PI*r, dash=(score/100)*c;
      const cls = score>=75?'hi':score>=50?'md':'lo';
      const ring = document.createElement('div');
      ring.className = 'ms-ring ' + cls;
      ring.title = 'Match Score: ' + score + '/100';
      ring.innerHTML = '<svg viewBox="0 0 46 46"><circle class="ms-bg" cx="23" cy="23" r="' + r + '"/><circle class="ms-fg" cx="23" cy="23" r="' + r + '" stroke-dasharray="' + dash + ' ' + c + '"/></svg><span class="ms-t">' + toBn(score) + '</span>';
      avEl.appendChild(ring);
    }
  }
  cardEl.dataset.v5Decorated = '1';
}

function observeDonorLists(){
  ['donorResults','topDonors','liveFeed','requestList'].forEach(id=>{
    const root = $(id); if(!root) return;
    root.querySelectorAll('.d-card').forEach(decorateDonorCard);
    const mo = new MutationObserver(muts=>{
      muts.forEach(m=>{
        m.addedNodes && m.addedNodes.forEach(n=>{
          if(n.nodeType!==1) return;
          if(n.classList && n.classList.contains('d-card')) decorateDonorCard(n);
          if(n.querySelectorAll) n.querySelectorAll('.d-card').forEach(decorateDonorCard);
        });
      });
    });
    mo.observe(root, {childList:true,subtree:true});
  });
}

function readMyProfile(){ const keys = ['barishalProfile','myProfile','currentUser','user']; for(const k of keys){ const v = lsGet(k,null); if(v && typeof v==='object' && (v.blood||v.name)) return v; } return null; }
function getDonors(){ return Array.isArray(window.donors)?window.donors:[]; }
function getRequests(){ return Array.isArray(window.requests)?window.requests:[]; }
function setTxt(id,v){ const el=$(id); if(el) el.textContent=v; }

function updateHomePulse(){
  const donors=getDonors(), reqs=getRequests();
  const avail = donors.filter(d=>window.getDonorAvailability(d).status==='available').length;
  const oMinus = reqs.filter(r=>r.blood==='O-' && r.status!=='done').length || donors.filter(d=>d.blood==='O-').length;
  const emerg = reqs.filter(r=>r.status!=='done' && (r.urgency==='critical'||r.urgency==='urgent')).length;
  const today = new Date().toISOString().slice(0,10);
  const todayDon = donors.filter(d=>String(d.lastDonation||'').slice(0,10)===today).length;
  setTxt('pAvail', toBn(avail)); setTxt('pOminus', toBn(oMinus)); setTxt('pEmerg', toBn(emerg)); setTxt('pToday', toBn(todayDon));
  setTxt('qaAvailCount', toBn(avail) + ' জন এখন প্রস্তুত');
}

window.v5RankDonors = function(blood, opts){ opts = opts||{}; const list = getDonors().slice(); const withScore = list.map(d=>{ const km = donorDistanceKm(d); const score = calcMatchScore(d, {blood, distanceKm:km}); return {d,score,km}; }); withScore.sort((a,b)=> b.score-a.score || (a.km??1e9)-(b.km??1e9)); return withScore; };

window.showAvailableNow = function(){
  if(typeof window.showScreen==='function') window.showScreen('search');
  setTimeout(()=>{
    const chips = document.querySelectorAll('#screen-search .sg-chip');
    let done = false;
    chips.forEach(c=>{ if(/অনলাইন|Available/i.test(c.textContent)){ c.click(); done=true; }});
    if(!done && typeof window.quickFilter==='function') window.quickFilter('online');
  }, 80);
};

let nearestOn = false;
window.toggleSortNearest = function(){
  nearestOn = !nearestOn;
  const btn = $('nearestBtn'); if(btn) btn.classList.toggle('active', nearestOn);
  if(nearestOn){ requestMyGeo().then(g=>{ if(!g){ toast('লোকেশন অনুমতি দরকার','error'); nearestOn=false; if(btn) btn.classList.remove('active'); return; } applyNearestSort(); }); }
  else { try{ if(typeof window.renderDonors==='function') window.renderDonors(); }catch(e){} }
};
function applyNearestSort(){
  try{ if(typeof window.renderDonors==='function') window.renderDonors(); }catch(e){}
  setTimeout(()=>{
    const root = $('donorResults'); if(!root) return;
    const cards = Array.from(root.querySelectorAll('.d-card'));
    if(cards.length<2) return;
    const donors = getDonors(); const me = getMyGeo(); if(!me) return;
    cards.sort((a,b)=>{ const na = (a.querySelector('.d-nm')||{}).textContent || ''; const nb = (b.querySelector('.d-nm')||{}).textContent || ''; const da = donors.find(x=> na.includes(x.name)) || {}; const db = donors.find(x=> nb.includes(x.name)) || {}; const ka = donorDistanceKm(da) ?? 1e9; const kb = donorDistanceKm(db) ?? 1e9; return ka-kb; });
    cards.forEach(c=> root.appendChild(c));
  }, 60);
}

const BLOOD_TOKENS = { 'A+':['a+','এ পজিটিভ','এ+'],'A-':['a-','এ নেগেটিভ','এ-'],'B+':['b+','বি পজিটিভ','বি+'],'B-':['b-','বি নেগেটিভ','বি-'],'O+':['o+','ও পজিটিভ','ও+'],'O-':['o-','ও নেগেটিভ','ও-'],'AB+':['ab+','এবি পজিটিভ','এবি+'],'AB-':['ab-','এবি নেগেটিভ','এবি-'] };
function parseAssistantText(text){
  const t = (text||'').toLowerCase();
  const out = {blood:null,upazila:null,district:null,urgency:null,bags:null,intent:'unknown'};
  for(const [grp,aliases] of Object.entries(BLOOD_TOKENS)){ if(aliases.some(a=>t.includes(a))){ out.blood = grp; break; } }
  for(const u of Object.keys(UPAZILA_GEO)){ if(t.includes(u.toLowerCase())||t.includes(u)){ out.upazila=u; break; } }
  if(!out.upazila){ for(const d of Object.keys(DISTRICT_HQ)){ if(t.includes(d.toLowerCase())||t.includes(d)){ out.district=d; break; } } }
  if(/অতি জরুরি|critical|সিজিয়র/.test(t)) out.urgency='critical';
  else if(/জরুরি|ইমার্জেন্সি|emergency|দ্রুত|এখনই/.test(t)) out.urgency='urgent';
  const bm = t.match(/(\d+)\s*(ব্যাগ|bag)/i);
  if(bm) out.bags = parseInt(bm[1],10);
  if(out.blood && (out.upazila||out.district)) out.intent='request';
  else if(/খুঁজ|খোঁজ|খুজ|দাতা|donor|search/.test(t)) out.intent='search';
  else if(/দিতে পার|available|আছি|ready/.test(t)) out.intent='availability';
  return out;
}
window.v5ParseAssistantText = parseAssistantText;

window.v5ApplyAssistant = function(text){
  const p = parseAssistantText(text);
  const upazilaToDist = { 'বাকেরগঞ্জ':'বরিশাল','বাবুগঞ্জ':'বরিশাল','উজিরপুর':'বরিশাল','বানারীপাড়া':'বরিশাল','গৌরনদী':'বরিশাল','আগৈলঝাড়া':'বরিশাল','মেহেন্দিগঞ্জ':'বরিশাল','মুলাদী':'বরিশাল','হিজলা':'বরিশাল','বরিশাল সদর':'বরিশাল','বাউফল':'পটুয়াখালী','দশমিনা':'পটুয়াখালী','গলাচিপা':'পটুয়াখালী','কলাপাড়া':'পটুয়াখালী','মির্জাগঞ্জ':'পটুয়াখালী','রাঙ্গাবালী':'পটুয়াখালী','দুমকি':'পটুয়াখালী','পটুয়াখালী সদর':'পটুয়াখালী','ভোলা সদর':'ভোলা','বোরহানউদ্দিন':'ভোলা','চরফ্যাশন':'ভোলা','লালমোহন':'ভোলা','পিরোজপুর সদর':'পিরোজপুর','ভান্ডারিয়া':'পিরোজপুর','মঠবাড়িয়া':'পিরোজপুর','বরগুনা সদর':'বরগুনা','আমতলী':'বরগুনা','পাথরঘাটা':'বরগুনা','ঝালকাঠি সদর':'ঝালকাঠি','নলছিটি':'ঝালকাঠি','রাজাপুর':'ঝালকাঠি','কাঠালিয়া':'ঝালকাঠি' };
  if(p.intent==='search'){
    if(typeof window.showScreen==='function') window.showScreen('search');
    setTimeout(()=>{ if(p.blood){ document.querySelectorAll('#screen-search .b-chip').forEach(c=>{ if(c.textContent.replace(/\s.*/,'').toUpperCase()===p.blood) c.click(); }); } if(p.district){ const sel = $('searchDistrict'); if(sel) for(const o of sel.options){ if(o.value===p.district||o.text===p.district){ sel.value=o.value; sel.dispatchEvent(new Event('change')); break; } } } }, 100);
    return true;
  }
  if(p.intent==='request'){
    if(typeof window.showScreen==='function') window.showScreen('request');
    setTimeout(()=>{
      if(p.blood && $('reqBlood')) $('reqBlood').value = p.blood;
      const dist = p.district || upazilaToDist[p.upazila];
      if(dist && $('reqDistrict')){ const dsel = $('reqDistrict'); for(const o of dsel.options){ if(o.value===dist||o.text===dist){ dsel.value=o.value; break; } } dsel.dispatchEvent(new Event('change')); }
      if(p.upazila){ setTimeout(()=>{ const usel = $('reqUpazila'); if(usel) for(const o of usel.options){ if(o.value===p.upazila||o.text===p.upazila){ usel.value=o.value; break; } } }, 80); }
      if(p.bags && $('reqBags')) $('reqBags').value = p.bags;
      if(p.urgency && $('reqUrgency')) $('reqUrgency').value = p.urgency;
      toast('✨ ফর্ম অটো-পূরণ হয়েছে','success');
    }, 120);
    return true;
  }
  return false;
};

window.v5ShowGeoConsent = function(){ const last = lsGet(LS.GEO_PROMPTED, 0); if(Date.now()-last < 7*86400000) return; const html = '<div class="geo-prompt"><div class="ic">📍</div><h3>নিকটতম ডোনার খুঁজুন</h3><p>আপনার লোকেশন ব্যবহার করে কাছের রক্তদাতাদের দেখাতে চাই। আমরা শুধু দূরত্ব হিসাব করি।</p><button class="btn btn-p" onclick="v5GrantGeo()">✔ অনুমতি দিন</button><button class="btn btn-gh" style="margin-top:8px" onclick="v5DenyGeo()">পরে</button></div>'; if(typeof window.openModal==='function') window.openModal(html); lsSet(LS.GEO_PROMPTED, Date.now()); };
window.v5GrantGeo = function(){ if(typeof window.closeModal==='function') window.closeModal(); requestMyGeo(true).then(g=>{ if(g) toast('📍 লোকেশন সেট হয়েছে','success'); }); };
window.v5DenyGeo = function(){ if(typeof window.closeModal==='function') window.closeModal(); };

function updateGreeting(){ const h = new Date().getHours(); const g = h<12?'শুভ সকাল 👋':h<17?'শুভ দুপুর ☀️':h<20?'শুভ সন্ধ্যা 🌆':'শুভ রাত্রি 🌙'; const el = $('heroGreeting'); if(el) el.textContent = g; }

function patchRenderDonors(){
  if(typeof window.renderDonors !== 'function') return;
  if(window.renderDonors.__v5Patched) return;
  const orig = window.renderDonors;
  const wrapped = function(){
    const r = orig.apply(this, arguments);
    setTimeout(()=>{ const root = $('donorResults'); if(root) root.querySelectorAll('.d-card').forEach(decorateDonorCard); updateHomePulse(); }, 0);
    return r;
  };
  wrapped.__v5Patched = true;
  window.renderDonors = wrapped;
  window.debouncedRenderDonors = window.debouncedRenderDonors || wrapped;
}

function boot(){
  setTimeout(()=>{ updateGreeting(); renderAvailBtn(); updateGeoStatus(); updateHomePulse(); observeDonorLists(); patchRenderDonors(); setTimeout(()=>{ try{ window.v5ShowGeoConsent(); }catch(e){} }, 4000); }, 1200);
  setInterval(()=>{ const before = getMyAvailability().status; renderAvailBtn(); updateHomePulse(); if(before==='available' && getMyAvailability().status==='expired'){ toast('⏱️ আপনার Availability শেষ হয়েছে','error'); } }, 30000);
  window.addEventListener('online', updateHomePulse);
  window.addEventListener('offline', updateHomePulse);
  console.log('%c✅ v5.js loaded','color:#C62828;font-weight:700');
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', boot); else boot();
window.V5 = { version: VERSION, getMyAvailability, setMyAvailability, requestMyGeo, calcMatchScore, getTrustLevel, donorDistanceKm };
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 3: v5-map.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
const UPAZILA_GEO = {
'বরিশাল সদর':[22.7010,90.3535],'বাকেরগঞ্জ':[22.5478,90.3372],'বাবুগঞ্জ':[22.8139,90.3186],
'উজিরপুর':[22.7805,90.2408],'বানারীপাড়া':[22.7844,90.1766],'গৌরনদী':[22.9700,90.2107],
'আগৈলঝাড়া':[22.9988,90.1521],'মেহেন্দিগঞ্জ':[22.8280,90.5291],'মুলাদী':[22.9456,90.4228],
'হিজলা':[22.9315,90.5717],'পটুয়াখালী সদর':[22.3596,90.3297],'বাউফল':[22.4211,90.5609],
'দশমিনা':[22.2166,90.5614],'গলাচিপা':[22.1535,90.4244],'কলাপাড়া':[21.9833,90.2436],
'মির্জাগঞ্জ':[22.2716,90.1723],'ভোলা সদর':[22.6833,90.6500],'বোরহানউদ্দিন':[22.5000,90.7333],
'চরফ্যাশন':[22.1833,90.7667],'লালমোহন':[22.2833,90.7333],'পিরোজপুর সদর':[22.5833,89.9750],
'ভান্ডারিয়া':[22.5000,89.9833],'মঠবাড়িয়া':[22.2833,89.9500],'নাজিরপুর':[22.7333,89.9500],
'বরগুনা সদর':[22.1500,90.1167],'আমতলী':[22.1333,90.2333],'পাথরঘাটা':[22.0333,89.9833],
'ঝালকাঠি সদর':[22.6406,90.2000],'কাঠালিয়া':[22.4167,90.1333],'নলছিটি':[22.6167,90.2833]
};
let map=null, activeFilter='all';
function loadLeaflet(){ if(window.L) return Promise.resolve(); return new Promise(res=>{ const css = document.createElement('link'); css.rel='stylesheet'; css.href='https://unpkg.com/leaflet@1.9.4/dist/leaflet.css'; document.head.appendChild(css); const s = document.createElement('script'); s.src='https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; s.onload=res; document.head.appendChild(s); }); }
function demandLevel(u){ const reqs = (window.requests||[]).filter(r=>r.upazila===u && r.status!=='completed'); const donors = (window.donors||[]).filter(d=>d.upazila===u); const ratio = donors.length ? reqs.length/donors.length : reqs.length; if(ratio>0.5||reqs.length>=3) return 'hi'; if(ratio>0.15||reqs.length>=1) return 'md'; return 'lo'; }
function colorFor(l){ return l==='hi'?'#E53935':l==='md'?'#FFB300':'#43A047'; }
async function initMap(){
  const container = document.getElementById('demandMapEl'); if(!container) return;
  await loadLeaflet();
  if(map){ map.remove(); map=null; }
  map = L.map(container,{zoomControl:true,attributionControl:false}).setView([22.5,90.35],8);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:18,opacity:0.9}).addTo(map);
  const geo = JSON.parse(localStorage.getItem('userGeo')||'null');
  if(geo && geo.lat){ L.circleMarker([geo.lat,geo.lng],{radius:8,color:'#1565C0',fillColor:'#1565C0',fillOpacity:.9}).addTo(map).bindPopup('📍 আপনি এখানে'); }
  Object.keys(UPAZILA_GEO).forEach(u=>{
    if(activeFilter!=='all'){ const has = (window.donors||[]).some(d=>d.upazila===u && d.blood===activeFilter); if(!has) return; }
    const [lat,lng] = UPAZILA_GEO[u];
    const reqs = (window.requests||[]).filter(r=>r.upazila===u && r.status!=='completed').length;
    const donors = (window.donors||[]).filter(d=>d.upazila===u).length;
    const lvl = demandLevel(u);
    L.circleMarker([lat,lng],{radius:8+Math.min(reqs*3,20),color:colorFor(lvl),fillColor:colorFor(lvl),fillOpacity:.55,weight:2}).addTo(map).bindPopup('<div style="font-family:\'Hind Siliguri\',sans-serif;min-width:150px"><b style="font-size:14px">' + u + '</b><br>🩸 অনুরোধ: <b>' + reqs + '</b><br>👥 ডোনার: <b>' + donors + '</b></div>');
  });
}
window.v5InitDemandMap = initMap;
window.v5FilterMap = function(blood, btn){ activeFilter = blood; document.querySelectorAll('.map-filter button').forEach(b=>b.classList.remove('active')); if(btn) btn.classList.add('active'); initMap(); };
const origSwitch = window.switchTab;
if(typeof origSwitch==='function'){
  window.switchTab = function(name, btn){ const r = origSwitch.apply(this, arguments); if(name==='map') setTimeout(initMap, 200); return r; };
}
console.log('%c✅ #10 Demand Map ready','color:#4CAF50');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 4: v5-voice.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
let recog=null, listening=false;
function isSupported(){ return !!(window.SpeechRecognition || window.webkitSpeechRecognition); }
window.v5OpenVoiceAssistant = function(){
  if(!isSupported()){ if(typeof toast==='function') toast('ভয়েস সাপোর্ট নেই (Chrome দিন)','error'); return; }
  const html = '<div class="va-panel show" id="vaPanel"><button class="va-close" onclick="v5CloseVoice()">✕</button><div class="va-orb" id="vaOrb">🎤</div><div class="va-title" id="vaTitle">বলুন...</div><div class="va-transcript" id="vaTranscript">যেমন: "ও পজিটিভ বরিশাল সদরে দুই ব্যাগ"</div><div class="va-hint">🎙️ বাংলায় কথা বলুন</div></div>';
  document.body.insertAdjacentHTML('beforeend', html);
  startListening();
};
window.v5CloseVoice = function(){ listening=false; if(recog){ try{recog.stop();}catch(e){} recog=null; } const el=document.getElementById('vaPanel'); if(el) el.remove(); };
function setTx(t){ const el=document.getElementById('vaTranscript'); if(el) el.textContent=t; }
function setTitle(t){ const el=document.getElementById('vaTitle'); if(el) el.textContent=t; }
function startListening(){
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  recog = new SR(); recog.lang = 'bn-BD'; recog.continuous = false; recog.interimResults = true; recog.maxAlternatives = 1;
  const panel = document.getElementById('vaPanel'); if(panel) panel.classList.add('listening');
  recog.onresult = e=>{
    let interim='', final='';
    for(let i=e.resultIndex; i<e.results.length; i++){ const t = e.results[i][0].transcript; if(e.results[i].isFinal) final += t; else interim += t; }
    setTx(final||interim);
    if(final){ setTitle('বুঝেছি ✔'); setTimeout(()=>handleCommand(final), 500); }
  };
  recog.onerror = e=>{ if(e.error==='not-allowed') setTitle('মাইক্রোফোন অনুমতি দিন'); else setTitle('আবার চেষ্টা করুন'); };
  recog.onend = ()=>{ if(listening){ try{recog.start();}catch(e){} } };
  listening = true;
  try{ recog.start(); }catch(e){}
}
function handleCommand(text){
  if(!text) return;
  const parse = window.v5ParseAssistantText ? window.v5ParseAssistantText(text) : null;
  if(parse && (parse.blood||parse.upazila||parse.district)){
    window.v5CloseVoice();
    if(typeof window.v5ApplyAssistant==='function') window.v5ApplyAssistant(text);
    if(typeof toast==='function') toast('🎯 ' + (parse.blood||'') + ' ' + (parse.upazila||parse.district||'') + ' — খুঁজছি','success');
  } else {
    setTitle('আবার বলুন');
    setTx('বুঝতে পারিনি। উদাহরণ: "ও পজিটিভ বরিশাল সদর"');
    setTimeout(()=>{ setTitle('বলুন...'); startListening(); }, 2000);
  }
}
window.openVoiceModal = window.v5OpenVoiceAssistant;
console.log('%c✅ #12 Voice Assistant ready','color:#4CAF50');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 5: v5-qr.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
function loadQR(){ if(window.QRCode) return Promise.resolve(); return new Promise(res=>{ const s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/qrcode@1.5.3/build/qrcode.min.js'; s.onload = res; document.head.appendChild(s); }); }
function profileUrl(){ const p = JSON.parse(localStorage.getItem('barishalProfile')||'null'); if(!p || !p.name) return null; const id = p.id || p.phone || encodeURIComponent(p.name); const base = location.origin + location.pathname.replace(/\/[^/]*$/, '/'); return base + 'public.html?id=' + encodeURIComponent(id); }
window.v5RenderQR = async function(){
  const url = profileUrl();
  const box = document.getElementById('qrCode'); if(!box) return;
  if(!url){ box.innerHTML = '<span style="color:var(--text2);font-size:13px">রেজিস্ট্রেশন করলে QR কোড দেখা যাবে</span>'; return; }
  await loadQR();
  box.innerHTML = '<canvas id="qrCanvas"></canvas>';
  window.QRCode.toCanvas(document.getElementById('qrCanvas'), url, {width:200, margin:1, color:{dark:'#1A1A1A',light:'#FFFFFF'}});
  const info = document.createElement('div');
  info.style.cssText = 'font-size:10.5px;color:var(--text2);margin-top:8px;word-break:break-all';
  info.textContent = url;
  box.appendChild(info);
};
window.v5ShareQR = async function(){
  const url = profileUrl();
  if(!url){ if(typeof toast==='function') toast('আগে রেজিস্ট্রেশন করুন','error'); return; }
  const shareData = {title:'বরিশাল রক্তদাতা — আমার প্রোফাইল', text:'QR স্ক্যান করে দেখুন', url};
  if(navigator.share){ try{ await navigator.share(shareData); }catch(e){} }
  else { try{ await navigator.clipboard.writeText(url); if(typeof toast==='function') toast('🔗 লিংক কপি হয়েছে','success'); } catch(e){ prompt('কপি করুন:', url); } }
};
window.shareProfile = window.v5ShareQR;
const origShowScreen = window.showScreen;
if(typeof origShowScreen==='function'){
  window.showScreen = function(name){ const r = origShowScreen.apply(this, arguments); if(name==='profile') setTimeout(()=>window.v5RenderQR(), 200); return r; };
}
console.log('%c✅ #13 QR Profile ready','color:#4CAF50');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 6: v5-privacy.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
const KEY = 'privacySettings';
const DEFAULT = {phone:'verified', location:'approx', profile:'public', availability:'all', showInSearch:true, allowNotif:true};
function get(){ return Object.assign({}, DEFAULT, JSON.parse(localStorage.getItem(KEY)||'{}')); }
function set(k,v){ const s=get(); s[k]=v; localStorage.setItem(KEY, JSON.stringify(s)); if(typeof toast==='function') toast('✅ সংরক্ষিত','success'); }
window.getPrivacy = get;
window.showPrivacyCenter = function(){
  const s = get();
  const sel = (val, opts) => opts.map(([v,l])=>'<option value="' + v + '" ' + (val===v?'selected':'') + '>' + l + '</option>').join('');
  const html = '<div class="mhdr"><div class="mt">🔐 Privacy Center</div><button class="cb" onclick="closeModal()">✕</button></div>' +
    '<p style="font-size:12.5px;color:var(--text2);margin-bottom:12px;line-height:1.6">আপনি ঠিক করবেন কে আপনার কোন তথ্য দেখবে।</p>' +
    '<div class="priv-section"><h4>📱 ফোন নম্বর</h4><div class="priv-row"><div class="lbl"><b>কারা দেখবে</b></div><select onchange="setPriv(\'phone\', this.value)">' + sel(s.phone, [['all','সবাই'],['verified','Verified ডোনার'],['request','অনুরোধের সময়'],['hidden','কেউ না']]) + '</select></div></div>' +
    '<div class="priv-section"><h4>📍 লোকেশন</h4><div class="priv-row"><div class="lbl"><b>নির্ভুলতা</b></div><select onchange="setPriv(\'location\', this.value)">' + sel(s.location, [['exact','সঠিক GPS'],['approx','শুধু উপজেলা'],['hidden','কিছুই না']]) + '</select></div></div>' +
    '<div class="priv-section"><h4>👤 প্রোফাইল</h4><div class="priv-row"><div class="lbl"><b>প্রোফাইল দেখাবে</b></div><select onchange="setPriv(\'profile\', this.value)">' + sel(s.profile, [['public','সবাই'],['limited','শুধু নাম+গ্রুপ'],['hidden','বন্ধ']]) + '</select></div></div>' +
    '<button class="btn btn-gh" style="margin-top:12px" onclick="v5ExportPrivacy()">📤 আমার ডেটা ডাউনলোড</button>' +
    '<button class="btn btn-o" style="margin-top:8px;color:var(--red);border-color:var(--red)" onclick="v5RequestDeletion()">🗑️ অ্যাকাউন্ট ডিলিট</button>';
  if(typeof openModal==='function') openModal(html);
};
window.setPriv = set;
window.v5ExportPrivacy = function(){ const data = {profile: JSON.parse(localStorage.getItem('barishalProfile')||'null'), privacy: get(), availability: JSON.parse(localStorage.getItem('donorAvailability')||'null'), geo: JSON.parse(localStorage.getItem('userGeo')||'null'), exportedAt: new Date().toISOString()}; const blob = new Blob([JSON.stringify(data,null,2)], {type:'application/json'}); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'my-data-' + Date.now() + '.json'; a.click(); if(typeof toast==='function') toast('📤 ডাউনলোড','success'); };
window.v5RequestDeletion = function(){ if(!confirm('আপনি কি নিশ্চিত?')) return; if(window.FIREBASE_ENABLED && window.firebase){ firebase.firestore().collection('deletionRequests').add({at:Date.now(), profile: JSON.parse(localStorage.getItem('barishalProfile')||'null')}); } if(typeof toast==='function') toast('✅ অনুরোধ জমা','success'); };
window.applyPrivacyFilter = function(donor, viewerRole){ const p = get(); const out = {...donor}; if(p.phone==='hidden') delete out.phone; else if(p.phone==='verified' && viewerRole!=='verified') delete out.phone; else if(p.phone==='request' && viewerRole!=='requester') delete out.phone; if(p.location==='hidden'){ delete out.lat; delete out.lng; } else if(p.location==='approx'){ if(out.lat) out.lat = Math.round(out.lat*100)/100; if(out.lng) out.lng = Math.round(out.lng*100)/100; } return out; };
console.log('%c✅ #14 Privacy Center ready','color:#4CAF50');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 7: v5-fraud.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
const FLAG_KEY = 'fraudFlags';
function getFlags(){ return JSON.parse(localStorage.getItem(FLAG_KEY)||'[]'); }
function addFlag(flag){ const arr = getFlags(); const sig = flag.type + ':' + flag.target; if(arr.some(f=> (f.type+':'+f.target)===sig && Date.now()-f.at < 86400000)) return; flag.at = Date.now(); arr.push(flag); localStorage.setItem(FLAG_KEY, JSON.stringify(arr)); if(window.FIREBASE_ENABLED && window.firebase){ try{ firebase.firestore().collection('fraudFlags').add(flag); }catch(e){} } }
window.v5GetFraudFlags = getFlags;
function checkDuplicatePhones(donors){ const seen = new Map(); (donors||[]).forEach(d=>{ if(!d.phone) return; if(seen.has(d.phone)){ addFlag({type:'duplicate_phone',target:d.phone,severity:'medium'}); } else seen.set(d.phone, d); }); }
function checkRapidRequests(reqs){ const byPhone = new Map(); const now = Date.now(); (reqs||[]).forEach(r=>{ if(!r.phone || !r.at || now-r.at > 3600000) return; const arr = byPhone.get(r.phone)||[]; arr.push(r); byPhone.set(r.phone, arr); }); byPhone.forEach((arr, phone)=>{ if(arr.length > 3){ addFlag({type:'rapid_requests',target:phone,count:arr.length,severity:'high'}); } }); }
function checkRepeatRequests(reqs){ const key = r => (r.phone||'') + '|' + (r.blood||'') + '|' + (r.upazila||'') + '|' + (r.hospital||''); const seen = new Map(); const now = Date.now(); (reqs||[]).forEach(r=>{ if(!r.at || now-r.at > 7200000) return; const k = key(r); const arr = seen.get(k)||[]; arr.push(r); seen.set(k, arr); }); seen.forEach((arr, k)=>{ if(arr.length >= 3){ addFlag({type:'repeat_request',target:k,severity:'medium'}); } }); }
function checkSuspiciousDonors(donors){ (donors||[]).forEach(d=>{ if((d.donations||0) > 20){ const days = (Date.now() - new Date(d.createdAt||0).getTime())/86400000; if(days < 30){ addFlag({type:'impossible_donations',target:d.id||d.phone,severity:'low'}); } } if(d.verified && (Date.now()-new Date(d.lastDonation||0).getTime()) > 400*86400000){ addFlag({type:'stale_verified',target:d.id||d.phone,severity:'low'}); } }); }
window.v5GetFlagsFor = function(idOrPhone){ return getFlags().filter(f=> f.target===idOrPhone); };
function scan(){ const donors = Array.isArray(window.donors)?window.donors:[]; const reqs = Array.isArray(window.requests)?window.requests:[]; checkDuplicatePhones(donors); checkRapidRequests(reqs); checkRepeatRequests(reqs); checkSuspiciousDonors(donors); }
setInterval(scan, 60000); setTimeout(scan, 5000);
console.log('%c✅ #15 Fraud Detection ready','color:#4CAF50');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 8: v5-donor-network.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
const LS = { ACC:'donorAcceptances' };
function me(){ return JSON.parse(localStorage.getItem('barishalProfile')||'null') || {}; }
function escapeHtml(s){ return String(s||'').replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
window.v5ShowAcceptModal = function(req){
  if(!req) return;
  const html = '<div class="accept-modal"><div class="ic">🚨</div><h3>' + escapeHtml(req.blood||'') + ' রক্ত প্রয়োজন</h3>' +
    '<p><b>' + escapeHtml(req.patient||'রোগী') + '</b><br>📍 ' + escapeHtml(req.upazila||req.district||'') + '<br>🏥 ' + escapeHtml(req.hospital||'') + '<br>' + (req.urgency==='critical'?'⚠️ <b style="color:var(--red)">অতি জরুরি</b>':req.urgency==='urgent'?'⚠️ জরুরি':'') + '</p>' +
    '<div class="ma" style="grid-template-columns:1fr 1fr">' +
      '<button class="ma-btn" onclick="v5DeclineRequest(\'' + req.id + '\')"><span class="ic">❌</span>পারব না</button>' +
      '<button class="ma-btn" style="background:var(--green);color:#fff;border-color:var(--green)" onclick="v5AcceptRequest(\'' + req.id + '\')"><span class="ic">✅</span>আমি দিতে পারব</button>' +
    '</div></div>';
  if(typeof openModal==='function') openModal(html);
};
window.v5AcceptRequest = async function(reqId){
  const profile = me();
  if(!profile.name){ if(typeof toast==='function') toast('আগে রেজিস্ট্রেশন করুন','error'); return; }
  const payload = {requestId:reqId, donorId: profile.id||profile.phone||'anon', donorName: profile.name, donorPhone: profile.phone||'', donorBlood: profile.blood||'', status:'accepted', at:Date.now()};
  if(window.FIREBASE_ENABLED && window.firebase){ try{ const db = firebase.firestore(); await db.collection('requests').doc(reqId).collection('responses').doc(payload.donorId).set(payload,{merge:true}); await db.collection('requests').doc(reqId).update({status:'matched',lastMatchedAt:Date.now()}); }catch(e){ console.warn(e); } }
  const arr = JSON.parse(localStorage.getItem(LS.ACC)||'[]'); arr.push(payload); localStorage.setItem(LS.ACC, JSON.stringify(arr));
  if(typeof closeModal==='function') closeModal();
  if(typeof toast==='function') toast('✅ ধন্যবাদ!','success');
  if(navigator.vibrate) navigator.vibrate([40,60,40]);
};
window.v5DeclineRequest = async function(reqId){
  const profile = me();
  const payload = {requestId:reqId, donorId: profile.id||profile.phone||'anon', donorName: profile.name||'Anonymous', status:'declined', at:Date.now()};
  if(window.FIREBASE_ENABLED && window.firebase){ try{ await firebase.firestore().collection('requests').doc(reqId).collection('responses').doc(payload.donorId).set(payload,{merge:true}); }catch(e){} }
  if(typeof closeModal==='function') closeModal();
  if(typeof toast==='function') toast('ঠিক আছে','success');
};
window.v5RenderNetworkStepper = function(req){
  const steps = [{label:'অনুরোধ',icon:'📝'},{label:'ডোনার',icon:'👥'},{label:'রক্তদান',icon:'🩸'},{label:'নিশ্চিত',icon:'✅'}];
  let current = 0; if(req.status==='matched') current=1; if(req.status==='completed') current=2; if(req.status==='confirmed') current=3;
  return '<div class="network-stepper">' + steps.map((s,i)=>{ const cls = i<current?'done':i===current?'active':''; return '<div class="step ' + cls + '"><div class="dot">' + s.icon + '</div><div>' + s.label + '</div></div>'; }).join('') + '</div>';
};
function watchIncoming(){
  if(!window.FIREBASE_ENABLED || !window.firebase) return;
  const db = firebase.firestore(); const prof = me(); if(!prof.blood) return;
  db.collection('requests').where('status','==','active').where('blood','==',prof.blood).onSnapshot(snap=>{ snap.docChanges().forEach(ch=>{ if(ch.type==='added'){ const req = Object.assign({id:ch.doc.id}, ch.doc.data()); const age = Date.now() - (req.at||0); if(age < 5*60*1000){ window.v5ShowAcceptModal(req); if(navigator.vibrate) navigator.vibrate([100,80,100]); } } }); });
}
setTimeout(watchIncoming, 3000);
if('serviceWorker' in navigator){
  navigator.serviceWorker.addEventListener('message', e=>{ const d = e.data||{}; if(d.type==='notification-action'){ if(d.action==='accept' && d.reqId) window.v5AcceptRequest(d.reqId); else if(d.reqId && typeof window.showScreen==='function') window.showScreen('requests-list'); } });
}
console.log('%c✅ #22 Donor Network ready','color:#4CAF50');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 9: v5-analytics.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
function toBn(n){ return String(n||0).replace(/[0-9]/g, x=>'০১২৩৪৫৬৭৮৯'[+x]); }
window.v5RenderAnalytics = function(){
  const c = document.getElementById('v5AnalyticsRoot'); if(!c) return;
  const donors = window.donors||[], reqs = window.requests||[];
  const byGroup = {}; donors.forEach(d=> byGroup[d.blood] = (byGroup[d.blood]||0)+1);
  const reqByGroup = {}; reqs.forEach(r=> reqByGroup[r.blood] = (reqByGroup[r.blood]||0)+1);
  const maxD = Math.max(1, ...Object.values(byGroup)); const totalD = donors.length || 1;
  const byDist = {}; donors.forEach(d=> byDist[d.district] = (byDist[d.district]||0)+1);
  const maxDist = Math.max(1, ...Object.values(byDist));
  const demandRows = Object.keys(byGroup).map(g=>{ const have = byGroup[g]||0, need = reqByGroup[g]||0; return {g,have,need,ratio: have ? need/have : need}; }).sort((a,b)=> b.ratio-a.ratio);
  c.innerHTML = '<div class="chart-box"><h4>🩸 গ্রুপ অনুযায়ী <span class="pct">' + toBn(totalD) + ' মোট</span></h4>' +
    Object.entries(byGroup).sort((a,b)=>b[1]-a[1]).map(([g,n])=>'<div class="bar-row"><div class="lbl">' + g + '</div><div class="bar"><div class="fill" style="width:' + (n/maxD)*100 + '%">' + (n>2?toBn(n):'') + '</div></div><div class="n">' + ((n/totalD)*100).toFixed(1) + '%</div></div>').join('') + '</div>' +
    '<div class="chart-box"><h4>🚨 সবচেয়ে বেশি চাহিদা</h4>' +
    demandRows.slice(0,6).map(d=>{ const pct = Math.min(100, d.ratio*50); const color = d.ratio>1?'var(--red)':d.ratio>0.5?'var(--amber)':'var(--green)'; return '<div class="bar-row"><div class="lbl">' + d.g + '</div><div class="bar"><div class="fill" style="width:' + pct + '%;background:' + color + '">' + d.need + ' চাহিদা</div></div><div class="n">' + d.have + ' আছে</div></div>'; }).join('') + '</div>' +
    '<div class="chart-box"><h4>📍 জেলা অনুযায়ী</h4>' +
    Object.entries(byDist).sort((a,b)=>b[1]-a[1]).map(([d,n])=>'<div class="bar-row"><div class="lbl" style="width:80px;font-size:11.5px">' + d + '</div><div class="bar"><div class="fill" style="width:' + (n/maxDist)*100 + '%"></div></div><div class="n">' + toBn(n) + '</div></div>').join('') + '</div>' +
    '<div class="chart-box"><h4>🔮 Predicted Demand</h4><div class="prediction"><div class="pred-val">' + toBn(Math.max(1,Math.round(reqs.length*1.3))) + '</div><div class="pred-lbl">আনুমানিক অনুরোধ (৭ দিন)</div></div></div>';
};
const origShow = window.showScreen;
if(typeof origShow==='function'){
  window.showScreen = function(name){
    const r = origShow.apply(this, arguments);
    if(name==='stats'){ setTimeout(()=>{ const sc = document.getElementById('screen-stats'); if(sc && !document.getElementById('v5AnalyticsRoot')){ sc.insertAdjacentHTML('beforeend', '<div id="v5AnalyticsRoot"></div>'); } window.v5RenderAnalytics(); }, 150); }
    return r;
  };
}
console.log('%c✅ #17 Analytics ready','color:#4CAF50');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 10: v5-chat.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
function appendBubble(who, text){ const body = document.getElementById('chatBody'); if(!body) return; const div = document.createElement('div'); div.className = 'chat-m ' + who; div.textContent = text; body.appendChild(div); body.scrollTop = body.scrollHeight; }
window.v5AppendBubble = appendBubble;
window.v5SendChat = function(){
  const inp = document.getElementById('chatInput');
  const txt = (inp && inp.value||'').trim(); if(!txt) return;
  inp.value = ''; appendBubble('user', txt);
  const p = window.v5ParseAssistantText ? window.v5ParseAssistantText(txt) : null;
  if(p && (p.intent==='request'||p.intent==='search')){
    const summary = [];
    if(p.blood) summary.push('🩸 ' + p.blood);
    if(p.upazila||p.district) summary.push('📍 ' + (p.upazila||p.district));
    if(p.bags) summary.push('📦 ' + p.bags + ' ব্যাগ');
    if(p.urgency) summary.push(p.urgency==='critical'?'🚨 অতি জরুরি':'⚠️ জরুরি');
    setTimeout(()=>{ appendBubble('bot', 'বুঝেছি! ফর্ম খুলছি:\n' + summary.join(' · ')); setTimeout(()=>{ if(typeof window.v5ApplyAssistant==='function') window.v5ApplyAssistant(txt); if(typeof toggleChat==='function') toggleChat(); }, 400); }, 300);
    return;
  }
  if(typeof window.__originalSendChat==='function'){ window.__originalSendChat(txt); return; }
  setTimeout(()=> appendBubble('bot','দুঃখিত, বুঝতে পারিনি। উদাহরণ: "আমার O+ দরকার বরিশাল সদরে ২ ব্যাগ"'), 300);
};
if(typeof window.sendChat==='function') window.__originalSendChat = window.sendChat;
window.sendChat = window.v5SendChat;
console.log('%c✅ #11 Conversational AI ready','color:#4CAF50');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 11: v5-hospital.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
window.v5ApplyHospital = function(){
  const html = '<div class="mhdr"><div class="mt">প্রতিষ্ঠান আবেদন</div><button class="cb" onclick="closeModal()">✕</button></div>' +
    '<div class="field"><label>প্রতিষ্ঠানের নাম *</label><input id="hpName"></div>' +
    '<div class="field"><label>ধরন *</label><select id="hpType"><option value="hospital">হাসপাতাল</option><option value="bloodBank">ব্লাড ব্যাংক</option><option value="clinic">ক্লিনিক</option><option value="club">রক্তদান ক্লাব</option></select></div>' +
    '<div class="field"><label>জেলা *</label><select id="hpDistrict"></select></div>' +
    '<div class="field"><label>উপজেলা *</label><select id="hpUpazila"></select></div>' +
    '<div class="field"><label>ফোন *</label><input id="hpPhone"></div>' +
    '<div class="field"><label>ঠিকানা</label><textarea id="hpAddress"></textarea></div>' +
    '<button class="btn btn-p" onclick="v5SubmitHospital()">📤 আবেদন পাঠান</button>';
  if(typeof openModal==='function') openModal(html);
  if(typeof updateUpazila==='function'){
    const d = document.getElementById('hpDistrict'); const regD = document.getElementById('regDistrict');
    if(d && regD && !d.options.length) d.innerHTML = regD.innerHTML;
    if(d) d.onchange = ()=> updateUpazila('hpDistrict','hpUpazila');
  }
};
window.v5SubmitHospital = async function(){
  const data = { name: (document.getElementById('hpName')||{}).value||'', type: (document.getElementById('hpType')||{}).value||'hospital', district: (document.getElementById('hpDistrict')||{}).value||'', upazila: (document.getElementById('hpUpazila')||{}).value||'', phone: (document.getElementById('hpPhone')||{}).value||'', address: (document.getElementById('hpAddress')||{}).value||'', verified:false, createdAt:Date.now() };
  if(!data.name || !data.phone){ if(typeof toast==='function') toast('নাম ও ফোন দিন','error'); return; }
  if(window.FIREBASE_ENABLED && window.firebase){ try{ await firebase.firestore().collection('hospitals').add(data); if(typeof toast==='function') toast('✅ আবেদন জমা','success'); } catch(e){ if(typeof toast==='function') toast('ব্যর্থ: ' + e.message,'error'); } }
  else { const arr = JSON.parse(localStorage.getItem('hospitalApplications')||'[]'); arr.push(Object.assign({}, data, {id:'h'+Date.now()})); localStorage.setItem('hospitalApplications', JSON.stringify(arr)); if(typeof toast==='function') toast('✅ সংরক্ষিত','success'); }
  if(typeof closeModal==='function') closeModal();
};
window.v5HospitalLogin = function(){ if(typeof toast==='function') toast('Phase 4-এ ইমেইল লগইন যোগ হবে','error'); };
console.log('%c✅ #8 Hospital Portal ready','color:#4CAF50');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 12: firebase-sync.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
if(!window.FIREBASE_ENABLED){ console.log('%c⚠️ Firebase disabled — লোকাল মোডে','color:#F57C00'); return; }
if(!window.firebase || !firebase.initializeApp){ console.warn('[sync] SDK missing'); return; }
try{ firebase.initializeApp(window.FIREBASE_CONFIG); }catch(e){ console.warn(e); return; }
const db = firebase.firestore();
const auth = firebase.auth();
auth.signInAnonymously().catch(e=>console.warn('[sync] auth failed', e));
async function syncDonors(){
  try{
    const snap = await db.collection('donors').limit(500).get();
    const cloudDonors = snap.docs.map(d=>Object.assign({id:d.id}, d.data()));
    if(Array.isArray(window.donors)){
      const byId = new Map(window.donors.map(d=>[d.id, d]));
      cloudDonors.forEach(d=> byId.set(d.id, Object.assign({}, byId.get(d.id), d)));
      window.donors.length = 0; window.donors.push(...byId.values());
    } else { window.donors = cloudDonors; }
    if(typeof window.renderDonors==='function') window.renderDonors();
    setSyncDot('online');
  }catch(e){ console.warn('[sync] donors failed', e); setSyncDot('error'); }
}
window.cloudSetAvailability = async function(payload){ try{ const uid = auth.currentUser && auth.currentUser.uid; if(!uid) return; await db.collection('donorAvailability').doc(uid).set(Object.assign({}, payload, {uid, at: firebase.firestore.FieldValue.serverTimestamp()}), {merge:true}); }catch(e){ console.warn(e); } };
function setSyncDot(state){ const el = document.querySelector('.sync-dot'); if(!el) return; el.classList.remove('online','local','error'); el.classList.add(state==='online'?'online':state==='error'?'error':'local'); const lbl = document.getElementById('syncLabel'); if(lbl) lbl.textContent = state==='online'?'লাইভ':state==='error'?'ত্রুটি':'লোকাল'; }
setInterval(syncDonors, 20000);
syncDonors();
console.log('%c✅ Firebase connected','color:#4CAF50;font-weight:700');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 13: hospitals-data.js — বরিশাল বিভাগের সব হাসপাতাল
   ═══════════════════════════════════════════════════════════ */
window.BARISHAL_HOSPITALS = [
  /* ═══ বরিশাল জেলা ═══ */
  {id:'sbmch',name:'শের-ই-বাংলা মেডিকেল কলেজ হাসপাতাল',nameEn:'Sher-e-Bangla Medical College Hospital',type:'government',category:'tertiary',district:'বরিশাল',upazila:'বরিশাল সদর',address:'বান্দ রোড, বরিশাল',phone:'01711-389546',emergency:'01711-389546',bloodBank:true,ambulance:true,icu:true,beds:1000,services:['ইমার্জেন্সি','ব্লাড ব্যাংক','ICU','CCU','সার্জারি','কার্ডিওলজি','নিউরোলজি','অর্থোপেডিক','শিশু','মাতৃসেবা'],lat:22.7010,lng:90.3535,verified:true,featured:true},
  {id:'barisal-general',name:'বরিশাল জেনারেল হাসপাতাল',type:'government',category:'district',district:'বরিশাল',upazila:'বরিশাল সদর',address:'হাসপাতাল রোড, বরিশাল',phone:'01711-389547',emergency:'01711-389547',bloodBank:true,ambulance:true,beds:250,services:['ইমার্জেন্সি','ব্লাড ব্যাংক','সার্জারি','মেডিসিন','শিশু','মাতৃসেবা'],lat:22.6995,lng:90.3600,verified:true,featured:true},
  {id:'sabur-medical',name:'শহীদ আব্দুর রব সেরনিয়াবাত মেডিকেল কলেজ হাসপাতাল',type:'government',category:'tertiary',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',bloodBank:true,ambulance:true,beds:500,services:['ইমার্জেন্সি','সার্জারি','মেডিসিন'],lat:22.6935,lng:90.3650,verified:true},
  {id:'barisal-mch',name:'সরকারি মাতৃ ও শিশু হাসপাতাল',type:'government',category:'specialized',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',bloodBank:false,ambulance:true,beds:100,services:['মাতৃসেবা','শিশু','গাইনী'],lat:22.7050,lng:90.3680,verified:true},
  {id:'uhc-bakergonj',name:'বাকেরগঞ্জ উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরিশাল',upazila:'বাকেরগঞ্জ',phone:'',beds:31,bloodBank:false,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.5478,lng:90.3372,verified:true},
  {id:'uhc-babugonj',name:'বাবুগঞ্জ উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরিশাল',upazila:'বাবুগঞ্জ',phone:'',beds:31,bloodBank:false,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.8139,lng:90.3186,verified:true},
  {id:'uhc-uzirpur',name:'উজিরপুর উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরিশাল',upazila:'উজিরপুর',phone:'',beds:50,bloodBank:false,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.7805,lng:90.2408,verified:true},
  {id:'uhc-gaurnadi',name:'গৌরনদী উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরিশাল',upazila:'গৌরনদী',phone:'',beds:50,bloodBank:false,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.9700,lng:90.2107,verified:true},
  {id:'uhc-agailjhara',name:'আগৈলঝাড়া উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরিশাল',upazila:'আগৈলঝাড়া',phone:'',beds:31,bloodBank:false,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.9988,lng:90.1521,verified:true},
  {id:'uhc-mehendiganj',name:'মেহেন্দিগঞ্জ উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরিশাল',upazila:'মেহেন্দিগঞ্জ',phone:'',beds:50,bloodBank:false,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.8280,lng:90.5291,verified:true},
  {id:'uhc-muladi',name:'মুলাদী উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরিশাল',upazila:'মুলাদী',phone:'',beds:31,bloodBank:false,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.9456,lng:90.4228,verified:true},
  {id:'uhc-hizla',name:'হিজলা উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরিশাল',upazila:'হিজলা',phone:'',beds:31,bloodBank:false,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.9315,lng:90.5717,verified:true},
  {id:'uhc-banaripara',name:'বানারীপাড়া উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরিশাল',upazila:'বানারীপাড়া',phone:'',beds:31,bloodBank:false,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.7844,lng:90.1766,verified:true},
  {id:'royal-city',name:'রয়েল সিটি হাসপাতাল',type:'private',category:'general',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.6975,lng:90.3620,verified:true},
  {id:'rahat-anwar',name:'রাহাত আনোয়ার হাসপাতাল',type:'private',category:'general',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.7000,lng:90.3550,verified:true},
  {id:'united-specialized-barishal',name:'দি ইউনাইটেড স্পেশালাইজড হাসপাতাল',type:'private',category:'specialized',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',beds:100,bloodBank:true,ambulance:true,icu:true,services:['ইমার্জেন্সি','ICU','সার্জারি'],lat:22.7040,lng:90.3540,verified:true},
  {id:'south-apollo',name:'সাউথ অ্যাপোলো মেডিকেল কলেজ ও হাসপাতাল',type:'private',category:'medical-college',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',beds:250,bloodBank:true,ambulance:true,icu:true,services:['ইমার্জেন্সি','ICU','শিক্ষা'],lat:22.6890,lng:90.3720,verified:true},
  {id:'islami-bank-hospital',name:'ইসলামি ব্যাংক হাসপাতাল',type:'private',category:'general',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',ambulance:true,services:['OPD','ডায়াগনস্টিক'],lat:22.7010,lng:90.3590,verified:true},
  {id:'diab-care-barisal',name:'বরিশাল ডায়াবেটিক হাসপাতাল',type:'private',category:'specialized',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',beds:50,ambulance:true,services:['ডায়াবেটিস','OPD'],lat:22.6980,lng:90.3620,verified:true},
  {id:'medinova-barishal',name:'মেডিনোভা মেডিকেল সার্ভিসেস',type:'private',category:'diagnostic',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',services:['ডায়াগনস্টিক'],lat:22.7005,lng:90.3560,verified:true},
  /* ═══ পটুয়াখালী ═══ */
  {id:'patuakhali-250',name:'পটুয়াখালী ২৫০ শয্যা সদর হাসপাতাল',type:'government',category:'district',district:'পটুয়াখালী',upazila:'পটুয়াখালী সদর',phone:'01712163530',emergency:'01712163530',beds:250,bloodBank:true,ambulance:true,icu:true,services:['ইমার্জেন্সি','ব্লাড ব্যাংক','ICU','সার্জারি'],lat:22.3596,lng:90.3297,verified:true,featured:true},
  {id:'patuakhali-diabetic',name:'পটুয়াখালী ডায়াবেটিক হাসপাতাল',type:'private',category:'specialized',district:'পটুয়াখালী',upazila:'পটুয়াখালী সদর',phone:'',services:['ডায়াবেটিস','OPD'],lat:22.3580,lng:90.3310,verified:true},
  {id:'uhc-patuakhali-sadar',name:'পটুয়াখালী সদর উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পটুয়াখালী',upazila:'পটুয়াখালী সদর',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.3590,lng:90.3300,verified:true},
  {id:'uhc-baufal',name:'বাউফল উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পটুয়াখালী',upazila:'বাউফল',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.4211,lng:90.5609,verified:true},
  {id:'uhc-dashmina',name:'দশমিনা উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পটুয়াখালী',upazila:'দশমিনা',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.2166,lng:90.5614,verified:true},
  {id:'uhc-galachipa',name:'গলাচিপা উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পটুয়াখালী',upazila:'গলাচিপা',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.1535,lng:90.4244,verified:true},
  {id:'uhc-kalapara',name:'কলাপাড়া উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পটুয়াখালী',upazila:'কলাপাড়া',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:21.9833,lng:90.2436,verified:true},
  {id:'uhc-mirzaganj',name:'মির্জাগঞ্জ উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পটুয়াখালী',upazila:'মির্জাগঞ্জ',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.2716,lng:90.1723,verified:true},
  {id:'uhc-rangabali',name:'রাঙ্গাবালী উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পটুয়াখালী',upazila:'রাঙ্গাবালী',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:21.8500,lng:90.3833,verified:true},
  {id:'uhc-dumki',name:'দুমকি উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পটুয়াখালী',upazila:'দুমকি',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.4561,lng:90.3277,verified:true},
  {id:'fortune-patuakhali',name:'ফরচুন হাসপাতাল',type:'private',category:'general',district:'পটুয়াখালী',upazila:'পটুয়াখালী সদর',phone:'',services:['OPD'],lat:22.3600,lng:90.3300,verified:true},
  /* ═══ ভোলা ═══ */
  {id:'bhola-sadar',name:'ভোলা জেলা সদর হাসপাতাল (২৫০ শয্যা)',type:'government',category:'district',district:'ভোলা',upazila:'ভোলা সদর',phone:'',beds:250,bloodBank:true,ambulance:true,icu:true,services:['ইমার্জেন্সি','ব্লাড ব্যাংক','ICU'],lat:22.6833,lng:90.6500,verified:true,featured:true},
  {id:'uhc-bhola-sadar',name:'ভোলা সদর উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'ভোলা',upazila:'ভোলা সদর',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.6850,lng:90.6520,verified:true},
  {id:'uhc-charfashion',name:'চরফ্যাশন উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'ভোলা',upazila:'চরফ্যাশন',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.1833,lng:90.7667,verified:true},
  {id:'uhc-borhanuddin',name:'বোরহানউদ্দিন উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'ভোলা',upazila:'বোরহানউদ্দিন',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.5000,lng:90.7333,verified:true},
  {id:'uhc-daularbazar',name:'দৌলতখান উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'ভোলা',upazila:'দৌলতখান',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.6167,lng:90.7000,verified:true},
  {id:'uhc-lalmohan',name:'লালমোহন উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'ভোলা',upazila:'লালমোহন',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.2833,lng:90.7333,verified:true},
  {id:'uhc-monpura',name:'মনপুরা উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'ভোলা',upazila:'মনপুরা',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.3167,lng:90.9333,verified:true},
  {id:'uhc-tozumuddin',name:'তজুমদ্দিন উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'ভোলা',upazila:'তজুমদ্দিন',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.4667,lng:90.8333,verified:true},
  {id:'dweep-eye-bhola',name:'দ্বীপ আই হাসপাতাল',type:'private',category:'specialized',district:'ভোলা',upazila:'ভোলা সদর',phone:'',services:['চক্ষু','OPD'],lat:22.6840,lng:90.6480,verified:true},
  {id:'unity-bhola',name:'ইউনিটি ডায়াগনস্টিক অ্যান্ড হাসপাতাল',type:'private',category:'diagnostic',district:'ভোলা',upazila:'ভোলা সদর',phone:'',services:['ডায়াগনস্টিক'],lat:22.6800,lng:90.6550,verified:true},
  /* ═══ পিরোজপুর ═══ */
  {id:'pirojpur-100',name:'পিরোজপুর জেলা হাসপাতাল (১০০ শয্যা)',type:'government',category:'district',district:'পিরোজপুর',upazila:'পিরোজপুর সদর',phone:'',beds:100,bloodBank:true,ambulance:true,services:['ইমার্জেন্সি','ব্লাড ব্যাংক'],lat:22.5833,lng:89.9750,verified:true,featured:true},
  {id:'uhc-bhandaria',name:'ভান্ডারিয়া উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পিরোজপুর',upazila:'ভান্ডারিয়া',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.5000,lng:89.9833,verified:true},
  {id:'uhc-mathbaria',name:'মঠবাড়িয়া উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পিরোজপুর',upazila:'মঠবাড়িয়া',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.2833,lng:89.9500,verified:true},
  {id:'uhc-nazirpur',name:'নাজিরপুর উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পিরোজপুর',upazila:'নাজিরপুর',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.7333,lng:89.9500,verified:true},
  {id:'uhc-nesarabad',name:'নেছারাবাদ উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পিরোজপুর',upazila:'নেছারাবাদ',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.7333,lng:90.0833,verified:true},
  {id:'uhc-kaukhali',name:'কাউখালী উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পিরোজপুর',upazila:'কাউখালী',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.6333,lng:90.0500,verified:true},
  {id:'uhc-zianagar',name:'জিয়ানগর উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'পিরোজপুর',upazila:'জিয়ানগর',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.4167,lng:89.9333,verified:true},
  {id:'tuskhali-pirojpur',name:'তুষখালী স্পেশালাইজড হাসপাতাল',type:'private',category:'specialized',district:'পিরোজপুর',upazila:'পিরোজপুর সদর',phone:'',services:['ডায়াগনস্টিক','OPD'],lat:22.5820,lng:89.9730,verified:true},
  /* ═══ বরগুনা ═══ */
  {id:'barguna-general',name:'বরগুনা জেনারেল হাসপাতাল (২৫০ শয্যা)',type:'government',category:'district',district:'বরগুনা',upazila:'বরগুনা সদর',phone:'',beds:250,bloodBank:true,ambulance:true,icu:true,services:['ইমার্জেন্সি','ব্লাড ব্যাংক','ICU'],lat:22.1500,lng:90.1167,verified:true,featured:true},
  {id:'uhc-amtali',name:'আমতলী উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরগুনা',upazila:'আমতলী',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.1333,lng:90.2333,verified:true},
  {id:'uhc-bamna',name:'বামনা উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরগুনা',upazila:'বামনা',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.2333,lng:90.0833,verified:true},
  {id:'uhc-betagi',name:'বেতাগী উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরগুনা',upazila:'বেতাগী',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.2333,lng:90.0000,verified:true},
  {id:'uhc-patharghata',name:'পাথরঘাটা উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরগুনা',upazila:'পাথরঘাটা',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.0333,lng:89.9833,verified:true},
  {id:'uhc-taltali',name:'তালতলী উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরগুনা',upazila:'তালতলী',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.0667,lng:90.1500,verified:true},
  {id:'united-amtali',name:'দি ইউনাইটেড স্পেশালাইজড হাসপাতাল',type:'private',category:'specialized',district:'বরগুনা',upazila:'আমতলী',phone:'',services:['OPD'],lat:22.1350,lng:90.2350,verified:true},
  /* ═══ ঝালকাঠি ═══ */
  {id:'jhalkathi-100',name:'ঝালকাঠি জেলা হাসপাতাল (১০০ শয্যা)',type:'government',category:'district',district:'ঝালকাঠি',upazila:'ঝালকাঠি সদর',phone:'01711311282',emergency:'01711311282',beds:100,bloodBank:true,ambulance:true,services:['ইমার্জেন্সি','ব্লাড ব্যাংক'],lat:22.6410,lng:90.2010,verified:true,featured:true},
  {id:'uhc-nalchity',name:'নলছিটি উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'ঝালকাঠি',upazila:'নলছিটি',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.6167,lng:90.2833,verified:true},
  {id:'uhc-rajapur',name:'রাজাপুর উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'ঝালকাঠি',upazila:'রাজাপুর',phone:'',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.5167,lng:90.1167,verified:true},
  {id:'uhc-kathalia',name:'কাঠালিয়া উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'ঝালকাঠি',upazila:'কাঠালিয়া',phone:'01730324423',emergency:'01730324423',beds:31,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.4167,lng:90.1333,verified:true}
];

window.HospitalDB = {
  all(){ return window.BARISHAL_HOSPITALS.slice(); },
  byDistrict(district){ return window.BARISHAL_HOSPITALS.filter(h => h.district === district); },
  byUpazila(upazila){ return window.BARISHAL_HOSPITALS.filter(h => h.upazila === upazila); },
  byType(type){ return window.BARISHAL_HOSPITALS.filter(h => h.type === type); },
  withBloodBank(){ return window.BARISHAL_HOSPITALS.filter(h => h.bloodBank); },
  featured(){ return window.BARISHAL_HOSPITALS.filter(h => h.featured); },
  search(q){ if(!q) return this.all(); const s = q.toLowerCase().trim(); return window.BARISHAL_HOSPITALS.filter(h => (h.name||'').toLowerCase().includes(s) || (h.nameEn||'').toLowerCase().includes(s) || (h.district||'').toLowerCase().includes(s) || (h.upazila||'').toLowerCase().includes(s) || (h.phone||'').includes(s)); },
  countByDistrict(){ const out = {}; window.BARISHAL_HOSPITALS.forEach(h => { out[h.district] = (out[h.district] || 0) + 1; }); return out; },
  stats(){ const all = window.BARISHAL_HOSPITALS; return { total: all.length, government: all.filter(h => h.type === 'government').length, private: all.filter(h => h.type === 'private').length, withBloodBank: all.filter(h => h.bloodBank).length, withICU: all.filter(h => h.icu).length, totalBeds: all.reduce((s,h) => s + (h.beds||0), 0) }; },
  grandTotal(){ return window.BARISHAL_HOSPITALS.length; },
  countByCategory(){ const out = {}; window.BARISHAL_HOSPITALS.forEach(h => { out[h.category] = (out[h.category] || 0) + 1; }); return out; },
  generatedCount(){ return window.BARISHAL_HOSPITALS.filter(h => h.generated).length; },
  verifiedCount(){ return window.BARISHAL_HOSPITALS.filter(h => !h.generated || h.verified).length; },
  categoryLabel(cat){ return { 'tertiary':'🏛️ বিশেষায়িত','district':'🏥 জেলা হাসপাতাল','upazila':'🏥 উপজেলা UHC','union':'🏘️ ইউনিয়ন কেন্দ্র','rhc':'🏘️ Rural','specialized':'💊 বিশেষায়িত','diagnostic':'🔬 ডায়াগনস্টিক','general':'🏥 সাধারণ','medical-college':'🎓 মেডিকেল কলেজ' }[cat] || '🏥'; }
};

/* ═══════════════════════════════════════════════════════════
   MODULE 14: hospitals-upazila.js — উপজেলা ভিত্তিক হাসপাতাল
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
if(!window.BARISHAL_HOSPITALS) return;
const UPAZILA_HOSPITALS = [
  {id:'uhc-barisal-sadar',name:'বরিশাল সদর উপজেলা স্বাস্থ্য কমপ্লেক্স',type:'government',category:'upazila',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',beds:50,ambulance:true,services:['ইমার্জেন্সি','OPD'],lat:22.7010,lng:90.3535,verified:true},
  {id:'rhc-charkaua-barisal',name:'চরকাউয়া ইউনিয়ন স্বাস্থ্য কেন্দ্র',type:'government',category:'union',district:'বরিশাল',upazila:'বরিশাল সদর',phone:'',beds:6,services:['OPD','টিকা'],lat:22.7100,lng:90.3600,verified:true},
  {id:'bakergonj-diag',name:'বাকেরগঞ্জ ডায়াগনস্টিক সেন্টার',type:'private',category:'diagnostic',district:'বরিশাল',upazila:'বাকেরগঞ্জ',phone:'',services:['ডায়াগনস্টিক'],lat:22.5480,lng:90.3380,verified:true},
  {id:'babugonj-diag',name:'বাবুগঞ্জ ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরিশাল',upazila:'বাবুগঞ্জ',phone:'',services:['ডায়াগনস্টিক'],lat:22.8140,lng:90.3190,verified:true},
  {id:'uzirpur-diag',name:'উজিরপুর ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরিশাল',upazila:'উজিরপুর',phone:'',services:['ডায়াগনস্টিক'],lat:22.7810,lng:90.2410,verified:true},
  {id:'banaripara-diag',name:'বানারীপাড়া ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরিশাল',upazila:'বানারীপাড়া',phone:'',services:['ডায়াগনস্টিক'],lat:22.7845,lng:90.1770,verified:true},
  {id:'gaurnadi-diag',name:'গৌরনদী ডায়াগনস্টিক অ্যান্ড হাসপাতাল',type:'private',category:'general',district:'বরিশাল',upazila:'গৌরনদী',phone:'',beds:20,services:['OPD'],lat:22.9705,lng:90.2110,verified:true},
  {id:'agailjhara-diag',name:'আগৈলঝাড়া ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরিশাল',upazila:'আগৈলঝাড়া',phone:'',services:['ডায়াগনস্টিক'],lat:22.9990,lng:90.1530,verified:true},
  {id:'mehendiganj-diag',name:'মেহেন্দিগঞ্জ ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরিশাল',upazila:'মেহেন্দিগঞ্জ',phone:'',services:['ডায়াগনস্টিক'],lat:22.8285,lng:90.5295,verified:true},
  {id:'muladi-diag',name:'মুলাদী ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরিশাল',upazila:'মুলাদী',phone:'',services:['ডায়াগনস্টিক'],lat:22.9460,lng:90.4230,verified:true},
  {id:'hizla-diag',name:'হিজলা ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরিশাল',upazila:'হিজলা',phone:'',services:['ডায়াগনস্টিক'],lat:22.9320,lng:90.5720,verified:true},
  {id:'baufal-diag',name:'বাউফল ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পটুয়াখালী',upazila:'বাউফল',phone:'',services:['ডায়াগনস্টিক'],lat:22.4215,lng:90.5610,verified:true},
  {id:'dashmina-diag',name:'দশমিনা ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পটুয়াখালী',upazila:'দশমিনা',phone:'',services:['ডায়াগনস্টিক'],lat:22.2170,lng:90.5620,verified:true},
  {id:'galachipa-diag',name:'গলাচিপা ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পটুয়াখালী',upazila:'গলাচিপা',phone:'',services:['ডায়াগনস্টিক'],lat:22.1540,lng:90.4250,verified:true},
  {id:'kalapara-diag',name:'কলাপাড়া ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পটুয়াখালী',upazila:'কলাপাড়া',phone:'',services:['ডায়াগনস্টিক'],lat:21.9840,lng:90.2440,verified:true},
  {id:'kuakata-health',name:'কুয়াকাটা স্বাস্থ্য কেন্দ্র',type:'government',category:'union',district:'পটুয়াখালী',upazila:'কলাপাড়া',phone:'',beds:10,services:['OPD'],lat:21.8200,lng:90.1200,verified:true},
  {id:'mirzaganj-diag',name:'মির্জাগঞ্জ ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পটুয়াখালী',upazila:'মির্জাগঞ্জ',phone:'',services:['ডায়াগনস্টিক'],lat:22.2720,lng:90.1730,verified:true},
  {id:'rangabali-diag',name:'রাঙ্গাবালী ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পটুয়াখালী',upazila:'রাঙ্গাবালী',phone:'',services:['ডায়াগনস্টিক'],lat:21.8510,lng:90.3840,verified:true},
  {id:'dumki-diag',name:'দুমকি ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পটুয়াখালী',upazila:'দুমকি',phone:'',services:['ডায়াগনস্টিক'],lat:22.4570,lng:90.3280,verified:true},
  {id:'bhola-sadar-diag',name:'ভোলা সদর ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ভোলা',upazila:'ভোলা সদর',phone:'',services:['ডায়াগনস্টিক'],lat:22.6840,lng:90.6510,verified:true},
  {id:'borhanuddin-diag',name:'বোরহানউদ্দিন ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ভোলা',upazila:'বোরহানউদ্দিন',phone:'',services:['ডায়াগনস্টিক'],lat:22.5010,lng:90.7340,verified:true},
  {id:'charfashion-diag',name:'চরফ্যাশন ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ভোলা',upazila:'চরফ্যাশন',phone:'',services:['ডায়াগনস্টিক'],lat:22.1840,lng:90.7670,verified:true},
  {id:'daulatkhan-diag',name:'দৌলতখান ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ভোলা',upazila:'দৌলতখান',phone:'',services:['ডায়াগনস্টিক'],lat:22.6170,lng:90.7010,verified:true},
  {id:'lalmohan-diag',name:'লালমোহন ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ভোলা',upazila:'লালমোহন',phone:'',services:['ডায়াগনস্টিক'],lat:22.2840,lng:90.7340,verified:true},
  {id:'monpura-diag',name:'মনপুরা ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ভোলা',upazila:'মনপুরা',phone:'',services:['ডায়াগনস্টিক'],lat:22.3175,lng:90.9340,verified:true},
  {id:'tozumuddin-diag',name:'তজুমদ্দিন ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ভোলা',upazila:'তজুমদ্দিন',phone:'',services:['ডায়াগনস্টিক'],lat:22.4675,lng:90.8340,verified:true},
  {id:'pirojpur-sadar-diag',name:'পিরোজপুর সদর ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পিরোজপুর',upazila:'পিরোজপুর সদর',phone:'',services:['ডায়াগনস্টিক'],lat:22.5840,lng:89.9760,verified:true},
  {id:'bhandaria-diag',name:'ভান্ডারিয়া ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পিরোজপুর',upazila:'ভান্ডারিয়া',phone:'',services:['ডায়াগনস্টিক'],lat:22.5010,lng:89.9840,verified:true},
  {id:'kaukhali-diag',name:'কাউখালী ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পিরোজপুর',upazila:'কাউখালী',phone:'',services:['ডায়াগনস্টিক'],lat:22.6340,lng:90.0510,verified:true},
  {id:'mathbaria-diag',name:'মঠবাড়িয়া ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পিরোজপুর',upazila:'মঠবাড়িয়া',phone:'',services:['ডায়াগনস্টিক'],lat:22.2840,lng:89.9510,verified:true},
  {id:'nazirpur-diag',name:'নাজিরপুর ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পিরোজপুর',upazila:'নাজিরপুর',phone:'',services:['ডায়াগনস্টিক'],lat:22.7340,lng:89.9510,verified:true},
  {id:'nesarabad-diag',name:'নেছারাবাদ ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পিরোজপুর',upazila:'নেছারাবাদ',phone:'',services:['ডায়াগনস্টিক'],lat:22.7340,lng:90.0840,verified:true},
  {id:'zianagar-diag',name:'জিয়ানগর ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'পিরোজপুর',upazila:'জিয়ানগর',phone:'',services:['ডায়াগনস্টিক'],lat:22.4175,lng:89.9340,verified:true},
  {id:'barguna-sadar-diag',name:'বরগুনা সদর ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরগুনা',upazila:'বরগুনা সদর',phone:'',services:['ডায়াগনস্টিক'],lat:22.1510,lng:90.1170,verified:true},
  {id:'islami-eye-barguna',name:'ইসলামী আই হাসপাতাল বরগুনা',type:'private',category:'specialized',district:'বরগুনা',upazila:'বরগুনা সদর',phone:'',services:['চক্ষু'],lat:22.1505,lng:90.1160,verified:true},
  {id:'amtali-diag',name:'আমতলী ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরগুনা',upazila:'আমতলী',phone:'',services:['ডায়াগনস্টিক'],lat:22.1340,lng:90.2340,verified:true},
  {id:'bamna-diag',name:'বামনা ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরগুনা',upazila:'বামনা',phone:'',services:['ডায়াগনস্টিক'],lat:22.2340,lng:90.0840,verified:true},
  {id:'betagi-diag',name:'বেতাগী ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরগুনা',upazila:'বেতাগী',phone:'',services:['ডায়াগনস্টিক'],lat:22.2340,lng:90.0010,verified:true},
  {id:'patharghata-diag',name:'পাথরঘাটা ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরগুনা',upazila:'পাথরঘাটা',phone:'',services:['ডায়াগনস্টিক'],lat:22.0340,lng:89.9840,verified:true},
  {id:'taltali-diag',name:'তালতলী ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'বরগুনা',upazila:'তালতলী',phone:'',services:['ডায়াগনস্টিক'],lat:22.0670,lng:90.1510,verified:true},
  {id:'jhalkathi-sadar-diag',name:'ঝালকাঠি সদর ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ঝালকাঠি',upazila:'ঝালকাঠি সদর',phone:'',services:['ডায়াগনস্টিক'],lat:22.6410,lng:90.2020,verified:true},
  {id:'kathalia-diag',name:'কাঠালিয়া ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ঝালকাঠি',upazila:'কাঠালিয়া',phone:'',services:['ডায়াগনস্টিক'],lat:22.4175,lng:90.1340,verified:true},
  {id:'nalchity-diag',name:'নলছিটি ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ঝালকাঠি',upazila:'নলছিটি',phone:'',services:['ডায়াগনস্টিক'],lat:22.6175,lng:90.2840,verified:true},
  {id:'rajapur-diag',name:'রাজাপুর ডায়াগনস্টিক',type:'private',category:'diagnostic',district:'ঝালকাঠি',upazila:'রাজাপুর',phone:'',services:['ডায়াগনস্টিক'],lat:22.5175,lng:90.1175,verified:true}
];
const existing = new Set(window.BARISHAL_HOSPITALS.map(h => h.id));
let added = 0;
UPAZILA_HOSPITALS.forEach(h => { if(!existing.has(h.id)){ window.BARISHAL_HOSPITALS.push(h); added++; } });
console.log('%c✅ hospitals-upazila.js — ' + added + ' new entries','color:#7B1FA2;font-weight:700');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 15: unions-data.js — ইউনিয়ন ভিত্তিক হাসপাতাল
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
if(!window.BARISHAL_HOSPITALS) return;
const UNION_NAMES = {
  'বরিশাল সদর':['রায়পাশা কড়াপুর','কাশীপুর','চরকাউয়া','চাঁদপুরা','জাগুয়া','শায়েস্তাবাদ','চরবাড়িয়া','সুভদিয়া','টুঙ্গীবাড়িয়া','চরমোনাই'],
  'বাকেরগঞ্জ':['কলস্কাটি','গারুড়িয়া','চরাদি','দুধল','দাড়িয়াল','চরামদ্দি','কালকিনি','নলুয়া','ফরিদপুর','রঙ্গশ্রী','বরিশাল','ভরপাশা','দাউদখান','সিকদারমল্লিক','কবাই'],
  'বাবুগঞ্জ':['রহমতপুর','বহরমপুর','মাধবপাশা','চাঁদপাশা','দেহেরগতি'],
  'উজিরপুর':['সাতলা','হিজলগঞ্জি','শিকারপুর','বরাকোঠা','বামরাইল','শোলক','গুঠিয়া','ওটরা','জল্লা'],
  'বানারীপাড়া':['ইলুহার','বাইশারী','সৈয়দকাঠী','চাখার','সলিয়াবাকপুর','বিশারকান্দি','উদয়কাঠী','বানারীপাড়া'],
  'গৌরনদী':['খাঞ্জাপুর','বাটাজোর','সরিকল','চাঁদশী','নলচিড়া','মাহিলাড়া','বাটা','গৌরনদী'],
  'আগৈলঝাড়া':['রাজিহার','বাকল','বাগধা','গৈলা','রত্নপুর','বাশাইল'],
  'মেহেন্দিগঞ্জ':['চরগোপালপুর','চরএককরিয়া','গোবিন্দপুর','চাঁদপুর','দরিচর','লতা','উলানিয়া','কালাদাস','আন্ধারমানিক','জাঙ্গালিয়া','ভাষানচর','আলিমাবাদ','বড়আইল'],
  'মুলাদী':['কাজিরচর','বাটামারা','নাজিরপুর','সফিপুর','গাছুয়া','চরকালেখান','মুলাদী','বালিথা'],
  'হিজলা':['হিজলা গৌরবদী','মেমানিয়া','ধুলখোলা','বরজালিয়া','কুড়িখাল','বাউশিয়া'],
  'পটুয়াখালী সদর':['শাহবাজপুর','জৈনকাঠী','কুড়িপাড়া','ইটবাড়িয়া','লাউকাঠী','লোহালিয়া','বদরপুর','ভুরঘাটা','অম্বিকাপুর'],
  'বাউফল':['কালাইয়া','কালিশুরী','কনকদিয়া','দাশমনিয়া','নওমালা','মদনপুরা','ধুলিয়া','সূর্য্যমনি','বগা','মধুখালী','নাজিরপুর','কাছিপাড়া','বাউফল'],
  'দশমিনা':['রণগোপালদী','বাঁশবাড়িয়া','বহরমপুর','আলীপুর','দশমিনা','চরবোরহান','কুমারখালী'],
  'গলাচিপা':['চর কাজল','গোলখালী','রতনদী তালতলী','পানপট্টি','গলাচিপা','কুয়াকাটা','ডাকুয়া','বকুলবাড়িয়া','আমখোলা','চিকনিকান্দি','কলাগাছিয়া'],
  'কলাপাড়া':['কলাপাড়া','চাকামইয়া','টিয়াখালী','লালুয়া','মিঠাগঞ্জ','নীলগঞ্জ','ধানখালী','বালিয়াতলী','বলবলিয়া','মহিপুর','খাপড়াবুনিয়া','চম্পাপুর'],
  'মির্জাগঞ্জ':['মির্জাগঞ্জ','কাকড়াবুনিয়া','আমড়াগাছিয়া','ডেকাতিয়া','মাধবখালী','সুবিদখালী','বাঁশবাড়িয়া'],
  'রাঙ্গাবালী':['রাঙ্গাবালী','বড়বাইশদিয়া','চালিতাবুনিয়া','চরমোন্তাজ','মৌডুবী','ছোটবাইশদিয়া'],
  'দুমকি':['দুমকি','শ্রীরামপুর','পাঙ্গাশিয়া','মুরাদিয়া','আংগারিয়া','লেবুখালী'],
  'ভোলা সদর':['বাপ্তা','ধনিয়া','শিবপুর','আলীনগর','চরসামাইয়া','বেদুরিয়া','ভেলুমিয়া','রাজাপুর','কাচিয়া','ইলিশা'],
  'বোরহানউদ্দিন':['বোরহানউদ্দিন','কাচিয়া','হাসাননগর','সাচড়া','পক্ষিয়া','গংগাপুর','টবগী','দেউলা','কুতুবা','বড় মানিকা'],
  'চরফ্যাশন':['চরফ্যাশন','ওসমানগঞ্জ','আছলামপুর','চরকলমি','জিন্নাগড়','নুরাবাদ','আবুবকরপুর','মুজিবনগর','ঢালচর','দক্ষিণ আইচা','চরমানিকা','কুকরী মুকরি','মাদ্রাজ','হাজারীগঞ্জ','বেতুয়া','শশিভূষণ','আওয়াজপুর','দুলারহাট','চরমাদ্রাজ','নীলকমল'],
  'দৌলতখান':['দৌলতখান','মেদুয়া','সৈয়দপুর','চরখলিফা','হাজীপুর','ভবানীপুর','উত্তর জয়নগর','চরপাতা','মদনপুর'],
  'লালমোহন':['লালমোহন','কালমা','ধলীগৌরনগর','চরভূতা','লর্ডহার্ডিঞ্জ','রমাগঞ্জ','বদরপুর','পশ্চিম চরউমেদ','ফরাজগঞ্জ'],
  'মনপুরা':['মনপুরা','হাজীরহাট','সাকুচিয়া উত্তর','সাকুচিয়া দক্ষিণ'],
  'তজুমদ্দিন':['তজুমদ্দিন','বড়মলং','চাঁদপুর','শম্ভুপুর','সোনাপুর'],
  'পিরোজপুর সদর':['শিকদারমল্লিক','কদমতলা','দূর্গাপুর','কলাখালী','টোনা','বলদিয়া','সাতুরিয়া','শরিকতলা','দুহাসার'],
  'ভান্ডারিয়া':['ভান্ডারিয়া','তেলিখালী','দেউলবাড়ী দোবড়া','ইকড়ী','ধানীসাফা','ভিটাবাড়িয়া','নদমুলা শিয়ালকাঠী'],
  'কাউখালী':['কাউখালী','সয়না রাজাপুর','আমড়াজুড়ি','চিরাপাড়া','শিয়ালকাঠী'],
  'মঠবাড়িয়া':['মঠবাড়িয়া','টিয়ারখালী','বড়মাছুয়া','চরকুন্ডি','তুষখালী','ধানীসাফা','গুলিশাখালী','সাপলেজা','হাসনা','বেতমোর রাজাপুর','আমড়াগাছিয়া','শিরা'],
  'নাজিরপুর':['মাটিভাঙ্গা','মালিখালী','দেউলবাড়ী দোবড়া','নাজিরপুর','শাখারীকাঠী','শ্রীরামকাঠী','কলারদোয়ানিয়া','দীর্ঘা','সেকেন্দরকাঠি'],
  'নেছারাবাদ':['স্বরূপকাঠি','বলদিয়া','বালিপাড়া','সোহাগদল','আটঘর কুড়িয়ানা','জলাবাড়ী','দৈহারী','গুয়ারেখা','সমুদয়কাঠী','সুটিয়াকাঠী'],
  'জিয়ানগর':['জিয়ানগর','পাড়েরহাট','বালিথা','পত্তাশি','আমড়াবুনিয়া','পুটিখালী'],
  'বরগুনা সদর':['বুড়িরচর','ঢলুয়া','নলটোনা','বদরখালী','গৌরিচন্না','ফুলঝুড়ি','কেওড়াবুনিয়া','আয়লা পাতাকাটা','এম বালিয়াতলী','চরদুয়ানী'],
  'আমতলী':['আমতলী','গুলিশাখালী','কুকুয়া','আড়পাঙ্গাশিয়া','চাওড়া','হলদিয়া','বড়বগি','শিশুতলা'],
  'বামনা':['বামনা','বুকাবুনিয়া','রামনা','ডৌয়াতলা'],
  'বেতাগী':['বেতাগী','বিবিচিনি','হোসনাবাদ','মোকামিয়া','বুড়ামজুমদার','সরিষামুড়ী','কাকাবাবু'],
  'পাথরঘাটা':['পাথরঘাটা','কাকচিড়া','কলমদহ','নাচনাপাড়া','রায়হানপুর','কালমেঘা','বাইনচর','বড্ডা'],
  'তালতলী':['তালতলী','বড়বগি','ছোটবগি','নিশানবাড়িয়া','কড়ইবাড়িয়া','পচাকোড়ালিয়া','সোনাকাটা','খাগদোনা'],
  'ঝালকাঠি সদর':['গাভা রামচন্দ্রপুর','কীর্তিপাশা','নবগ্রাম','বাসন্ডা','শেখেরহাট','দক্ষিণ আলেকান্দা','পোনাবালিয়া'],
  'কাঠালিয়া':['কাঠালিয়া','আমুয়া','আওরাবুনিয়া','শৌলজালিয়া','চেঁচরী রামপুর','পাটিখালঘাটা','শিবগঞ্জ'],
  'নলছিটি':['নলছিটি','ভৈরবপাশা','মগর','কুশঙ্গল','দপদপিয়া','নাচনমহল','সিদ্ধকাঠী','রানাপাশা','কুলকাঠী','সুবিদপুর'],
  'রাজাপুর':['রাজাপুর','গালুয়া','পশ্চিম দেউলিয়া','বড়ইয়া','নলছিটি']
};
function slugify(str){ return String(str || '').replace(/[^\w\u0980-\u09FF]+/g, '-').toLowerCase().slice(0, 60); }
function getUpazilaGeo(upazila){ const found = window.BARISHAL_HOSPITALS.find(h => h.upazila === upazila && h.lat); if(found) return { lat: found.lat, lng: found.lng }; return { lat: null, lng: null }; }
function getDistrictOf(upazila){ if(window.DISTRICTS){ for(const d of Object.keys(window.DISTRICTS)){ if(window.DISTRICTS[d].includes(upazila)) return d; } } return null; }
function generateUnionEntries(){
  const newEntries = [];
  const existingIds = new Set(window.BARISHAL_HOSPITALS.map(h => h.id));
  Object.keys(UNION_NAMES).forEach(upazila => {
    const unionList = UNION_NAMES[upazila] || [];
    const district = getDistrictOf(upazila);
    const geo = getUpazilaGeo(upazila);
    unionList.forEach((union, idx) => {
      const slug = slugify(union);
      const uhfwcId = 'uhfwc-' + slug + '-' + idx;
      if(!existingIds.has(uhfwcId)){
        const offsetLat = geo.lat ? geo.lat + (Math.random() - 0.5) * 0.05 : null;
        const offsetLng = geo.lng ? geo.lng + (Math.random() - 0.5) * 0.05 : null;
        newEntries.push({ id: uhfwcId, name: union + ' ইউনিয়ন স্বাস্থ্য ও পরিবার কল্যাণ কেন্দ্র', type: 'government', category: 'union', district: district, upazila: upazila, address: union + ' ইউনিয়ন', phone: '', beds: 6, services: ['OPD','টিকা','পরিবার পরিকল্পনা'], lat: offsetLat, lng: offsetLng, verified: false, generated: true });
      }
      const ccCount = union.length > 8 ? 3 : 2;
      for(let c = 1; c <= ccCount; c++){
        const ccId = 'cc-' + slug + '-' + idx + '-' + c;
        if(existingIds.has(ccId)) continue;
        const ccName = c === 1 ? union + ' কমিউনিটি ক্লিনিক' : union + ' কমিউনিটি ক্লিনিক-' + c;
        newEntries.push({ id: ccId, name: ccName, type: 'government', category: 'community-clinic', district: district, upazila: upazila, address: union + ' ইউনিয়ন, ওয়ার্ড ' + c, phone: '', beds: 0, services: ['প্রাথমিক চিকিৎসা','টিকা'], lat: null, lng: null, verified: false, generated: true });
      }
    });
  });
  return newEntries;
}
const unionEntries = generateUnionEntries();
unionEntries.forEach(h => window.BARISHAL_HOSPITALS.push(h));
window.BARISHAL_UNIONS = UNION_NAMES;
console.log('%c✅ unions-data.js — ' + unionEntries.length + ' entries','color:#00838F;font-weight:700');
console.log('   মোট প্রতিষ্ঠান:', window.BARISHAL_HOSPITALS.length);
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 16: hospitals-ui.js — হাসপাতাল UI
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
const $ = id => document.getElementById(id);
const toBn = n => String(n||0).replace(/[0-9]/g, d => '০১২৩৪৫৬৭৮৯'[+d]);
const esc = s => String(s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let currentDistrict = '', currentUpazila = '', currentType = '', currentFilter = '', searchQuery = '';

window.renderHospitalsList = function(){
  const container = $('hospitalList'); if(!container) return;
  const stats = window.HospitalDB.stats();
  const catCounts = window.HospitalDB.countByCategory ? window.HospitalDB.countByCategory() : {};
  const generatedCount = window.HospitalDB.generatedCount ? window.HospitalDB.generatedCount() : 0;
  container.innerHTML =
    '<div class="hosp-stats-strip">' +
      '<div class="hosp-stat-item"><div class="hosp-stat-num">' + toBn(stats.total) + '</div><div class="hosp-stat-lbl">মোট</div></div>' +
      '<div class="hosp-stat-item"><div class="hosp-stat-num">' + toBn(stats.government) + '</div><div class="hosp-stat-lbl">সরকারি</div></div>' +
      '<div class="hosp-stat-item"><div class="hosp-stat-num">' + toBn(stats.private) + '</div><div class="hosp-stat-lbl">বেসরকারি</div></div>' +
      '<div class="hosp-stat-item"><div class="hosp-stat-num">' + toBn(catCounts['union'] || 0) + '</div><div class="hosp-stat-lbl">🏘️ ইউনিয়ন</div></div>' +
      '<div class="hosp-stat-item"><div class="hosp-stat-num">' + toBn(stats.withBloodBank) + '</div><div class="hosp-stat-lbl">🩸 ব্লাড</div></div>' +
    '</div>' +
    (generatedCount > 0 ? '<div class="hosp-generated-notice" onclick="__hospShowGenInfo()">ℹ️ <b>' + toBn(generatedCount) + 'টি প্রতিষ্ঠান</b> স্বয়ংক্রিয়ভাবে যোগ — DGHS থেকে verified নয় <span style="margin-left:auto">▾</span></div>' : '') +
    '<div class="hosp-search-wrap"><input type="text" id="hospSearch" class="hosp-search-input" placeholder="🔍 নাম / এলাকা / ফোন" oninput="__hospSearch(this.value)"><button class="hosp-search-clear" onclick="__hospClearSearch()">✕</button></div>' +
    '<div class="hosp-filter-row">' +
      '<button class="hosp-filter-chip ' + (currentDistrict===''?'active':'') + '" onclick="__hospFilterDistrict(\'\')">সব জেলা</button>' +
      Object.keys(window.DISTRICTS).map(d => '<button class="hosp-filter-chip ' + (currentDistrict===d?'active':'') + '" onclick="__hospFilterDistrict(\'' + d + '\')">' + d + '</button>').join('') +
    '</div>' +
    (currentDistrict ? '<div class="hosp-filter-row"><button class="hosp-filter-chip small ' + (currentUpazila===''?'active':'') + '" onclick="__hospFilterUpazila(\'\')">সব উপজেলা</button>' + (window.DISTRICTS[currentDistrict] || []).map(u => '<button class="hosp-filter-chip small ' + (currentUpazila===u?'active':'') + '" onclick="__hospFilterUpazila(\'' + u + '\')">' + u + '</button>').join('') + '</div>' : '') +
    '<div class="hosp-filter-row">' +
      '<button class="hosp-filter-chip small ' + (currentType===''?'active':'') + '" onclick="__hospFilterType(\'\')">সব ধরন</button>' +
      '<button class="hosp-filter-chip small ' + (currentType==='government'?'active':'') + '" onclick="__hospFilterType(\'government\')">🏛️ সরকারি</button>' +
      '<button class="hosp-filter-chip small ' + (currentType==='private'?'active':'') + '" onclick="__hospFilterType(\'private\')">🏥 বেসরকারি</button>' +
      '<button class="hosp-filter-chip small ' + (currentFilter==='bloodBank'?'active':'') + '" onclick="__hospFilterSpecial(\'bloodBank\')">🩸 ব্লাড ব্যাংক</button>' +
      '<button class="hosp-filter-chip small ' + (currentFilter==='icu'?'active':'') + '" onclick="__hospFilterSpecial(\'icu\')">💊 ICU</button>' +
      '<button class="hosp-filter-chip small ' + (currentFilter==='featured'?'active':'') + '" onclick="__hospFilterSpecial(\'featured\')">⭐ প্রধান</button>' +
      '<button class="hosp-filter-chip small ' + (currentFilter==='uhfwc'?'active':'') + '" onclick="__hospFilterSpecial(\'uhfwc\')">🏘️ ইউনিয়ন</button>' +
    '</div>' +
    '<div id="hospResults"></div>';
  renderResults();
};

function renderResults(){
  const results = $('hospResults'); if(!results) return;
  let list = window.HospitalDB.all();
  if(searchQuery) list = window.HospitalDB.search(searchQuery);
  if(currentDistrict) list = list.filter(h => h.district === currentDistrict);
  if(currentUpazila) list = list.filter(h => h.upazila === currentUpazila);
  if(currentType) list = list.filter(h => h.type === currentType);
  if(currentFilter === 'bloodBank') list = list.filter(h => h.bloodBank);
  if(currentFilter === 'icu') list = list.filter(h => h.icu);
  if(currentFilter === 'featured') list = list.filter(h => h.featured);
  if(currentFilter === 'uhfwc') list = list.filter(h => h.category === 'union' || h.category === 'community-clinic');
  const catPriority = { 'tertiary':1,'medical-college':2,'district':3,'upazila':4,'specialized':5,'general':6,'diagnostic':7,'union':8,'rhc':9,'community-clinic':10 };
  list.sort((a,b) => {
    if(a.featured && !b.featured) return -1;
    if(!a.featured && b.featured) return 1;
    if(a.type === 'government' && b.type !== 'government') return -1;
    if(a.type !== 'government' && b.type === 'government') return 1;
    const ap = catPriority[a.category] || 99, bp = catPriority[b.category] || 99;
    if(ap !== bp) return ap - bp;
    return (a.district || '').localeCompare(b.district || '', 'bn');
  });
  if(!list.length){ results.innerHTML = '<div class="empty"><div class="empty-ic">🏥</div><div class="empty-t">কোনো প্রতিষ্ঠান নেই</div></div>'; return; }
  const grouped = {};
  list.forEach(h => { const key = h.district + '|' + (h.upazila || 'অন্যান্য'); if(!grouped[key]) grouped[key] = { district: h.district, upazila: h.upazila || 'অন্যান্য', items: [] }; grouped[key].items.push(h); });
  const sortedGroups = Object.values(grouped).sort((a,b) => { if(a.district !== b.district) return a.district.localeCompare(b.district, 'bn'); return (a.upazila||'').localeCompare(b.upazila||'', 'bn'); });
  results.innerHTML = sortedGroups.map(group =>
    '<div class="hosp-district-group">' +
      '<div class="hosp-district-header"><span class="hosp-district-icon">📍</span><span class="hosp-district-name">' + esc(group.district) + ' · ' + esc(group.upazila) + '</span><span class="hosp-district-count">' + toBn(group.items.length) + ' টি</span></div>' +
      group.items.map(h => hospitalCardHTML(h)).join('') +
    '</div>'
  ).join('');
}

function hospitalCardHTML(h){
  const typeClass = h.type === 'government' ? 'gov' : 'pvt';
  const badges = [];
  if(h.bloodBank) badges.push('<span class="hosp-badge red">🩸 ব্লাড ব্যাংক</span>');
  if(h.icu) badges.push('<span class="hosp-badge purple">💊 ICU</span>');
  if(h.ambulance) badges.push('<span class="hosp-badge blue">🚑</span>');
  if(h.featured) badges.push('<span class="hosp-badge gold">⭐ প্রধান</span>');
  const categoryLabel = window.HospitalDB.categoryLabel ? window.HospitalDB.categoryLabel(h.category) : '';
  const iconEmoji = { 'tertiary':'🏛️','district':'🏥','upazila':'🏥','union':'🏘️','community-clinic':'🏘️','rhc':'🏘️','specialized':'💊','diagnostic':'🔬','general':'🏥','medical-college':'🎓' }[h.category] || '🏥';
  return '<div class="hosp-card-v2" onclick="__hospShowDetail(\'' + h.id + '\')" data-cat="' + (h.category||'') + '">' +
    '<div class="hosp-card-v2-icon ' + typeClass + '">' + iconEmoji + '</div>' +
    '<div class="hosp-card-v2-body">' +
      '<div class="hosp-card-v2-name">' + esc(h.name) + '</div>' +
      '<div class="hosp-card-v2-meta"><span>📍 ' + esc(h.upazila) + '</span>' + (h.beds?'<span>🛏️ ' + toBn(h.beds) + ' শয্যা</span>':'') + (categoryLabel?'<span class="hosp-cat">' + categoryLabel + '</span>':'') + '</div>' +
      (h.phone?'<div class="hosp-card-v2-phone">📞 ' + esc(h.phone) + '</div>':'') +
      (badges.length?'<div class="hosp-card-v2-badges">' + badges.join('') + '</div>':'') +
    '</div>' +
    '<div class="hosp-card-v2-arrow">›</div>' +
  '</div>';
}

window.__hospSearch = function(v){ searchQuery = v || ''; renderResults(); };
window.__hospClearSearch = function(){ searchQuery = ''; const i = $('hospSearch'); if(i) i.value=''; renderResults(); };
window.__hospFilterDistrict = function(d){ currentDistrict = d; currentUpazila = ''; window.renderHospitalsList(); };
window.__hospFilterUpazila = function(u){ currentUpazila = u; renderResults(); };
window.__hospFilterType = function(t){ currentType = t; window.renderHospitalsList(); };
window.__hospFilterSpecial = function(f){ currentFilter = currentFilter === f ? '' : f; window.renderHospitalsList(); };

window.__hospShowDetail = function(id){
  const h = window.HospitalDB.all().find(x => x.id === id); if(!h) return;
  const typeLabel = h.type === 'government' ? '🏛️ সরকারি' : '🏥 বেসরকারি';
  const dist = calcDistance(h);
  const html = '<div class="mhdr"><div class="mt">' + esc(h.name) + '</div><button class="cb" onclick="closeModal()">✕</button></div>' +
    '<div class="hosp-detail">' +
      '<div class="hosp-detail-hero"><div class="hosp-detail-icon">' + (h.type === 'government' ? '🏛️' : '🏥') + '</div><div><span class="hosp-detail-type">' + typeLabel + '</span></div></div>' +
      '<div class="hosp-detail-info">' +
        '<div class="hosp-detail-row"><span class="hosp-detail-label">📍 ঠিকানা</span><span class="hosp-detail-value">' + esc(h.address || h.upazila) + '</span></div>' +
        '<div class="hosp-detail-row"><span class="hosp-detail-label">🏙️ জেলা</span><span class="hosp-detail-value">' + esc(h.district) + '</span></div>' +
        '<div class="hosp-detail-row"><span class="hosp-detail-label">🗺️ উপজেলা</span><span class="hosp-detail-value">' + esc(h.upazila) + '</span></div>' +
        (h.phone ? '<div class="hosp-detail-row"><span class="hosp-detail-label">📞 ফোন</span><span class="hosp-detail-value">' + esc(h.phone) + '</span></div>' : '') +
        (h.beds ? '<div class="hosp-detail-row"><span class="hosp-detail-label">🛏️ শয্যা</span><span class="hosp-detail-value">' + toBn(h.beds) + ' টি</span></div>' : '') +
        (dist ? '<div class="hosp-detail-row"><span class="hosp-detail-label">📏 দূরত্ব</span><span class="hosp-detail-value">' + dist + '</span></div>' : '') +
      '</div>' +
      (h.services && h.services.length ? '<div class="hosp-detail-services"><div class="hosp-detail-section-title">🩺 সেবাসমূহ</div><div class="hosp-detail-chips">' + h.services.map(s => '<span class="hosp-service-chip">' + esc(s) + '</span>').join('') + '</div></div>' : '') +
      '<div class="hosp-detail-actions">' +
        (h.phone ? '<a href="tel:' + h.phone + '" class="btn btn-p" style="text-decoration:none;text-align:center">📞 কল করুন</a>' : '') +
        (h.lat && h.lng ? '<a href="https://www.google.com/maps?q=' + h.lat + ',' + h.lng + '" target="_blank" class="btn btn-o" style="text-decoration:none;text-align:center">🗺️ ম্যাপ</a>' : '') +
      '</div>' +
      (h.bloodBank ? '<div class="hosp-detail-blood-notice">🩸 <b>এই হাসপাতালে ব্লাড ব্যাংক আছে</b></div>' : '') +
    '</div>';
  if(typeof window.openModal === 'function') window.openModal(html);
};

function calcDistance(h){
  if(!h.lat || !h.lng) return null;
  try{
    const geo = JSON.parse(localStorage.getItem('userGeo') || 'null');
    if(!geo || !geo.lat) return null;
    const R = 6371, T = x => x * Math.PI / 180;
    const dLat = T(h.lat - geo.lat), dLng = T(h.lng - geo.lng);
    const a = Math.sin(dLat/2)**2 + Math.cos(T(geo.lat)) * Math.cos(T(h.lat)) * Math.sin(dLng/2)**2;
    const km = 2 * R * Math.asin(Math.sqrt(a));
    if(km < 1) return Math.round(km*1000) + ' মিটার';
    return km.toFixed(1) + ' কিমি';
  }catch(e){ return null; }
}

window.__hospShowGenInfo = function(){
  const generated = window.HospitalDB.generatedCount();
  const verified = window.HospitalDB.verifiedCount();
  const total = window.HospitalDB.grandTotal();
  const html = '<div class="mhdr"><div class="mt">ℹ️ ডেটা সম্পর্কে</div><button class="cb" onclick="closeModal()">✕</button></div>' +
    '<div style="font-size:13.5px;line-height:1.8;color:var(--text2)">' +
      '<div style="padding:14px;background:#FFF8E1;border-radius:10px;margin-bottom:14px">' +
        '<b>📊 মোট:</b> ' + toBn(total) + '<br>' +
        '<b>✅ যাচাইকৃত:</b> ' + toBn(verified) + '<br>' +
        '<b>ℹ️ স্বয়ংক্রিয়:</b> ' + toBn(generated) +
      '</div>' +
      '<p>সরকারি মডেল অনুযায়ী ইউনিয়ন কেন্দ্র ও কমিউনিটি ক্লিনিক যোগ করা হয়েছে।</p>' +
      '<p style="margin-top:10px"><b>যাচাই:</b> dghs.gov.bd, communityclinic.gov.bd</p>' +
    '</div>';
  if(typeof window.openModal === 'function') window.openModal(html);
};

console.log('%c✅ hospitals-ui.js loaded','color:#43A047;font-weight:700');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 17: ambulance-data.js
   ═══════════════════════════════════════════════════════════ */
window.AMBULANCE_DATA = {
  national: [
    {id:'999',name:'জাতীয় জরুরি সেবা',number:'999',icon:'🚨',type:'emergency',description:'পুলিশ, ফায়ার ও অ্যাম্বুলেন্স — ২৪/৭',tollFree:true,coverage:'সারাদেশ',priority:1},
    {id:'16263',name:'স্বাস্থ্য বাতায়ন',number:'16263',icon:'🏥',type:'health',description:'ডাক্তারি পরামর্শ, অ্যাম্বুলেন্স তথ্য',tollFree:true,coverage:'সারাদেশ',priority:1},
    {id:'16111',name:'বাংলাদেশ কোস্ট গার্ড',number:'16111',icon:'⛵',type:'water',description:'নৌপথে জরুরি সহায়তা',tollFree:true,coverage:'উপকূল',priority:2}
  ],
  districts: {
    'বরিশাল': {
      government: [
        {name:'শের-ই-বাংলা মেডিকেল (সরকারি)',number:'04312173547',type:'সরকারি',category:'hospital',note:'২৪/৭',priority:1},
        {name:'বরিশাল জেনারেল হাসপাতাল',number:'01715005533',type:'সরকারি',category:'hospital',note:'২৪/৭',priority:2},
        {name:'বরিশাল সিটি কর্পোরেশন (ফ্রি)',number:'01722286367, 01723022997',type:'ফ্রি',category:'free',note:'২৪ ঘণ্টা বিনামূল্যে',priority:1},
        {name:'বাসদ ফ্রি অ্যাম্বুলেন্স',number:'01572314085',type:'ফ্রি',category:'free',note:'হটলাইন',priority:2}
      ],
      private: [
        {name:'মাহি অ্যাম্বুলেন্স',number:'01719777992',type:'বেসরকারি',category:'general',note:'শের-ই-বাংলা',priority:1},
        {name:'টিটু অ্যাম্বুলেন্স',number:'01720323996',type:'বেসরকারি',category:'general',note:'বরিশাল সদর',priority:2},
        {name:'বরিশাল অ্যাম্বুলেন্স',number:'01714717024',type:'বেসরকারি',category:'general',note:'হাসপাতাল রোড',priority:2},
        {name:'বেলভিউ হাসপাতাল',number:'01745236243',type:'বেসরকারি',category:'hospital',note:'২৪/৭',priority:2},
        {name:'ল্যাবএইড অ্যাম্বুলেন্স',number:'01766663305',type:'বেসরকারি',category:'ac',note:'AC/ICU',priority:2}
      ]
    },
    'পটুয়াখালী': {
      government: [{name:'পটুয়াখালী মেডিকেল কলেজ',number:'01712163530',type:'সরকারি',category:'hospital',note:'২৪/৭',priority:1}],
      private: [
        {name:'তুষার অ্যাম্বুলেন্স',number:'01853543357',type:'বেসরকারি',category:'general',note:'পটুয়াখালী',priority:1},
        {name:'মর্ডান অ্যাম্বুলেন্স',number:'01798055245',type:'বেসরকারি',category:'general',note:'সদর',priority:1},
        {name:'পটুয়াখালী অ্যাম্বুলেন্স',number:'01627669222',type:'বেসরকারি',category:'ac',note:'AC',priority:2}
      ],
      water: [{name:'নৌ-অ্যাম্বুলেন্স',number:'',type:'নৌ-পথ',category:'water',note:'চর এলাকা',priority:1}]
    },
    'ভোলা': {
      government: [
        {name:'ভোলা সদর হাসপাতাল',number:'01712645252',type:'সরকারি',category:'hospital',note:'২৪/৭',priority:1},
        {name:'ভোলা ডিস্ট্রিক্ট হাসপাতাল',number:'01716074580',type:'সরকারি',category:'hospital',note:'হটলাইন',priority:1}
      ],
      private: [{name:'ভোলা মডেল হাসপাতাল',number:'01798715382',type:'বেসরকারি',category:'general',note:'২৪/৭',priority:2}],
      water: [
        {name:'নৌ-অ্যাম্বুলেন্স (দৌলতখান)',number:'',type:'নৌ-পথ',category:'water',note:'৫০ শয্যা',priority:1},
        {name:'নৌ-অ্যাম্বুলেন্স (চরফ্যাশন)',number:'',type:'নৌ-পথ',category:'water',note:'চর',priority:1},
        {name:'নৌ-অ্যাম্বুলেন্স (লালমোহন)',number:'',type:'নৌ-পথ',category:'water',note:'লালমোহন',priority:1},
        {name:'নৌ-অ্যাম্বুলেন্স (মনপুরা)',number:'',type:'নৌ-পথ',category:'water',note:'দ্বীপ',priority:1}
      ]
    },
    'পিরোজপুর': {
      government: [{name:'পিরোজপুর জেলা হাসপাতাল',number:'046162233',type:'সরকারি',category:'hospital',note:'২৪/৭',priority:1}],
      private: [
        {name:'পিরোজপুর মডার্ন',number:'96540',type:'বেসরকারি',category:'ac',note:'২৪ ঘণ্টা',priority:1},
        {name:'পিরোজপুর মডার্ন (মোবাইল)',number:'01787559646',type:'বেসরকারি',category:'general',note:'২৪/৭',priority:1}
      ],
      free: [{name:'ভান্ডারিয়া উপজেলা (ফ্রি)',number:'01310552066',type:'ফ্রি',category:'free',note:'ভান্ডারিয়া',priority:1}]
    },
    'বরগুনা': {
      government: [
        {name:'বরগুনা জেনারেল হাসপাতাল',number:'044862264',type:'সরকারি',category:'hospital',note:'২৫০ শয্যা',priority:1},
        {name:'বরগুনা সদর হাসপাতাল',number:'01730324884',type:'সরকারি',category:'hospital',note:'সদর',priority:2}
      ],
      private: [
        {name:'শিকদার অ্যাম্বুলেন্স',number:'01713260042',type:'বেসরকারি',category:'ac',note:'বরগুনা→ঢাকা',priority:1},
        {name:'লিটন অ্যাম্বুলেন্স',number:'01725242834',type:'বেসরকারি',category:'general',note:'সদর',priority:2},
        {name:'হাওলাদার অ্যাম্বুলেন্স',number:'01727059122',type:'বেসরকারি',category:'general',note:'সদর',priority:2}
      ],
      water: [{name:'নৌ-অ্যাম্বুলেন্স',number:'',type:'নৌ-পথ',category:'water',note:'নষ্ট',priority:3}]
    },
    'ঝালকাঠি': {
      government: [
        {name:'ঝালকাঠি সদর হাসপাতাল',number:'049862723',type:'সরকারি',category:'hospital',note:'২৪/৭',priority:1},
        {name:'ঝালকাঠি জেলা হাসপাতাল (মোবাইল)',number:'01712163530',type:'সরকারি',category:'hospital',note:'২৪/৭',priority:1},
        {name:'কাঠালিয়া ফায়ার সার্ভিস',number:'16163',type:'ফায়ার',category:'emergency',note:'ফায়ার+অ্যাম্বুলেন্স',priority:2}
      ],
      private: [{name:'ঝালকাঠি অ্যাম্বুলেন্স',number:'01627669222',type:'বেসরকারি',category:'ac',note:'AC/Non-AC',priority:1}]
    }
  }
};

window.AmbulanceDB = {
  allNational(){ return window.AMBULANCE_DATA.national; },
  byDistrict(d){ return window.AMBULANCE_DATA.districts[d] || {}; },
  districts(){ return Object.keys(window.AMBULANCE_DATA.districts); },
  search(q){ const query = (q || '').toLowerCase().trim(); if(!query) return []; const results = []; window.AMBULANCE_DATA.national.forEach(e => { if(e.name.toLowerCase().includes(query) || (e.number||'').includes(query)) results.push(e); }); Object.entries(window.AMBULANCE_DATA.districts).forEach(([dist, cats]) => { Object.entries(cats).forEach(([cat, items]) => { items.forEach(item => { if(item.name.toLowerCase().includes(query) || (item.number||'').includes(query)) results.push(Object.assign({}, item, {district: dist, category: cat})); }); }); }); return results; },
  totalCount(){ let total = window.AMBULANCE_DATA.national.length; Object.values(window.AMBULANCE_DATA.districts).forEach(cats => { Object.values(cats).forEach(arr => total += arr.length); }); return total; },
  byUpazila(district, upazila){ const d = window.AMBULANCE_DATA.districts[district]; if(!d) return []; const out = []; ['upazilaUHC','upazilaFire','upazilaPrivate','upazilaWater'].forEach(key => { (d[key] || []).forEach(item => { if(item.upazila === upazila) out.push(item); }); }); return out.sort((a,b) => (a.priority||9) - (b.priority||9)); },
  allUpazilas(district){ const d = window.AMBULANCE_DATA.districts[district]; if(!d) return []; const set = new Set(); ['upazilaUHC','upazilaFire','upazilaPrivate','upazilaWater'].forEach(key => { (d[key] || []).forEach(item => { if(item.upazila) set.add(item.upazila); }); }); return Array.from(set).sort(); }
};

/* ═══════════════════════════════════════════════════════════
   MODULE 18: ambulance-upazila.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
if(!window.AMBULANCE_DATA) return;
const UHC_AMBULANCES = {
  'বরিশাল':[
    {upazila:'বরিশাল সদর',name:'বরিশাল সদর উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'বাকেরগঞ্জ',name:'বাকেরগঞ্জ উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'বাবুগঞ্জ',name:'বাবুগঞ্জ উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'উজিরপুর',name:'উজিরপুর উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'বানারীপাড়া',name:'বানারীপাড়া উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'গৌরনদী',name:'গৌরনদী উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'আগৈলঝাড়া',name:'আগৈলঝাড়া উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'মেহেন্দিগঞ্জ',name:'মেহেন্দিগঞ্জ উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'01730324414',verified:true},
    {upazila:'মুলাদী',name:'মুলাদী উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'হিজলা',name:'হিজলা উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false}
  ],
  'পটুয়াখালী':[
    {upazila:'পটুয়াখালী সদর',name:'পটুয়াখালী সদর উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'বাউফল',name:'বাউফল উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'দশমিনা',name:'দশমিনা উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'গলাচিপা',name:'গলাচিপা উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'কলাপাড়া',name:'কলাপাড়া উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'মির্জাগঞ্জ',name:'মির্জাগঞ্জ উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'রাঙ্গাবালী',name:'রাঙ্গাবালী উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'দুমকি',name:'দুমকি উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false}
  ],
  'ভোলা':[
    {upazila:'ভোলা সদর',name:'ভোলা সদর উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'বোরহানউদ্দিন',name:'বোরহানউদ্দিন উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'চরফ্যাশন',name:'চরফ্যাশন উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'দৌলতখান',name:'দৌলতখান উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'লালমোহন',name:'লালমোহন উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'মনপুরা',name:'মনপুরা উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'তজুমদ্দিন',name:'তজুমদ্দিন উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false}
  ],
  'পিরোজপুর':[
    {upazila:'পিরোজপুর সদর',name:'পিরোজপুর সদর উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'ভান্ডারিয়া',name:'ভান্ডারিয়া উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'01310552066',verified:true},
    {upazila:'কাউখালী',name:'কাউখালী উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'মঠবাড়িয়া',name:'মঠবাড়িয়া উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'নাজিরপুর',name:'নাজিরপুর উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'নেছারাবাদ',name:'নেছারাবাদ উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'জিয়ানগর',name:'জিয়ানগর উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false}
  ],
  'বরগুনা':[
    {upazila:'বরগুনা সদর',name:'বরগুনা সদর উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'01720543495',verified:true},
    {upazila:'আমতলী',name:'আমতলী উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'বামনা',name:'বামনা উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'বেতাগী',name:'বেতাগী উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'পাথরঘাটা',name:'পাথরঘাটা উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'তালতলী',name:'তালতলী উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false}
  ],
  'ঝালকাঠি':[
    {upazila:'ঝালকাঠি সদর',name:'ঝালকাঠি সদর উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'01711311282',verified:true},
    {upazila:'কাঠালিয়া',name:'কাঠালিয়া উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'01730324423',verified:true},
    {upazila:'নলছিটি',name:'নলছিটি উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false},
    {upazila:'রাজাপুর',name:'রাজাপুর উপজেলা স্বাস্থ্য কমপ্লেক্স',number:'',verified:false}
  ]
};
function ensureStructure(district){ if(!window.AMBULANCE_DATA.districts[district]) window.AMBULANCE_DATA.districts[district] = {}; const d = window.AMBULANCE_DATA.districts[district]; if(!d.upazilaUHC) d.upazilaUHC = []; if(!d.upazilaFire) d.upazilaFire = []; if(!d.upazilaPrivate) d.upazilaPrivate = []; if(!d.upazilaWater) d.upazilaWater = []; return d; }
let addedCount = 0;
Object.entries(UHC_AMBULANCES).forEach(([district, items]) => { const d = ensureStructure(district); items.forEach(item => { d.upazilaUHC.push({name:item.name,number:item.number,type:'সরকারি',category:'hospital',upazila:item.upazila,note:item.number ? 'উপজেলা UHC' : '২৪/৭',verified:item.verified,priority:1}); addedCount++; }); });
console.log('%c✅ ambulance-upazila.js — ' + addedCount + ' entries','color:#00838F;font-weight:700');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 19: ambulance-ui.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
const $ = id => document.getElementById(id);
const toBn = n => String(n||0).replace(/[0-9]/g, d => '০১২৩৪৫৬৭৮৯'[+d]);
const esc = s => String(s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let currentDistrict = 'বরিশাল', currentUpazila = '', searchQuery = '';

window.renderAmbulanceDirectory = function(){
  const container = $('ambulanceDirectory'); if(!container) return;
  const total = window.AmbulanceDB.totalCount();
  container.innerHTML =
    '<div class="amb-header"><div><div class="amb-title">🚑 অ্যাম্বুলেন্স সেবা</div><div class="amb-sub">' + toBn(total) + 'টি সেবা — ২৪/৭</div></div></div>' +
    '<div class="amb-search-wrap"><input type="text" class="amb-search-input" id="ambSearch" placeholder="সেবার নাম বা নম্বর" oninput="__ambSearch(this.value)"><button class="amb-search-clear" onclick="__ambClearSearch()">✕</button></div>' +
    '<div class="amb-district-row">' + window.AmbulanceDB.districts().map(d => '<button class="amb-district-chip ' + (currentDistrict===d?'active':'') + '" onclick="__ambSetDistrict(\'' + d + '\')">' + d + '</button>').join('') + '</div>' +
    (currentDistrict ? '<div class="amb-district-row"><button class="amb-district-chip small ' + (currentUpazila===''?'active':'') + '" onclick="__ambSetUpazila(\'\')">সব উপজেলা</button>' + window.AmbulanceDB.allUpazilas(currentDistrict).map(u => '<button class="amb-district-chip small ' + (currentUpazila===u?'active':'') + '" onclick="__ambSetUpazila(\'' + u + '\')">' + u + '</button>').join('') + '</div>' : '') +
    '<div id="ambResults"></div>';
  renderAmbulanceResults();
};

function renderAmbulanceResults(){
  const results = $('ambResults'); if(!results) return;
  if(searchQuery){
    const list = window.AmbulanceDB.search(searchQuery);
    if(!list.length){ results.innerHTML = '<div class="amb-empty"><span class="ic">🔍</span><b>কিছু পাওয়া যায়নি</b></div>'; return; }
    results.innerHTML = '<div class="amb-section-header"><span class="icon">🔍</span>সার্চ ফলাফল<span class="count">' + toBn(list.length) + '</span></div>' + list.map(e => ambulanceCardHTML(e)).join('');
    return;
  }
  let html = '<div class="amb-section-header"><span class="icon">🇧🇩</span>জাতীয় জরুরি সেবা<span class="count">' + toBn(window.AMBULANCE_DATA.national.length) + '</span></div>' + window.AMBULANCE_DATA.national.map(e => ambulanceCardHTML(e)).join('');
  if(currentUpazila){
    const upzItems = window.AmbulanceDB.byUpazila(currentDistrict, currentUpazila);
    if(upzItems.length){ html += '<div class="amb-section-header"><span class="icon">📍</span>' + esc(currentUpazila) + '<span class="count">' + toBn(upzItems.length) + '</span></div>' + upzItems.map(e => ambulanceCardHTML(e)).join(''); }
  } else {
    const d = window.AmbulanceDB.byDistrict(currentDistrict);
    ['government','private','free','water','longDistance','upazilaUHC','upazilaFire','upazilaPrivate','upazilaWater'].forEach(cat => {
      const items = d[cat]; if(!items || !items.length) return;
      html += '<div class="amb-section-header"><span class="icon">📞</span>' + currentDistrict + ' — ' + cat + '<span class="count">' + toBn(items.length) + '</span></div>' + items.map(e => ambulanceCardHTML(e)).join('');
    });
  }
  results.innerHTML = html;
}

function ambulanceCardHTML(e){
  const typeClass = e.category === 'free' ? 'free' : e.category === 'water' ? 'water' : e.category === 'hospital' ? 'government' : 'private';
  const typeLabel = e.category === 'free' ? '🆓 ফ্রি' : e.category === 'water' ? '⛵ নৌ' : e.category === 'hospital' ? '🏥 হাসপাতাল' : e.category === 'ac' ? '❄️ AC' : '🚑 সাধারণ';
  const callNum = (e.number || '').replace(/[^\d+]/g, '').split(',')[0];
  return '<div class="amb-card type-' + typeClass + '" onclick="__ambShowDetail(\'' + esc(e.name) + '\')">' +
    '<div class="amb-card-icon ' + typeClass + '">' + (e.icon || '🚑') + '</div>' +
    '<div class="amb-card-body">' +
      '<div class="amb-card-name">' + esc(e.name) + '</div>' +
      '<div class="amb-card-note">' + typeLabel + (e.note ? ' · ' + esc(e.note) : '') + '</div>' +
    '</div>' +
    '<div class="amb-card-number">' + esc(e.number || '—') + '</div>' +
    (callNum && callNum.length >= 3 ? '<button class="amb-card-call" onclick="event.stopPropagation();window.location.href=\'tel:' + callNum + '\'">📞</button>' : '') +
  '</div>';
}

window.__ambSetDistrict = function(d){ currentDistrict = d; currentUpazila = ''; renderAmbulanceDirectory(); };
window.__ambSetUpazila = function(u){ currentUpazila = u; renderAmbulanceResults(); };
window.__ambSearch = function(v){ searchQuery = v || ''; renderAmbulanceResults(); };
window.__ambClearSearch = function(){ searchQuery = ''; const i = $('ambSearch'); if(i) i.value=''; renderAmbulanceResults(); };

window.__ambShowDetail = function(name){
  let found = window.AMBULANCE_DATA.national.find(e => e.name === name);
  if(!found){
    outer:
    for(const [dist, cats] of Object.entries(window.AMBULANCE_DATA.districts)){
      for(const [cat, items] of Object.entries(cats)){
        if(!Array.isArray(items)) continue;
        const f = items.find(i => i.name === name);
        if(f){ found = Object.assign({}, f, {district:dist, category:cat}); break outer; }
      }
    }
  }
  if(!found) return;
  const numbers = (found.number||'').split(',').map(n => n.trim()).filter(Boolean);
  const callBtns = numbers.map(n => { const c = n.replace(/[^\d+]/g,''); if(c.length < 3) return ''; return '<button class="amb-detail-call-btn" onclick="window.location.href=\'tel:' + c + '\'">📞 ' + esc(n) + '</button>'; }).join('');
  const html = '<div class="mhdr"><div class="mt">🚑 অ্যাম্বুলেন্স</div><button class="cb" onclick="closeModal()">✕</button></div>' +
    '<div class="amb-detail"><div class="amb-detail-icon">' + (found.icon||'🚑') + '</div><div class="amb-detail-name">' + esc(found.name) + '</div>' +
    (found.note?'<div class="amb-detail-note">' + esc(found.note) + '</div>':'') +
    (numbers.length ? callBtns : '<div style="padding:14px;background:#FFF8E1;border-radius:10px;font-size:13px">⚠️ সরাসরি নম্বর নেই — ৯৯৯ বা ১৬২৬৩ ব্যবহার করুন</div>') +
    '</div>';
  if(typeof window.openModal === 'function') window.openModal(html);
};

console.log('%c✅ ambulance-ui.js loaded','color:#C62828;font-weight:700');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 20: emergency-data.js
   ═══════════════════════════════════════════════════════════ */
window.EMERGENCY_DATA = {
  national: [
    {id:'999',name:'ন্যাশনাল ইমার্জেন্সি সার্ভিস',number:'999',icon:'🚨',category:'all',color:'red',description:'পুলিশ, ফায়ার, অ্যাম্বুলেন্স — সব জরুরি সেবা',tollFree:true,available:'২৪/৭',priority:1},
    {id:'102',name:'ফায়ার সার্ভিস ও সিভিল ডিফেন্স',number:'102',altNumber:'16163',icon:'🚒',category:'fire',color:'red',description:'অগ্নিকাণ্ড, উদ্ধার, দুর্ঘটনা',tollFree:true,available:'২৪/৭',priority:1},
    {id:'16263',name:'স্বাস্থ্য বাতায়ন',number:'16263',icon:'🏥',category:'health',color:'blue',description:'ডাক্তারি পরামর্শ, অ্যাম্বুলেন্স',tollFree:true,available:'২৪/৭',priority:2},
    {id:'1090',name:'দুর্যোগের আগাম সতর্কবার্তা',number:'1090',icon:'🌪️',category:'disaster',color:'amber',description:'ঘূর্ণিঝড়, বন্যা, সুনামি',tollFree:true,available:'২৪/৭',priority:2},
    {id:'109',name:'নারী ও শিশু নির্যাতন প্রতিরোধ',number:'109',icon:'🛡️',category:'women-child',color:'purple',description:'নির্যাতন, হয়রানি, বাল্যবিবাহ',tollFree:true,available:'২৪/৭',priority:2},
    {id:'106',name:'দুদক হটলাইন',number:'106',icon:'⚖️',category:'anti-corruption',color:'indigo',description:'দুর্নীতির অভিযোগ',tollFree:true,available:'কর্মদিবস',priority:3},
    {id:'333',name:'জাতীয় তথ্য ও সেবা হটলাইন',number:'333',icon:'ℹ️',category:'info',color:'cyan',description:'সরকারি সেবা',tollFree:true,available:'২৪/৭',priority:3},
    {id:'1098',name:'শিশু সহায়তা হটলাইন',number:'1098',icon:'👶',category:'child',color:'green',description:'শিশু নির্যাতন, পাচার',tollFree:true,available:'২৪/৭',priority:3},
    {id:'10921',name:'নারী ও শিশু হেল্পলাইন',number:'10921',icon:'♀️',category:'women',color:'pink',description:'আইনি পরামর্শ, কাউন্সেলিং',tollFree:true,available:'২৪/৭',priority:3}
  ],
  barishalDivision: {
    'বরিশাল': {
      police: [
        {name:'মেট্রোপলিটন পুলিশ কন্ট্রোল রুম',number:'01769690126',icon:'👮',priority:1},
        {name:'পুলিশ কমিশনার (BMP)',number:'01713374525',icon:'👮‍♂️',priority:2},
        {name:'জেলা পুলিশ সুপার (SP)',number:'01769072556',icon:'👮',priority:2}
      ],
      fire: [
        {name:'বরিশাল ডিভিশনাল কন্ট্রোল রুম',number:'01878001111',icon:'🚒',priority:1},
        {name:'বরিশাল সদর ফায়ার স্টেশন',number:'0431-65222',icon:'🚒',priority:2}
      ],
      health: [
        {name:'সিভিল সার্জন অফিস',number:'01712265410',icon:'🏥',priority:1},
        {name:'শের-ই-বাংলা মেডিকেল (ইমার্জেন্সি)',number:'04312173547',icon:'🏥',priority:1},
        {name:'বরিশাল জেনারেল হাসপাতাল',number:'01715005533',icon:'🏥',priority:2}
      ],
      military: [
        {name:'সেনাবাহিনী (ISPR)',number:'01769072556',altNumber:'01769072456',icon:'🪖',priority:1},
        {name:'নৌবাহিনী (খুলনা-বরিশাল)',number:'01769784140',icon:'⚓',priority:2},
        {name:'RAB-8 বরিশাল',number:'01777711441',icon:'🛡️',priority:2}
      ],
      ambulance: [
        {name:'ল্যাবএইড অ্যাম্বুলেন্স',number:'01766663305',icon:'🚑',priority:1},
        {name:'টিটু অ্যাম্বুলেন্স',number:'01720323996',icon:'🚑',priority:2}
      ]
    },
    'পটুয়াখালী': {
      police:[{name:'পুলিশ সুপার (SP)',number:'01769073120',icon:'👮',priority:1}],
      fire:[{name:'ডিভিশনাল কন্ট্রোল রুম',number:'01878001111',icon:'🚒',priority:1},{name:'পটুয়াখালী ফায়ার স্টেশন',number:'0441-62222',icon:'🚒',priority:2}],
      health:[{name:'সিভিল সার্জন অফিস',number:'01769073120',icon:'🏥',priority:1},{name:'পটুয়াখালী মেডিকেল কলেজ',number:'01712163530',icon:'🏥',priority:1}],
      military:[{name:'সেনাবাহিনী (ISPR)',number:'01769073120',icon:'🪖',priority:1},{name:'RAB-8 CPC-1',number:'01777711441',icon:'🛡️',priority:2}],
      ambulance:[]
    },
    'ভোলা': {
      police:[{name:'পুলিশ সুপার (SP)',number:'01713374525',icon:'👮',priority:1}],
      fire:[{name:'ডিভিশনাল কন্ট্রোল রুম',number:'01878001111',icon:'🚒',priority:1},{name:'ভোলা ফায়ার স্টেশন',number:'0491-62222',icon:'🚒',priority:2}],
      health:[{name:'সিভিল সার্জন অফিস',number:'01712265410',icon:'🏥',priority:1},{name:'ভোলা সদর হাসপাতাল',number:'0491-62222',icon:'🏥',priority:2}],
      military:[{name:'নৌবাহিনী (ভোলা)',number:'01769796227',icon:'⚓',priority:1},{name:'RAB-8 ভোলা',number:'01777711441',icon:'🛡️',priority:2}],
      ambulance:[]
    },
    'পিরোজপুর': {
      police:[{name:'পুলিশ সুপার (SP)',number:'01769078298',icon:'👮',priority:1}],
      fire:[{name:'ডিভিশনাল কন্ট্রোল রুম',number:'01878001111',icon:'🚒',priority:1},{name:'পিরোজপুর ফায়ার স্টেশন',number:'0461-62222',icon:'🚒',priority:2}],
      health:[{name:'সিভিল সার্জন অফিস',number:'01712265410',icon:'🏥',priority:1},{name:'পিরোজপুর সদর হাসপাতাল',number:'0461-62222',icon:'🏥',priority:2}],
      military:[{name:'সেনাবাহিনী (ISPR)',number:'01769078298',icon:'🪖',priority:1},{name:'RAB-8',number:'01777711441',icon:'🛡️',priority:2}],
      ambulance:[]
    },
    'বরগুনা': {
      police:[{name:'পুলিশ সুপার (SP)',number:'01713374525',icon:'👮',priority:1}],
      fire:[{name:'ডিভিশনাল কন্ট্রোল রুম',number:'01878001111',icon:'🚒',priority:1},{name:'বরগুনা ফায়ার স্টেশন',number:'0448-62386',icon:'🚒',priority:2}],
      health:[{name:'সিভিল সার্জন অফিস',number:'01712857544',icon:'🏥',priority:1},{name:'বরগুনা জেনারেল হাসপাতাল',number:'0448-62386',icon:'🏥',priority:2}],
      military:[{name:'নৌবাহিনী (বরগুনা)',number:'01769781019',icon:'⚓',priority:1},{name:'RAB-8',number:'01777711441',icon:'🛡️',priority:2}],
      ambulance:[]
    },
    'ঝালকাঠি': {
      police:[{name:'পুলিশ সুপার (SP)',number:'01769072108',icon:'👮',priority:1}],
      fire:[{name:'ডিভিশনাল কন্ট্রোল রুম',number:'01878001111',icon:'🚒',priority:1}],
      health:[{name:'সিভিল সার্জন অফিস',number:'01712265410',icon:'🏥',priority:1},{name:'ঝালকাঠি সদর হাসপাতাল',number:'01711311282',icon:'🏥',priority:2}],
      military:[{name:'সেনাবাহিনী (ISPR)',number:'01769072108',icon:'🪖',priority:1},{name:'RAB-8',number:'01777711441',icon:'🛡️',priority:2}],
      ambulance:[]
    }
  },
  categories: {
    all:{label:'সব',icon:'🚨'},fire:{label:'ফায়ার',icon:'🚒'},health:{label:'স্বাস্থ্য',icon:'🏥'},
    disaster:{label:'দুর্যোগ',icon:'🌪️'},'women-child':{label:'নারী-শিশু',icon:'🛡️'},
    'anti-corruption':{label:'দুদক',icon:'⚖️'},info:{label:'তথ্য',icon:'ℹ️'},
    child:{label:'শিশু',icon:'👶'},women:{label:'নারী',icon:'♀️'}
  }
};

window.EmergencyDB = {
  allNational(){ return window.EMERGENCY_DATA.national; },
  byCategory(cat){ return window.EMERGENCY_DATA.national.filter(e => e.category === cat); },
  byDistrict(district){ return window.EMERGENCY_DATA.barishalDivision[district] || {}; },
  districts(){ return Object.keys(window.EMERGENCY_DATA.barishalDivision); },
  search(query){
    const q = (query || '').toLowerCase().trim(); if(!q) return { national: [], district: [] };
    const national = window.EMERGENCY_DATA.national.filter(e => e.name.toLowerCase().includes(q) || (e.number||'').includes(q));
    const district = [];
    Object.entries(window.EMERGENCY_DATA.barishalDivision).forEach(([dist, cats]) => { Object.entries(cats).forEach(([cat, items]) => { items.forEach(item => { if(item.name.toLowerCase().includes(q) || (item.number||'').includes(q)) district.push(Object.assign({}, item, {district:dist, category:cat})); }); }); });
    return { national, district };
  }
};

/* ═══════════════════════════════════════════════════════════
   MODULE 21: emergency-ui.js
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
const $ = id => document.getElementById(id);
const toBn = n => String(n||0).replace(/[0-9]/g, d => '০১২৩৪৫৬৭৮৯'[+d]);
const esc = s => String(s||'').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let currentDistrict = 'বরিশাল', currentCategory = 'all', searchQuery = '';

window.renderEmergencyDirectory = function(){
  const c = $('emergencyDirectory'); if(!c) return;
  c.innerHTML =
    '<div class="emergency-header"><div><div class="emergency-title">🚨 জরুরি সেবা</div><div class="emergency-sub">২৪/৭ — এক ট্যাপে কল</div></div></div>' +
    '<div class="emergency-search-wrap"><input type="text" class="emergency-search-input" id="emergencySearch" placeholder="নাম বা নম্বর" oninput="__emergencySearch(this.value)"><button class="emergency-search-clear" onclick="__emergencyClearSearch()">✕</button></div>' +
    '<div class="emergency-district-row">' +
      '<button class="emergency-district-chip ' + (currentDistrict===''?'active':'') + '" onclick="__emergencySetDistrict(\'\')">🌐 সব</button>' +
      window.EmergencyDB.districts().map(d => '<button class="emergency-district-chip ' + (currentDistrict===d?'active':'') + '" onclick="__emergencySetDistrict(\'' + d + '\')">' + d + '</button>').join('') +
    '</div>' +
    '<div class="emergency-cat-tabs">' +
      Object.entries(window.EMERGENCY_DATA.categories).map(([key, cat]) => '<button class="emergency-cat-tab ' + (currentCategory===key?'active':'') + '" onclick="__emergencySetCategory(\'' + key + '\')">' + cat.icon + ' ' + cat.label + '</button>').join('') +
    '</div>' +
    '<div id="emergencyResults"></div>';
  renderEmergencyResults();
};

function renderEmergencyResults(){
  const results = $('emergencyResults'); if(!results) return;
  if(searchQuery){
    const { national, district } = window.EmergencyDB.search(searchQuery);
    if(!national.length && !district.length){ results.innerHTML = '<div class="empty"><div class="empty-ic">🔍</div><div class="empty-t">কিছু পাওয়া যায়নি</div></div>'; return; }
    let html = '';
    if(national.length) html += '<div class="emergency-section-header"><span class="icon">🇧🇩</span>জাতীয়<span class="count">' + toBn(national.length) + '</span></div>' + national.map(e => emergencyCardHTML(e)).join('');
    if(district.length) html += '<div class="emergency-section-header"><span class="icon">📍</span>জেলা<span class="count">' + toBn(district.length) + '</span></div>' + district.map(e => emergencyCardHTML(e)).join('');
    results.innerHTML = html;
    return;
  }
  let html = '';
  let nationalList = window.EmergencyDB.allNational();
  if(currentCategory !== 'all') nationalList = nationalList.filter(e => e.category === currentCategory);
  if(nationalList.length) html += '<div class="emergency-section-header"><span class="icon">🇧🇩</span>জাতীয় হটলাইন<span class="count">' + toBn(nationalList.length) + '</span></div>' + nationalList.map(e => emergencyCardHTML(e)).join('');
  if(currentDistrict){
    const d = window.EmergencyDB.byDistrict(currentDistrict);
    const catLabels = { police:{icon:'👮',label:'পুলিশ'}, fire:{icon:'🚒',label:'ফায়ার'}, health:{icon:'🏥',label:'স্বাস্থ্য'}, military:{icon:'🪖',label:'সেনা/র‍্যাব'}, ambulance:{icon:'🚑',label:'অ্যাম্বুলেন্স'} };
    Object.entries(d).forEach(([cat, items]) => {
      if(!items || !items.length) return;
      const label = catLabels[cat] || {icon:'📞',label:cat};
      html += '<div class="emergency-section-header"><span class="icon">' + label.icon + '</span>' + currentDistrict + ' — ' + label.label + '<span class="count">' + toBn(items.length) + '</span></div>' + items.sort((a,b)=>(a.priority||9)-(b.priority||9)).map(e => emergencyCardHTML(e)).join('');
    });
  }
  if(!html) html = '<div class="empty"><div class="empty-ic">🚨</div><div class="empty-t">কিছু নেই</div></div>';
  results.innerHTML = html;
}

function emergencyCardHTML(e){
  const colorClass = e.color || 'red';
  const priority = e.priority || 3;
  const numDisplay = e.number || '—';
  const callNumber = (e.number || '').replace(/[^\d+]/g, '');
  return '<div class="emergency-card priority-' + priority + '">' +
    '<div class="emergency-card-icon ' + colorClass + '">' + (e.icon || '📞') + '</div>' +
    '<div class="emergency-card-body">' +
      '<div class="emergency-card-name">' + esc(e.name) + '</div>' +
      (e.description ? '<div class="emergency-card-desc">' + esc(e.description) + '</div>' : '') +
      '<div style="display:flex;gap:6px;flex-wrap:wrap">' +
        '<span class="badge ' + (e.tollFree?'badge-g':'badge-bl') + '">' + (e.tollFree?'✅ টোল-ফ্রি':'📞') + '</span>' +
        '<span class="badge badge-g">🕐 ' + (e.available||'২৪/৭') + '</span>' +
      '</div>' +
    '</div>' +
    '<div class="emergency-card-number">' + esc(numDisplay) + '</div>' +
    (callNumber && callNumber.length >= 3 ? '<button class="emergency-card-call" onclick="event.stopPropagation();window.location.href=\'tel:' + callNumber + '\'">📞</button>' : '') +
  '</div>';
}

window.__emergencySetDistrict = function(d){ currentDistrict = d; renderEmergencyDirectory(); };
window.__emergencySetCategory = function(c){ currentCategory = c; renderEmergencyDirectory(); };
window.__emergencySearch = function(q){ searchQuery = q || ''; renderEmergencyResults(); };
window.__emergencyClearSearch = function(){ searchQuery = ''; const i = $('emergencySearch'); if(i) i.value=''; renderEmergencyResults(); };

console.log('%c✅ emergency-ui.js loaded','color:#43A047;font-weight:700');
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 22: v7-auth.js — Server OTP Auth (Cloudflare backend)
   ------------------------------------------------------------
   আগে এটি Firebase client-side phone auth + reCAPTCHA ব্যবহার করত।
   এখন এটি backend-এর নিজস্ব OTP API কল করে (api-client.js →
   window.BloodAPI) — server-side hashed OTP, httpOnly session cookie।
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
const $ = id => document.getElementById(id);
const lsGet = (k,fb) => { try{ const r=localStorage.getItem(k); return r==null?fb:JSON.parse(r); }catch(e){ return fb; } };
const lsSet = (k,v) => { try{ localStorage.setItem(k, JSON.stringify(v)); }catch(e){} };
const toast = (m,t) => { if(typeof window.toast==='function') window.toast(m,t); };
const AUTH_KEYS = { SESSION: 'v7Session', PENDING: 'v7PendingPhone' };
let userRole = 'guest', pendingPhone = null;

// backend donor row (snake_case) -> old app's donor object shape
function mapServerDonor(d){
  if(!d) return null;
  return {
    id: d.id, name: d.name, phone: d.phone, blood: d.blood,
    district: d.district, upazila: d.upazila,
    lastDonation: d.last_donation || null, age: d.age || null, weight: d.weight || null,
    gender: d.gender || null, emergency: d.emergency || 'yes',
    verified: !!d.verified, bloodVerified: !!d.blood_verified,
    nidRejected: !!d.nid_rejected, nidRejectReason: d.nid_reject_reason || null,
    suspended: !!d.suspended, suspendReason: d.suspend_reason || null,
    donations: d.donations || 0, responseRate: d.response_rate || 0,
    createdAt: d.created_at || Date.now(), availability: null
  };
}
window.__mapServerDonor = mapServerDonor;

function updateAuthUI(){
  const s = lsGet(AUTH_KEYS.SESSION, null);
  const el = $('v7SessionChip'); if(!el) return;
  if(!s || !s.phone){ el.textContent = '👤 অতিথি'; el.className = 'v7-session-chip guest'; }
  else if(s.role === 'admin'){ el.textContent = '👑 Admin'; el.className = 'v7-session-chip admin'; }
  else { el.textContent = '📱 ' + s.phone; el.className = 'v7-session-chip donor'; }
}

// পেজ লোডে existing session cookie আছে কিনা চেক করে (refresh-এর পরও লগইন থাকে)
async function restoreSession(){
  if(!window.BloodAPI) { console.warn('[v7-auth] api-client.js missing'); return; }
  try{
    const res = await window.BloodAPI.me();
    if(!res || !res.success) { updateAuthUI(); return; } // no session — guest
    userRole = res.role || 'donor';
    lsSet(AUTH_KEYS.SESSION, { phone: (res.donor && res.donor.phone) || null, role: userRole, hasProfile: !!res.donor });
    if(res.donor){
      const donor = mapServerDonor(res.donor);
      lsSet('barishalProfile', donor);
      if(Array.isArray(window.donors) && !window.donors.some(x => x.id === donor.id)) window.donors.push(donor);
    }
    updateAuthUI();
  }catch(e){ console.warn('[v7-auth] session restore failed', e); }
}

window.v7StartPhoneAuth = function(){
  const html = '<div class="mhdr"><div class="mt">📱 ফোন নম্বর যাচাই</div><button class="cb" onclick="closeModal()">✕</button></div>' +
    '<p style="font-size:12.5px;color:var(--text2);line-height:1.6;margin-bottom:14px">৬-সংখ্যার OTP SMS-এ আসবে। এটা আপনার স্থায়ী অ্যাকাউন্ট।</p>' +
    '<div class="field"><label>মোবাইল নম্বর</label><input type="tel" id="v7PhoneInput" placeholder="01XXXXXXXXX" maxlength="11" oninput="this.value=this.value.replace(/\\D/g,\'\').slice(0,11)"></div>' +
    '<button class="btn btn-p" id="v7SendOtpBtn" onclick="v7SendOtp()">📤 OTP পাঠান</button>';
  if(typeof window.openModal==='function') window.openModal(html);
};
window.v7SendOtp = async function(){
  const inp = $('v7PhoneInput'); if(!inp) return;
  const phone = (inp.value || '').trim();
  if(!/^01[3-9]\d{8}$/.test(phone)){ toast('সঠিক ১১-সংখ্যার নম্বর দিন','error'); return; }
  const btn = $('v7SendOtpBtn'); if(btn){ btn.disabled = true; btn.textContent = '⏳...'; }
  try{
    const res = await window.BloodAPI.sendOtp(phone);
    if(!res.success){ toast('❌ ' + (res.message || 'ব্যর্থ'),'error'); if(btn){ btn.disabled = false; btn.textContent = '📤 OTP পাঠান'; } return; }
    pendingPhone = phone; lsSet(AUTH_KEYS.PENDING, phone);
    showOtpDialog(phone, res.devOTP);
  }catch(e){ toast('❌ নেটওয়ার্ক সমস্যা','error'); if(btn){ btn.disabled = false; btn.textContent = '📤 OTP পাঠান'; } }
};
function showOtpDialog(phone, devOTP){
  const hint = devOTP ? ('<p style="font-size:12px;color:var(--red);margin-bottom:8px">DEV MODE OTP: <b>' + devOTP + '</b></p>') : '';
  const html = '<div class="mhdr"><div class="mt">🔐 OTP দিন</div><button class="cb" onclick="closeModal()">✕</button></div>' +
    '<p style="font-size:13px;color:var(--text2);margin-bottom:10px"><b>' + phone + '</b>-এ ৬-সংখ্যার কোড পাঠানো হয়েছে।</p>' + hint +
    '<div class="field"><label>OTP</label><input type="tel" id="v7OtpInput" maxlength="6" placeholder="123456" style="letter-spacing:8px;text-align:center;font-size:22px;font-weight:700" oninput="this.value=this.value.replace(/\\D/g,\'\')"></div>' +
    '<button class="btn btn-p" id="v7VerifyBtn" onclick="v7VerifyOtp()">✅ যাচাই করুন</button>';
  if(typeof window.openModal==='function') window.openModal(html);
  setTimeout(() => { const i = $('v7OtpInput'); if(i) i.focus(); }, 100);
}
window.v7VerifyOtp = async function(){
  const otp = ($('v7OtpInput')||{}).value || '';
  const phone = pendingPhone || lsGet(AUTH_KEYS.PENDING, null);
  if(otp.length !== 6){ toast('৬-সংখ্যার কোড দিন','error'); return; }
  if(!phone){ toast('আগে ফোন নম্বর দিন','error'); return; }
  const btn = $('v7VerifyBtn'); if(btn){ btn.disabled = true; btn.textContent = '⏳...'; }
  try{
    const res = await window.BloodAPI.verifyOtp(phone, otp);
    if(!res.success){ toast('❌ ' + (res.message || 'ব্যর্থ'),'error'); if(btn){ btn.disabled = false; btn.textContent = '✅ যাচাই করুন'; } return; }
    userRole = res.role || 'donor';
    lsSet(AUTH_KEYS.SESSION, { phone, role: userRole, hasProfile: !!res.hasProfile });
    if(typeof closeModal==='function') closeModal();
    updateAuthUI();
    if(res.hasProfile){
      const me = await window.BloodAPI.me();
      if(me && me.success && me.donor) lsSet('barishalProfile', mapServerDonor(me.donor));
      toast('✅ লগইন সফল','success');
      if(typeof showScreen==='function') showScreen('profile');
    } else {
      toast('✅ ফোন verified — এবার প্রোফাইল তৈরি করুন','success');
      if(typeof showScreen==='function') showScreen('register');
    }
  }catch(e){ toast('❌ নেটওয়ার্ক সমস্যা','error'); if(btn){ btn.disabled = false; btn.textContent = '✅ যাচাই করুন'; } }
};
window.v7SignOut = async function(){
  if(!confirm('লগ-আউট করবেন?')) return;
  try{ if(window.BloodAPI) await window.BloodAPI.logout(); }catch(e){}
  lsSet(AUTH_KEYS.SESSION, null); lsSet('barishalProfile', null); userRole = 'guest';
  toast('👋 লগ-আউট','success');
  if(typeof showScreen==='function') showScreen('home');
  updateAuthUI();
};
window.v7GetSession = function(){ return lsGet(AUTH_KEYS.SESSION, null); };
window.v7GetRole = function(){ return userRole; };
window.v7IsAdmin = function(){ return userRole === 'admin'; };
window.v7IsSignedIn = function(){ const s = lsGet(AUTH_KEYS.SESSION, null); return !!(s && s.phone); };
function boot(){
  restoreSession();
  setTimeout(updateAuthUI, 800);
  console.log('%c✅ v7-auth.js loaded (server OTP)','color:#1565C0;font-weight:700');
}
if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
window.V7Auth = { startPhoneAuth: window.v7StartPhoneAuth, signOut: window.v7SignOut, getSession: window.v7GetSession, getRole: window.v7GetRole };
})();

/* ═══════════════════════════════════════════════════════════
   MODULE 23: v9-gate.js — Registration Gate
   ═══════════════════════════════════════════════════════════ */
(function(){
'use strict';
const $ = id => document.getElementById(id);
const lsGet = (k,fb) => { try{ const r=localStorage.getItem(k); return r==null?fb:JSON.parse(r); }catch(e){ return fb; } };
function isRegistered(){ const profile = lsGet('barishalProfile', null); return !!(profile && profile.name && profile.phone && profile.blood); }
function showGateScreen(action){
  document.body.classList.add('gate-locked');
  const gate = document.createElement('div');
  gate.id = 'v9Gate';
  gate.className = 'v9-gate-overlay';
  gate.innerHTML = '<div class="v9-gate-card"><div class="v9-gate-logo">🩸</div><h1 class="v9-gate-title">বরিশাল রক্তদাতা</h1><p class="v9-gate-sub">৬ জেলা • ৪১ উপজেলা • লাইভ নেটওয়ার্ক</p><div class="v9-gate-info"><div class="v9-gate-info-item"><span>🔒</span><div><b>রেজিস্ট্রেশন ছাড়া ব্যবহার করা যাবে না</b><span>ডোনার ও রোগীর তথ্য সুরক্ষার জন্য ৩০ সেকেন্ডে ফ্রি অ্যাকাউন্ট খুলুন</span></div></div></div><div class="v9-gate-benefits"><div class="v9-gate-benefit"><span>✅</span> ডোনার সার্চ</div><div class="v9-gate-benefit"><span>✅</span> জরুরি অনুরোধ</div><div class="v9-gate-benefit"><span>✅</span> GPS দূরত্ব</div><div class="v9-gate-benefit"><span>✅</span> নোটিফিকেশন</div></div><button class="v9-gate-btn primary" onclick="v9StartRegistration()">🩸 ফ্রি রেজিস্টার করুন</button><button class="v9-gate-btn secondary" onclick="v9StartLogin()">ইতিমধ্যে অ্যাকাউন্ট আছে? লগইন</button><a href="index.html" class="v9-gate-home-link">← হোম পেজে ফিরুন</a></div>';
  document.body.appendChild(gate);
  if(action === 'register') setTimeout(() => v9StartRegistration(), 400);
  else if(action === 'login') setTimeout(() => v9StartLogin(), 400);
}
window.v9StartRegistration = function(){ const gate = $('v9Gate'); if(gate) gate.style.display = 'none'; document.body.classList.remove('gate-locked'); if(typeof window.showScreen === 'function') window.showScreen('register'); showBackToGate(); };
window.v9StartLogin = function(){ const gate = $('v9Gate'); if(gate) gate.style.display = 'none'; document.body.classList.remove('gate-locked'); if(typeof window.v7StartPhoneAuth === 'function') window.v7StartPhoneAuth(); else if(typeof window.showScreen === 'function') window.showScreen('register'); showBackToGate(); };
function showBackToGate(){
  let btn = $('v9BackToGate');
  if(btn) return;
  btn = document.createElement('button');
  btn.id = 'v9BackToGate';
  btn.className = 'v9-back-to-gate';
  btn.innerHTML = '← ফিরে যান';
  btn.onclick = () => { const gate = $('v9Gate'); if(gate){ gate.style.display = ''; document.body.classList.add('gate-locked'); btn.remove(); } };
  document.body.appendChild(btn);
}
function watchRegistration(){
  setInterval(() => {
    if(isRegistered()){
      const gate = $('v9Gate');
      if(gate){
        document.body.classList.remove('gate-locked');
        gate.style.transition = 'opacity .3s';
        gate.style.opacity = '0';
        setTimeout(() => gate.remove(), 300);
        if(typeof window.toast === 'function') window.toast('🎉 অ্যাকাউন্ট তৈরি হয়েছে!','success');
      }
      const backBtn = $('v9BackToGate');
      if(backBtn) backBtn.remove();
    }
  }, 800);
}
function boot(){
  const params = new URLSearchParams(location.search);
  const action = params.get('action');
  if(!isRegistered()){ showGateScreen(action); watchRegistration(); }
  else console.log('%c✅ v9-gate: User registered','color:#43A047;font-weight:700');
}
if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();

/* ═══════════════════════════════════════════════════════════
   ✅ scripts.js সম্পূর্ণ — v9.0
   ═══════════════════════════════════════════════════════════ */
console.log('%c🎉 scripts.js loaded — সব module ready','color:#C62828;font-weight:700;font-size:16px');
console.log('   23 modules · app.js · v5 (11) · hospitals (4) · ambulance (3) · emergency (2) · v7-auth · v9-gate');