/* ============================================================
   district-search.js — Home District Search + Shortcuts
   ============================================================ */
(function(){
'use strict';

const $ = id => document.getElementById(id);
const DISTRICTS = {
  'বরিশাল':['বরিশাল সদর','বাকেরগঞ্জ','বাবুগঞ্জ','উজিরপুর','বানারীপাড়া','গৌরনদী','আগৈলঝাড়া','মেহেন্দিগঞ্জ','মুলাদী','হিজলা'],
  'পটুয়াখালী':['পটুয়াখালী সদর','বাউফল','দশমিনা','গলাচিপা','কলাপাড়া','মির্জাগঞ্জ','রাঙ্গাবালী','দুমকি'],
  'ভোলা':['ভোলা সদর','বোরহানউদ্দিন','চরফ্যাশন','দৌলতখান','লালমোহন','মনপুরা','তজুমদ্দিন'],
  'পিরোজপুর':['পিরোজপুর সদর','ভাণ্ডারিয়া','কাউখালী','মঠবাড়িয়া','নাজিরপুর','নেছারাবাদ','জিয়ানগর'],
  'বরগুনা':['বরগুনা সদর','আমতলী','বামনা','বেতাগী','পাথরঘাটা','তালতলী'],
  'ঝালকাঠি':['ঝালকাঠি সদর','কাঠালিয়া','নলছিটি','রাজাপুর']
};
// Some common upazila name variants
DISTRICTS['পিরোজপুর'][1] = 'ভান্ডারিয়া';

let currentDistrict = '';

/* ═══════════════════════════════════════════════════════════
   District Shortcuts Render
   ═══════════════════════════════════════════════════════════ */
function renderDistrictShortcuts(){
  const c = $('districtShortcuts');
  if(!c) return;
  const districts = Object.keys(DISTRICTS);
  c.innerHTML = districts.map(d => {
    const donorCount = (window.donors || []).filter(x => x.district === d).length;
    const active = currentDistrict === d ? 'style="border-color:var(--red);background:var(--red-l)"' : '';
    return '<button class="qa-card" ' + active + ' onclick="selectDistrict(\'' + d + '\')" style="padding:12px;text-align:left">' +
      '<div style="font-size:14px;font-weight:700;color:var(--text);margin-bottom:2px">📍 ' + d + '</div>' +
      '<div style="font-size:11px;color:var(--text2)">' + toBn(donorCount) + ' জন ডোনার</div>' +
    '</button>';
  }).join('');
}

function toBn(n){ return String(n||0).replace(/[0-9]/g, x => '০১২৩৪৫৬৭৮৯'[+x]); }

/* ═══════════════════════════════════════════════════════════
   Select District → go to Search with filter
   ═══════════════════════════════════════════════════════════ */
window.selectDistrict = function(district, upazila){
  currentDistrict = district;
  // Save to search screen selects
  const sd = $('searchDistrict');
  const su = $('searchUpazila');
  if(sd){
    sd.value = district;
    if(typeof updateUpazila === 'function') updateUpazila('searchDistrict', 'searchUpazila');
  }
  if(upazila && su){
    setTimeout(() => { su.value = upazila; if(typeof renderDonors === 'function') renderDonors(); }, 100);
  }
  // Show banner
  showDistrictBanner(district, upazila);
  // Go to search
  if(typeof showScreen === 'function') showScreen('search');
  if(typeof renderDonors === 'function') setTimeout(renderDonors, 150);
};

/* ═══════════════════════════════════════════════════════════
   District Banner (in Search screen)
   ═══════════════════════════════════════════════════════════ */
function showDistrictBanner(district, upazila){
  const b = $('districtBanner');
  if(!b) return;
  const count = (window.donors || []).filter(x => x.district === district && (!upazila || x.upazila === upazila)).length;
  b.style.display = 'block';
  b.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px">' +
    '<div><b style="font-size:14px">📍 ' + district + (upazila ? ' · ' + upazila : '') + '</b><br>' +
    '<span style="font-size:12px;color:var(--text2)">' + toBn(count) + ' জন ডোনার পাওয়া গেছে</span></div>' +
    '<button onclick="hideDistrictBanner()" style="padding:6px 12px;border-radius:16px;background:var(--bg);border:1px solid var(--bd);font-size:12px;cursor:pointer">✕ বাতিল</button>' +
  '</div>';
}

window.hideDistrictBanner = function(){
  const b = $('districtBanner');
  if(b) b.style.display = 'none';
  currentDistrict = '';
  const sd = $('searchDistrict');
  const su = $('searchUpazila');
  if(sd) sd.value = '';
  if(su) su.value = '';
  if(typeof renderDonors === 'function') renderDonors();
  renderDistrictShortcuts();
};

/* ═══════════════════════════════════════════════════════════
   Live Search Input (findLocation)
   ═══════════════════════════════════════════════════════════ */
window.filterLocationSearch = function(){
  const q = (($('findLocation') || {}).value || '').trim().toLowerCase();
  const res = $('locationSearchResults');
  if(!res) return;

  if(!q){ res.style.display = 'none'; res.innerHTML = ''; return; }

  const matches = [];
  Object.keys(DISTRICTS).forEach(d => {
    if(d.toLowerCase().includes(q)) matches.push({ type:'district', district: d, text: d + ' জেলা' });
    DISTRICTS[d].forEach(u => {
      if(u.toLowerCase().includes(q)) matches.push({ type:'upazila', district: d, upazila: u, text: u + ' · ' + d });
    });
  });

  if(!matches.length){
    res.style.display = 'block';
    res.innerHTML = '<div style="padding:14px;text-align:center;color:var(--text2);font-size:13px">কোনো এলাকা পাওয়া যায়নি</div>';
    return;
  }

  res.style.display = 'block';
  res.innerHTML = matches.slice(0, 8).map((m, i) =>
    '<button onclick="pickLocationResult(' + i + ')" data-idx="' + i + '" ' +
      'style="width:100%;text-align:left;padding:12px 14px;background:var(--bg2);border:1px solid var(--bd);border-radius:10px;margin-bottom:6px;cursor:pointer;font-family:inherit">' +
      '<div style="font-size:13.5px;font-weight:600">📍 ' + m.text + '</div>' +
    '</button>'
  ).join('');

  // Store last matches
  window.__locMatches = matches;
};

window.pickLocationResult = function(i){
  const matches = window.__locMatches || [];
  const m = matches[i];
  if(!m) return;
  const inp = $('findLocation');
  if(inp) inp.value = m.text;
  const res = $('locationSearchResults');
  if(res){ res.style.display = 'none'; res.innerHTML = ''; }
  if(m.type === 'upazila') window.selectDistrict(m.district, m.upazila);
  else window.selectDistrict(m.district);
};

/* ═══════════════════════════════════════════════════════════
   Boot
   ═══════════════════════════════════════════════════════════ */
function boot(){
  setTimeout(renderDistrictShortcuts, 500);
  // Re-render shortcuts when donors change
  const orig = window.renderDonors;
  if(typeof orig === 'function'){
    window.renderDonors = function(){
      const r = orig.apply(this, arguments);
      setTimeout(renderDistrictShortcuts, 50);
      return r;
    };
  }
  console.log('%c✅ district-search.js loaded','color:#00838F;font-weight:700');
}

if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
else boot();

window.DistrictSearch = { select: window.selectDistrict, render: renderDistrictShortcuts };

})();