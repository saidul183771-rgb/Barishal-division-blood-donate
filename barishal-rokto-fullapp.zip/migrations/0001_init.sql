-- ============================================================
-- migrations/0001_init.sql
-- বরিশাল রক্তদাতা — D1 ডাটাবেজ স্কিমা
-- চালান: wrangler d1 execute barishal-rokto --file=migrations/0001_init.sql
-- ============================================================

CREATE TABLE IF NOT EXISTS donors (
  id              TEXT PRIMARY KEY,
  phone           TEXT UNIQUE NOT NULL,
  name            TEXT NOT NULL,
  blood           TEXT NOT NULL,
  district        TEXT NOT NULL,
  upazila         TEXT NOT NULL,
  age             INTEGER,
  weight          INTEGER,
  gender          TEXT,
  emergency       TEXT DEFAULT 'yes',
  last_donation   TEXT,
  nid_number      TEXT,
  nid_photo       TEXT,
  verified        INTEGER DEFAULT 0,
  blood_verified  INTEGER DEFAULT 0,
  nid_rejected    INTEGER DEFAULT 0,
  nid_reject_reason TEXT,
  suspended       INTEGER DEFAULT 0,
  suspend_reason  TEXT,
  donations       INTEGER DEFAULT 0,
  response_rate   REAL DEFAULT 0,
  created_at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_donors_district ON donors(district, upazila);
CREATE INDEX IF NOT EXISTS idx_donors_blood ON donors(blood);

CREATE TABLE IF NOT EXISTS otp_codes (
  phone       TEXT PRIMARY KEY,
  code_hash   TEXT NOT NULL,
  expires_at  INTEGER NOT NULL,
  attempts    INTEGER DEFAULT 0,
  sent_at     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  token       TEXT PRIMARY KEY,
  phone       TEXT NOT NULL,
  role        TEXT NOT NULL DEFAULT 'donor',
  created_at  INTEGER NOT NULL,
  expires_at  INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_phone ON sessions(phone);

CREATE TABLE IF NOT EXISTS admins (
  phone     TEXT PRIMARY KEY,
  added_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS requests (
  id          TEXT PRIMARY KEY,
  patient     TEXT NOT NULL,
  blood       TEXT NOT NULL,
  district    TEXT NOT NULL,
  upazila     TEXT NOT NULL,
  hospital    TEXT NOT NULL,
  bags        INTEGER DEFAULT 1,
  urgency     TEXT DEFAULT 'urgent',
  age         TEXT,
  phone       TEXT NOT NULL,
  note        TEXT,
  status      TEXT DEFAULT 'active',
  at          INTEGER NOT NULL,
  updated_at  INTEGER
);
CREATE INDEX IF NOT EXISTS idx_requests_status ON requests(status);
CREATE INDEX IF NOT EXISTS idx_requests_district ON requests(district, upazila);

CREATE TABLE IF NOT EXISTS request_responses (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  request_id  TEXT NOT NULL,
  phone       TEXT NOT NULL,
  status      TEXT NOT NULL,
  at          INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_responses_request ON request_responses(request_id);

CREATE TABLE IF NOT EXISTS hospitals (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  type        TEXT DEFAULT 'hospital',
  district    TEXT,
  phone       TEXT,
  verified    INTEGER DEFAULT 0,
  created_at  INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS reports (
  id           TEXT PRIMARY KEY,
  target_type  TEXT NOT NULL,
  target_id    TEXT NOT NULL,
  reason       TEXT NOT NULL,
  status       TEXT DEFAULT 'open',
  at           INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS broadcasts (
  id     TEXT PRIMARY KEY,
  message TEXT NOT NULL,
  at     INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
  id      TEXT PRIMARY KEY,
  action  TEXT NOT NULL,
  target  TEXT,
  note    TEXT,
  at      INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_at ON audit_log(at DESC);
