# 🩸 বরিশাল রক্তদাতা — Blood Donor Network (v10)

একটি সম্পূর্ণ কার্যকরী রক্তদাতা খোঁজা/রেজিস্ট্রেশন/জরুরি রক্তের অনুরোধ PWA।
Bengali-first, mobile-first, ইনস্টলযোগ্য (PWA), অফলাইন-সহনশীল।

## ✅ এই আপডেটে কী ঠিক করা হয়েছে

আপলোড করা zip-এ কয়েকটি জিনিস অসম্পূর্ণ ছিল যেগুলো ঠিক করা হয়েছে:

1. **OTP লগইন/রেজিস্ট্রেশন কাজ করছিল না** — `api-client.js` `/api/...` এন্ডপয়েন্টে কল করত, কিন্তু কোনো ব্যাকএন্ড zip-এ ছিল না। এখন `api-client.js` **dual-mode**: প্রকৃত ব্যাকএন্ড না পেলে নিজেই ব্রাউজারে একটি সম্পূর্ণ local mock backend চালায় (OTP, রেজিস্ট্রেশন, রিকোয়েস্ট, সব)। ব্যাকএন্ড ডিপ্লয় করলে স্বয়ংক্রিয়ভাবে আপগ্রেড হয়ে যায়।
2. **Admin panel সম্পূর্ণ অকার্যকর ছিল** — এটি Firebase-নির্ভর ছিল যা ডিফল্টভাবে বন্ধ। এখন admin.html একই phone+OTP সিস্টেম ব্যবহার করে (BloodAPI), এবং প্রথমবার কোনো admin না থাকলে নিজেকে "প্রথম Admin" বানানোর flow আছে।
3. **ভাঙা ফাইল রেফারেন্স** — `icon.svg.xml` → `icon.svg`, `Public.html` → `public.html` (case-sensitive হোস্টিং-এ 404 করত)।
4. **অব্যবহৃত মডিউল** — `district-search.js`, `v6-enterprise.js` এখন home/search স্ক্রিনে wired-in (এলাকা শর্টকাট, লোকেশন সার্চ, মিডিয়া কিট, KPI heatmap ইত্যাদি চালু)।
5. **রিকোয়েস্ট সিঙ্ক হচ্ছিল না** — আগে "রক্তের অনুরোধ" শুধু নিজের ব্রাউজারে সেভ হতো, admin panel-এ কখনো দেখা যেত না। এখন এটি BloodAPI দিয়ে সিঙ্ক হয়।
6. **নতুন**: প্রোডাকশনের জন্য একটি সম্পূর্ণ Cloudflare Pages Functions ব্যাকএন্ড (D1 ডাটাবেজ সহ) যোগ করা হয়েছে — যাতে চাইলে সব ইউজার/ডিভাইসের মধ্যে রিয়েল সিঙ্ক করা যায়।

## 🚀 দুইভাবে ব্যবহার করা যায়

### ১) কোনো সেটআপ ছাড়াই (Local demo মোড)
এই ফোল্ডারের ভেতরের ফাইলগুলো যেকোনো স্ট্যাটিক হোস্টিং-এ আপলোড করুন (Netlify, GitHub Pages, Cloudflare Pages, বা এমনকি লোকাল `python3 -m http.server`)। কোনো ব্যাকএন্ড না থাকলেও:
- OTP লগইন কাজ করবে (OTP কোড ডেভ-মোডে স্ক্রিনেই দেখানো হবে)
- রেজিস্ট্রেশন, অনুরোধ, admin panel — সব কাজ করবে
- ডেটা শুধু **এই ব্রাউজারেই** (localStorage) থাকবে — অন্য ডিভাইস/ইউজারের সাথে সিঙ্ক হবে না

এটা demo/টেস্টিং/একক-ব্যবহারকারীর জন্য যথেষ্ট, কিন্তু বাস্তব মাল্টি-ইউজার প্রোডাক্টের জন্য নিচের ধাপ অনুসরণ করুন।

### ২) প্রোডাকশন — Cloudflare Pages + D1 (সব ইউজারের মধ্যে রিয়েল সিঙ্ক)

**প্রয়োজন:** Cloudflare অ্যাকাউন্ট, Node.js, `npm i -g wrangler`

```bash
# ১. D1 ডাটাবেজ তৈরি করুন
wrangler d1 create barishal-rokto
# আউটপুটে যে database_id পাবেন সেটা wrangler.toml-এ বসান

# ২. স্কিমা চালান
wrangler d1 execute barishal-rokto --remote --file=migrations/0001_init.sql

# ৩. Cloudflare Pages প্রজেক্ট তৈরি + deploy করুন
wrangler pages project create barishal-rokto
wrangler pages deploy . --project-name=barishal-rokto

# ৪. Pages ড্যাশবোর্ডে গিয়ে D1 বাইন্ডিং যোগ করুন (Settings → Functions → D1 database bindings)
#    Variable name: DB   →   Database: barishal-rokto
```

ডিপ্লয়ের পর `/api/...` এন্ডপয়েন্টগুলো লাইভ হয়ে যাবে, আর `api-client.js` স্বয়ংক্রিয়ভাবে local mode থেকে real backend মোডে চলে যাবে — **ফ্রন্টএন্ডে কোনো কোড পরিবর্তন লাগবে না।**

#### (ঐচ্ছিক) বাস্তব SMS পাঠানো
ডিফল্টভাবে OTP কোড কোনো real SMS gateway ছাড়া `devOTP` হিসেবে response-এ ফেরত আসে (শুধু টেস্টিং-এর জন্য — নিরাপদ নয়)। বাস্তব SMS পাঠাতে Cloudflare Pages-এ এই environment variables সেট করুন:
- `SMS_API_KEY` — আপনার SMS provider-এর API key
- `SMS_SEND_URL` — provider-এর send endpoint

(`functions/api/otp/send.js` ফাইলে provider-specific payload অনুযায়ী সামান্য পরিবর্তন লাগতে পারে — যেমন BulkSMSBD, Twilio, Infobip ইত্যাদির নিজস্ব request format আছে।)

## 👑 প্রথম Admin বানানো

Admin panel-এ (`/admin.html`) নিজের ফোন নম্বর দিয়ে OTP লগইন করুন। কোনো admin না থাকলে "আমাকে প্রথম Admin বানান" বাটন দেখাবে — সেটায় ক্লিক করলেই আপনি admin হয়ে যাবেন। এরপর Admin panel-এর "Admins" সেকশন থেকে আরও admin ফোন নম্বর যোগ/বাদ দিতে পারবেন।

## 📁 প্রজেক্ট গঠন

```
index.html          ল্যান্ডিং পেজ
app.html             মূল অ্যাপ (SPA) — রেজিস্ট্রেশন, সার্চ, রিকোয়েস্ট, প্রোফাইল ইত্যাদি
admin.html           অ্যাডমিন কনসোল
public.html          শেয়ারযোগ্য পাবলিক ডোনার প্রোফাইল পেজ
scripts.js           মূল অ্যাপ লজিক (v9 — ১২টি মডিউল, দেখুন ফাইলের ভেতরে MODULE কমেন্ট)
api-client.js        BloodAPI — real backend / local fallback dual-mode client
district-search.js   এলাকা শর্টকাট + লোকেশন-ভিত্তিক সার্চ
v6-enterprise.js      KPI heatmap, media kit, compliance ড্যাশবোর্ড (admin-adjacent এক্সট্রা)
firebase-config.js    ঐচ্ছিক লিগ্যাসি — ডিফল্টে নিষ্ক্রিয়, প্রয়োজন নেই
manifest.webmanifest  PWA ম্যানিফেস্ট
sw.js                 Service worker (অফলাইন cache + push)
_redirects            Netlify-স্টাইল রুট রিরাইট (Cloudflare Pages-ও সমর্থন করে)
functions/            Cloudflare Pages Functions ব্যাকএন্ড (production API)
migrations/           D1 স্কিমা
wrangler.toml         Cloudflare ডিপ্লয় কনফিগ
```

## ⚠️ সীমাবদ্ধতা (সততার সাথে বলা প্রয়োজন)

- Local demo মোডে ডেটা **শুধু একটি ব্রাউজারে** থাকে — অন্য কেউ আপনার রেজিস্ট্রেশন/রিকোয়েস্ট দেখতে পাবে না যতক্ষণ না backend deploy করা হয়।
- SMS gateway ছাড়া OTP প্রোডাকশনে নিরাপদ নয় (devOTP screen-এ দেখা যায়) — আসল ব্যবহারকারীদের জন্য অবশ্যই একটি SMS provider যুক্ত করুন।
- NID ছবি আপলোড ফিচারটি ফ্রন্টএন্ডে আছে কিন্তু ব্যাকএন্ডে ফাইল স্টোরেজ (যেমন Cloudflare R2) যুক্ত করা হয়নি — বর্তমানে base64/URL হিসেবে টেক্সট ফিল্ডে সংরক্ষিত হয়; বড় স্কেলে R2 বাইন্ডিং যোগ করার পরামর্শ দেওয়া হচ্ছে।
- Push notification-এর জন্য Firebase Cloud Messaging কনফিগ (`firebase-config.js`) এখনও ঐচ্ছিক রাখা হয়েছে যদি আপনি push চালু করতে চান — না করলে অ্যাপ স্বাভাবিকভাবেই কাজ করবে।
