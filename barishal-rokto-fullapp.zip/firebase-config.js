/* ============================================================
   firebase-config.js — Firebase Configuration
   ------------------------------------------------------------
   ⚠️ গুরুত্বপূর্ণ:
   ১. https://console.firebase.google.com এ যান
   ২. নতুন প্রজেক্ট বানান (যেমন: barishal-rokto)
   ৩. Project Settings → Your apps → Web (</>) যোগ করুন
   ৪. নিচের config-এ আপনার আসল মান বসান
   ৫. FIREBASE_ENABLED = true করুন
   ------------------------------------------------------------
   Firebase ছাড়া (FIREBASE_ENABLED = false):
   - অ্যাপ লোকাল মোডে চলবে
   - Demo data দেখাবে
   - সব ফিচার কাজ করবে (শুধু cloud sync বন্ধ থাকবে)
   ============================================================ */

window.FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "G-XXXXXXXXXX"
};

/* Web Push VAPID Key
   Firebase Console → Project Settings → Cloud Messaging → Web Push certificates
   থেকে পাবেন */
window.FCM_VAPID_KEY = "YOUR_WEB_PUSH_VAPID_KEY";

/* Firebase চালু/বন্ধ
   - false → লোকাল মোড (Firebase ছাড়া)
   - true  → Cloud sync + Auth + Push notifications */
window.FIREBASE_ENABLED = false;

/* ============================================================
   ✅ Firebase Setup Guide (সংক্ষিপ্ত)
   ============================================================
   
   ১. Firebase Project তৈরি:
      - https://console.firebase.google.com
      - "Add project" → নাম দিন → Continue → Create
   
   ২. Firestore Database:
      - Build → Firestore Database → Create database
      - Production mode → Region: asia-south1 → Enable
   
   ৩. Authentication:
      - Build → Authentication → Get started
      - Sign-in method → Anonymous: Enable
      - Sign-in method → Email/Password: Enable
      - Sign-in method → Phone: Enable (বাংলাদেশ +880 যোগ করুন)
   
   ৪. Web App যোগ করুন:
      - Project Settings (⚙️) → General → Your apps
      - Web app (</>) আইকনে ক্লিক
      - Nickname: barishal-rokto
      - Register app
      - firebaseConfig কপি করুন → উপরে বসান
   
   ৫. Web Push VAPID Key:
      - Project Settings → Cloud Messaging
      - Web Push certificates → Generate key pair
      - Key কপি করুন → উপরে FCM_VAPID_KEY তে বসান
   
   ৬. FIREBASE_ENABLED = true করুন
   
   ৭. Server-side Rules:
      - Firestore Database → Rules → নিচের rules বসান:
      
      rules_version = '2';
      service cloud.firestore {
        match /databases/{database}/documents {
          match /donors/{uid} {
            allow read: if true;
            allow create: if request.auth != null;
            allow update: if request.auth != null && request.auth.uid == uid;
            allow delete: if false;
          }
          match /requests/{id} {
            allow read: if true;
            allow create: if request.auth != null;
            allow update: if request.auth != null;
            allow delete: if false;
          }
          match /donorAvailability/{uid} {
            allow read: if true;
            allow write: if request.auth != null && request.auth.uid == uid;
          }
          match /hospitals/{id} {
            allow read: if true;
            allow create: if request.auth != null;
            allow update: if false;
          }
          match /reports/{id} {
            allow read, create: if request.auth != null;
            allow update, delete: if false;
          }
          match /auditLog/{id} {
            allow read: if request.auth != null;
            allow create: if request.auth != null;
            allow update, delete: if false;
          }
          match /users/{uid} {
            allow read, write: if request.auth != null && request.auth.uid == uid;
          }
        }
      }
      
   ৮. Netlify-তে Deploy করুন
   ============================================================ */

console.log('%c🔥 firebase-config.js loaded', 'color:#F57C00;font-weight:700');
console.log('   Firebase Enabled:', window.FIREBASE_ENABLED ? '✅ YES' : '❌ NO (local mode)');
if(window.FIREBASE_ENABLED && window.FIREBASE_CONFIG.apiKey === 'YOUR_API_KEY'){
  console.warn('⚠️ Firebase config খালি! YOUR_API_KEY এর জায়গায় আসল মান বসান।');
  window.FIREBASE_ENABLED = false;
}