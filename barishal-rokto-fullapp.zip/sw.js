/* ============================================================
   sw.js — Service Worker (PWA + Offline + Push)
   বরিশাল রক্তদাতা v9.0
   ------------------------------------------------------------
   কাজ:
   ১. অ্যাপ-শেল ক্যাশ করা (offline support)
   ২. দ্রুত লোডিং (cache-first strategy)
   ৩. Push notifications (Firebase Cloud Messaging)
   ৪. Notification click handling
   ============================================================ */

const CACHE_NAME = 'barishal-rokto-v10.0.0';
const APP_SHELL = [
  './',
  './index.html',
  './app.html',
  './admin.html',
  './public.html',
  './styles.css',
  './scripts.js',
  './api-client.js',
  './district-search.js',
  './v6-enterprise.js',
  './firebase-config.js',
  './manifest.webmanifest',
  './icon.svg'
];

/* ═══════════ INSTALL ═══════════ */
self.addEventListener('install', event => {
  console.log('[sw] Installing...');
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('[sw] Caching app shell');
        return cache.addAll(APP_SHELL).catch(err => {
          console.warn('[sw] Some files failed to cache:', err);
        });
      })
      .then(() => self.skipWaiting())
  );
});

/* ═══════════ ACTIVATE ═══════════ */
self.addEventListener('activate', event => {
  console.log('[sw] Activating...');
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys.filter(key => key !== CACHE_NAME)
            .map(key => caches.delete(key))
      ))
      .then(() => self.clients.claim())
  );
});

/* ═══════════ FETCH (cache-first strategy) ═══════════ */
self.addEventListener('fetch', event => {
  if(event.request.method !== 'GET') return;

  const url = new URL(event.request.url);

  // Firebase, Google APIs, Leaflet — network-first
  if(url.hostname.includes('firebase') ||
     url.hostname.includes('gstatic') ||
     url.hostname.includes('googleapis') ||
     url.hostname.includes('unpkg') ||
     url.hostname.includes('openstreetmap') ||
     url.hostname.includes('jsdelivr')){
    event.respondWith(
      fetch(event.request)
        .then(response => {
          if(response && response.status === 200){
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          }
          return response;
        })
        .catch(() => caches.match(event.request))
    );
    return;
  }

  // Same-origin — cache-first
  event.respondWith(
    caches.match(event.request)
      .then(cached => {
        const fetchPromise = fetch(event.request)
          .then(response => {
            if(response && response.status === 200 && url.origin === location.origin){
              const clone = response.clone();
              caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
            }
            return response;
          })
          .catch(() => cached);
        return cached || fetchPromise;
      })
  );
});

/* ═══════════ PUSH NOTIFICATION ═══════════ */
self.addEventListener('push', event => {
  console.log('[sw] Push received');
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch(e){
    data = { notification: { title: 'বরিশাল রক্তদাতা', body: 'নতুন আপডেট' } };
  }

  const title = (data.notification && data.notification.title) || '🚨 জরুরি রক্তের অনুরোধ';
  const body = (data.notification && data.notification.body) || 'নিকটবর্তী রোগীর জন্য রক্ত প্রয়োজন';
  const reqId = (data.data && data.data.reqId) || '';
  const urgency = (data.data && data.data.urgency) || 'urgent';

  const options = {
    body: body,
    icon: './icon.svg',
    badge: './icon.svg',
    vibrate: [200, 100, 200, 100, 200],
    tag: 'emergency-' + reqId,
    requireInteraction: true,
    data: Object.assign({ reqId: reqId }, data.data || {}),
    actions: [
      { action: 'accept', title: '✅ আমি দিতে পারব' },
      { action: 'view', title: 'বিস্তারিত' },
      { action: 'close', title: 'বন্ধ' }
    ]
  };

  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

/* ═══════════ NOTIFICATION CLICK ═══════════ */
self.addEventListener('notificationclick', event => {
  console.log('[sw] Notification clicked:', event.action);
  event.notification.close();

  const action = event.action;
  const reqId = (event.notification.data && event.notification.data.reqId) || '';
  const targetUrl = './app.html' + (reqId ? '#request-' + reqId : '');

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then(clientList => {
        // কেউ অ্যাপ খোলা থাকলে সেখানে মেসেজ পাঠাই
        for(const client of clientList){
          if(client.url.includes('app.html') && 'focus' in client){
            client.postMessage({
              type: 'notification-action',
              action: action,
              reqId: reqId
            });
            return client.focus();
          }
        }
        // অ্যাপ খোলা না থাকলে নতুন ট্যাবে খুলি
        if(clients.openWindow){
          return clients.openWindow(targetUrl);
        }
      })
  );
});

/* ═══════════ MESSAGE FROM PAGE ═══════════ */
self.addEventListener('message', event => {
  const data = event.data || {};
  if(data.type === 'SKIP_WAITING'){
    self.skipWaiting();
  }
  if(data.type === 'CLEAR_CACHE'){
    caches.delete(CACHE_NAME).then(() => {
      console.log('[sw] Cache cleared');
    });
  }
});

/* ═══════════ BACKGROUND SYNC (optional) ═══════════ */
self.addEventListener('sync', event => {
  if(event.tag === 'sync-pending-requests'){
    console.log('[sw] Background sync: pending requests');
    event.waitUntil(
      // এখানে offline queue থেকে pending requests পাঠানো যায়
      Promise.resolve()
    );
  }
});

console.log('[sw] Service Worker loaded ✅');