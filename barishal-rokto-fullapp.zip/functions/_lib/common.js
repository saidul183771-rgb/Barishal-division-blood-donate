/* ============================================================
   _lib/common.js — সব Cloudflare Pages Functions-এর জন্য শেয়ার্ড হেল্পার
   ============================================================ */

export function json(data, status){
  return new Response(JSON.stringify(data), {
    status: status || 200,
    headers: { 'Content-Type': 'application/json; charset=utf-8' }
  });
}

export function fail(message, status){
  return json({ success: false, message: message || 'ব্যর্থ' }, status || 400);
}

export async function readJson(request){
  try{ return await request.json(); }catch(e){ return {}; }
}

export function genId(prefix){
  return (prefix||'id') + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2,10);
}

export function genOtp(){
  return String(Math.floor(100000 + Math.random()*900000));
}

export async function sha256Hex(str){
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(x => x.toString(16).padStart(2,'0')).join('');
}

const SESSION_COOKIE = 'brsession';
const SESSION_TTL_MS = 30 * 24 * 3600 * 1000; // ৩০ দিন

export function sessionCookieHeader(token, maxAgeSec){
  const parts = [
    SESSION_COOKIE + '=' + token,
    'Path=/',
    'HttpOnly',
    'Secure',
    'SameSite=Lax'
  ];
  if(maxAgeSec === 0) parts.push('Max-Age=0');
  else parts.push('Max-Age=' + (maxAgeSec || Math.floor(SESSION_TTL_MS/1000)));
  return parts.join('; ');
}

export function getCookie(request, name){
  const header = request.headers.get('Cookie') || '';
  const match = header.match(new RegExp('(?:^|;\\s*)' + name + '=([^;]+)'));
  return match ? decodeURIComponent(match[1]) : null;
}

/* সেশন টোকেন যাচাই করে { phone, role } রিটার্ন করে, নাহলে null */
export async function getSession(request, env){
  const token = getCookie(request, SESSION_COOKIE);
  if(!token) return null;
  const row = await env.DB.prepare('SELECT phone, role, expires_at FROM sessions WHERE token = ?').bind(token).first();
  if(!row) return null;
  if(row.expires_at && row.expires_at < Date.now()){
    await env.DB.prepare('DELETE FROM sessions WHERE token = ?').bind(token).run();
    return null;
  }
  return { token, phone: row.phone, role: row.role };
}

export async function createSession(env, phone, role){
  const token = genId('tok');
  const now = Date.now();
  await env.DB.prepare('INSERT INTO sessions (token, phone, role, created_at, expires_at) VALUES (?, ?, ?, ?, ?)')
    .bind(token, phone, role, now, now + SESSION_TTL_MS).run();
  return token;
}

export async function isAdminPhone(env, phone){
  const row = await env.DB.prepare('SELECT phone FROM admins WHERE phone = ?').bind(phone).first();
  return !!row;
}

export async function writeAudit(env, action, target, note){
  try{
    await env.DB.prepare('INSERT INTO audit_log (id, action, target, note, at) VALUES (?, ?, ?, ?, ?)')
      .bind(genId('a'), action, target || '', note || '', Date.now()).run();
  }catch(e){ /* audit ব্যর্থ হলে মূল অপারেশন আটকাবে না */ }
}

/* donor DB row -> API shape (snake_case, api-client.js যা আশা করে) */
export function donorRowToApi(row){
  if(!row) return null;
  return {
    id: row.id, name: row.name, phone: row.phone, blood: row.blood,
    district: row.district, upazila: row.upazila,
    last_donation: row.last_donation || null, age: row.age || null, weight: row.weight || null,
    gender: row.gender || null, emergency: row.emergency || 'yes',
    verified: !!row.verified, blood_verified: !!row.blood_verified,
    nid_rejected: !!row.nid_rejected, nid_reject_reason: row.nid_reject_reason || null,
    suspended: !!row.suspended, suspend_reason: row.suspend_reason || null,
    donations: row.donations || 0, response_rate: row.response_rate || 0,
    created_at: row.created_at || Date.now()
  };
}

export async function requireAuth(request, env){
  const session = await getSession(request, env);
  if(!session) return { ok:false, response: fail('লগইন প্রয়োজন', 401) };
  return { ok:true, session };
}

export async function requireAdmin(request, env){
  const auth = await requireAuth(request, env);
  if(!auth.ok) return auth;
  if(auth.session.role !== 'admin') return { ok:false, response: fail('শুধু Admin অনুমোদিত', 403) };
  return auth;
}
