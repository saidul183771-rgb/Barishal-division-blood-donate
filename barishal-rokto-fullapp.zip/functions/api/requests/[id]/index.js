import { json, fail, readJson, requireAuth, writeAudit } from '../../../_lib/common.js';

export async function onRequestGet({ params, env }){
  const row = await env.DB.prepare('SELECT * FROM requests WHERE id = ?').bind(params.id).first();
  if(!row) return fail('পাওয়া যায়নি', 404);
  return json({ success: true, request: row });
}

export async function onRequestPatch({ request, env, params }){
  const auth = await requireAuth(request, env);
  if(!auth.ok) return auth.response;
  const b = await readJson(request);
  if(!b.status) return fail('status দিন');
  await env.DB.prepare('UPDATE requests SET status = ?, updated_at = ? WHERE id = ?')
    .bind(b.status, Date.now(), params.id).run();
  await writeAudit(env, 'REQUEST_STATUS', params.id, b.status);
  return json({ success: true });
}
