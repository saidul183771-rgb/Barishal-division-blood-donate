import { json, fail, readJson, requireAuth } from '../../../_lib/common.js';

export async function onRequestGet({ params, env }){
  const { results } = await env.DB.prepare('SELECT phone, status, at FROM request_responses WHERE request_id = ? ORDER BY at DESC')
    .bind(params.id).all();
  return json({ success: true, responses: results || [] });
}

export async function onRequestPost({ request, env, params }){
  const auth = await requireAuth(request, env);
  if(!auth.ok) return auth.response;
  const b = await readJson(request);
  if(!b.status) return fail('status দিন');
  await env.DB.prepare('INSERT INTO request_responses (request_id, phone, status, at) VALUES (?, ?, ?, ?)')
    .bind(params.id, auth.session.phone, b.status, Date.now()).run();
  return json({ success: true });
}
