import { json, fail, readJson, genId, writeAudit } from '../../_lib/common.js';

export async function onRequestGet({ request, env }){
  const url = new URL(request.url);
  const status = url.searchParams.get('status');
  let sql = 'SELECT * FROM requests';
  const binds = [];
  if(status){ sql += ' WHERE status = ?'; binds.push(status); }
  sql += ' ORDER BY at DESC LIMIT 500';
  const { results } = await env.DB.prepare(sql).bind(...binds).all();
  return json({ success: true, requests: results || [] });
}

export async function onRequestPost({ request, env }){
  const b = await readJson(request);
  if(!b.patient || !b.blood || !b.district || !b.upazila || !b.hospital || !b.phone){
    return fail('সব * পূরণ করুন');
  }
  const id = genId('r');
  const now = Date.now();
  await env.DB.prepare(
    `INSERT INTO requests (id, patient, blood, district, upazila, hospital, bags, urgency, age, phone, note, status, at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?)`
  ).bind(
    id, b.patient, b.blood, b.district, b.upazila, b.hospital, b.bags || 1, b.urgency || 'urgent',
    b.age || null, b.phone, b.note || null, now
  ).run();
  await writeAudit(env, 'REQUEST_CREATED', id, b.blood + ' · ' + (b.upazila||''));
  const row = await env.DB.prepare('SELECT * FROM requests WHERE id = ?').bind(id).first();
  return json({ success: true, id, request: row });
}
