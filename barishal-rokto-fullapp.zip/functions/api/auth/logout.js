import { getCookie, sessionCookieHeader } from '../../_lib/common.js';

export async function onRequestPost({ request, env }){
  const token = getCookie(request, 'brsession');
  if(token){
    try{ await env.DB.prepare('DELETE FROM sessions WHERE token = ?').bind(token).run(); }catch(e){}
  }
  return new Response(JSON.stringify({ success: true }), {
    status: 200,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Set-Cookie': sessionCookieHeader('', 0)
    }
  });
}
