import { json, fail, readJson, requireAuth, requireAdmin, writeAudit } from '../../_lib/common.js';

async function listAdminPhones(env){
  const { results } = await env.DB.prepare('SELECT phone FROM admins ORDER BY added_at ASC').all();
  return (results || []).map(r => r.phone);
}

export async function onRequestGet({ request, env }){
  const admins = await listAdminPhones(env);
  // Bootstrap অবস্থায় (এখনো কোনো admin নেই) লগইন ছাড়াই তালিকা (খালি) দেখা যাবে,
  // যাতে ফ্রন্টএন্ড bootstrap flow দেখাতে পারে। Admin থাকলে শুধু admin-ই দেখতে পারবে।
  if(admins.length > 0){
    const auth = await requireAdmin(request, env);
    if(!auth.ok) return auth.response;
  }
  return json({ success: true, admins });
}

const PHONE_RE = /^01[3-9]\d{8}$/;

export async function onRequestPost({ request, env }){
  const b = await readJson(request);
  const phone = String(b.phone || '').trim();
  if(!PHONE_RE.test(phone)) return fail('সঠিক নম্বর দিন');

  const admins = await listAdminPhones(env);
  if(admins.length > 0){
    // ইতিমধ্যে admin আছে — শুধু বিদ্যমান admin-ই নতুন admin যোগ করতে পারবে
    const auth = await requireAdmin(request, env);
    if(!auth.ok) return auth.response;
  } else {
    // Bootstrap: প্রথম admin — যাচাইকৃত ফোন সেশন থাকলেই যথেষ্ট (তার নিজের নম্বর হতে হবে)
    const auth = await requireAuth(request, env);
    if(!auth.ok) return auth.response;
    if(auth.session.phone !== phone) return fail('শুধু নিজের ফোন নম্বর দিয়ে bootstrap করা যাবে', 403);
  }

  await env.DB.prepare('INSERT OR IGNORE INTO admins (phone, added_at) VALUES (?, ?)').bind(phone, Date.now()).run();
  // ওই ফোনের বর্তমান সব সেশনের role আপডেট করুন
  await env.DB.prepare("UPDATE sessions SET role = 'admin' WHERE phone = ?").bind(phone).run();
  await writeAudit(env, 'ADMIN_ADDED', phone, '');
  return json({ success: true, admins: await listAdminPhones(env) });
}

export async function onRequestDelete({ request, env }){
  const auth = await requireAdmin(request, env);
  if(!auth.ok) return auth.response;
  const b = await readJson(request);
  const phone = String(b.phone || '').trim();
  if(!phone) return fail('phone দিন');
  const admins = await listAdminPhones(env);
  if(admins.length <= 1) return fail('শেষ Admin বাদ দেওয়া যাবে না');
  await env.DB.prepare('DELETE FROM admins WHERE phone = ?').bind(phone).run();
  await env.DB.prepare("UPDATE sessions SET role = 'donor' WHERE phone = ?").bind(phone).run();
  await writeAudit(env, 'ADMIN_REMOVED', phone, '');
  return json({ success: true, admins: await listAdminPhones(env) });
}
