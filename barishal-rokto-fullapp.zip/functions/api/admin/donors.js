import { json, fail, readJson, requireAdmin, writeAudit, donorRowToApi } from '../../_lib/common.js';

export async function onRequestGet({ request, env }){
  const auth = await requireAdmin(request, env);
  if(!auth.ok) return auth.response;
  const url = new URL(request.url);
  const filter = url.searchParams.get('filter');
  let sql = 'SELECT * FROM donors';
  if(filter === 'pending') sql += ' WHERE verified = 0 AND nid_rejected = 0';
  else if(filter === 'verified') sql += ' WHERE verified = 1';
  else if(filter === 'suspended') sql += ' WHERE suspended = 1';
  sql += ' ORDER BY created_at DESC LIMIT 1000';
  const { results } = await env.DB.prepare(sql).all();
  return json({ success: true, donors: (results || []).map(donorRowToApi) });
}

export async function onRequestPatch({ request, env }){
  const auth = await requireAdmin(request, env);
  if(!auth.ok) return auth.response;
  const b = await readJson(request);
  if(!b.id || !b.action) return fail('id ও action দিন');

  const row = await env.DB.prepare('SELECT phone FROM donors WHERE id = ?').bind(b.id).first();
  if(!row) return fail('ডোনার পাওয়া যায়নি', 404);

  if(b.action === 'verify'){
    await env.DB.prepare('UPDATE donors SET verified = 1, blood_verified = 1, nid_rejected = 0 WHERE id = ?').bind(b.id).run();
  } else if(b.action === 'suspend'){
    await env.DB.prepare('UPDATE donors SET suspended = 1, suspend_reason = ? WHERE id = ?').bind(b.reason || '', b.id).run();
  } else if(b.action === 'unsuspend'){
    await env.DB.prepare('UPDATE donors SET suspended = 0, suspend_reason = NULL WHERE id = ?').bind(b.id).run();
  } else if(b.action === 'reject_nid'){
    await env.DB.prepare('UPDATE donors SET nid_rejected = 1, nid_reject_reason = ?, verified = 0 WHERE id = ?').bind(b.reason || '', b.id).run();
  } else {
    return fail('অজানা action');
  }

  const actionName = b.action === 'verify' ? 'VERIFY_DONOR' : b.action === 'suspend' ? 'SUSPEND_DONOR' : b.action.toUpperCase();
  await writeAudit(env, actionName, row.phone, b.reason || '');
  return json({ success: true });
}
