import { json, fail, readJson, requireAdmin, writeAudit } from '../../_lib/common.js';

export async function onRequestPatch({ request, env }){
  const auth = await requireAdmin(request, env);
  if(!auth.ok) return auth.response;
  const b = await readJson(request);
  if(!b.id || !b.action) return fail('id ও action দিন');
  if(b.action === 'approve'){
    await env.DB.prepare('UPDATE hospitals SET verified = 1 WHERE id = ?').bind(b.id).run();
    await writeAudit(env, 'APPROVE_HOSPITAL', b.id, '');
    return json({ success: true });
  }
  return fail('অজানা action');
}
