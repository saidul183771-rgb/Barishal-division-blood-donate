import { json, requireAdmin } from '../../_lib/common.js';

export async function onRequestGet({ request, env }){
  const auth = await requireAdmin(request, env);
  if(!auth.ok) return auth.response;
  const url = new URL(request.url);
  const limit = Math.min(parseInt(url.searchParams.get('limit') || '200', 10) || 200, 500);
  const { results } = await env.DB.prepare('SELECT * FROM audit_log ORDER BY at DESC LIMIT ?').bind(limit).all();
  return json({ success: true, log: results || [] });
}
