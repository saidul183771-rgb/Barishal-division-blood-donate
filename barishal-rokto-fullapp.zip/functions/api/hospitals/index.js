import { json, fail, readJson, genId, writeAudit } from '../../_lib/common.js';

export async function onRequestGet({ request, env }){
  const url = new URL(request.url);
  const district = url.searchParams.get('district');
  let sql = 'SELECT * FROM hospitals';
  const binds = [];
  if(district){ sql += ' WHERE district = ?'; binds.push(district); }
  sql += ' ORDER BY created_at DESC LIMIT 500';
  const { results } = await env.DB.prepare(sql).bind(...binds).all();
  return json({ success: true, hospitals: results || [] });
}

export async function onRequestPost({ request, env }){
  const b = await readJson(request);
  if(!b.name) return fail('হাসপাতালের নাম দিন');
  const id = genId('h');
  await env.DB.prepare(
    'INSERT INTO hospitals (id, name, type, district, phone, verified, created_at) VALUES (?, ?, ?, ?, ?, 0, ?)'
  ).bind(id, b.name, b.type || 'hospital', b.district || null, b.phone || null, Date.now()).run();
  await writeAudit(env, 'HOSPITAL_ADDED', id, b.name);
  return json({ success: true, id });
}
