import { json, fail, readJson, requireAdmin, writeAudit } from '../../_lib/common.js';

export async function onRequestPatch({ request, env, params }){
  const auth = await requireAdmin(request, env);
  if(!auth.ok) return auth.response;
  const b = await readJson(request);
  if(!b.status) return fail('status দিন');
  await env.DB.prepare('UPDATE reports SET status = ? WHERE id = ?').bind(b.status, params.id).run();
  await writeAudit(env, 'RESOLVE_REPORT', params.id, b.status);
  return json({ success: true });
}
