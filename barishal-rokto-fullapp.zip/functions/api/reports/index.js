import { json, fail, readJson, genId, writeAudit } from '../../_lib/common.js';

export async function onRequestGet({ request, env }){
  const url = new URL(request.url);
  const status = url.searchParams.get('status');
  let sql = 'SELECT * FROM reports';
  const binds = [];
  if(status){ sql += ' WHERE status = ?'; binds.push(status); }
  sql += ' ORDER BY at DESC LIMIT 500';
  const { results } = await env.DB.prepare(sql).bind(...binds).all();
  return json({ success: true, reports: results || [] });
}

export async function onRequestPost({ request, env }){
  const b = await readJson(request);
  if(!b.targetType || !b.targetId || !b.reason) return fail('সব ঘর পূরণ করুন');
  const id = genId('rep');
  await env.DB.prepare(
    'INSERT INTO reports (id, target_type, target_id, reason, status, at) VALUES (?, ?, ?, ?, \'open\', ?)'
  ).bind(id, b.targetType, b.targetId, b.reason, Date.now()).run();
  await writeAudit(env, 'REPORT_FILED', id, b.reason);
  return json({ success: true, id });
}
