import { json, fail, readJson, genId, requireAdmin, writeAudit } from '../../_lib/common.js';

export async function onRequestGet({ request, env }){
  const url = new URL(request.url);
  const limit = Math.min(parseInt(url.searchParams.get('limit') || '20', 10) || 20, 100);
  const { results } = await env.DB.prepare('SELECT * FROM broadcasts ORDER BY at DESC LIMIT ?').bind(limit).all();
  return json({ success: true, broadcasts: results || [] });
}

export async function onRequestPost({ request, env }){
  const auth = await requireAdmin(request, env);
  if(!auth.ok) return auth.response;
  const b = await readJson(request);
  if(!b.message) return fail('message দিন');
  const id = genId('bc');
  await env.DB.prepare('INSERT INTO broadcasts (id, message, at) VALUES (?, ?, ?)').bind(id, b.message, Date.now()).run();
  await writeAudit(env, 'BROADCAST_SENT', '', b.message);
  return json({ success: true, id });
}
