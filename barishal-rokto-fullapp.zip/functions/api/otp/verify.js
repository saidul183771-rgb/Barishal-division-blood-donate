import { json, fail, readJson, sha256Hex, createSession, isAdminPhone, sessionCookieHeader, writeAudit } from '../../_lib/common.js';

export async function onRequestPost({ request, env }){
  const body = await readJson(request);
  const phone = String(body.phone || '').trim();
  const otp = String(body.otp || '').trim();
  if(!phone || otp.length !== 6) return fail('ফোন ও ৬-সংখ্যার OTP দিন');

  const rec = await env.DB.prepare('SELECT code_hash, expires_at, attempts FROM otp_codes WHERE phone = ?').bind(phone).first();
  if(!rec) return fail('আগে OTP পাঠান');
  if(Date.now() > rec.expires_at){
    await env.DB.prepare('DELETE FROM otp_codes WHERE phone = ?').bind(phone).run();
    return fail('OTP মেয়াদ শেষ — আবার চেষ্টা করুন');
  }
  if(rec.attempts >= 5){
    await env.DB.prepare('DELETE FROM otp_codes WHERE phone = ?').bind(phone).run();
    return fail('বার বার ভুল — আবার OTP নিন');
  }

  const hash = await sha256Hex(phone + ':' + otp);
  if(hash !== rec.code_hash){
    await env.DB.prepare('UPDATE otp_codes SET attempts = attempts + 1 WHERE phone = ?').bind(phone).run();
    return fail('ভুল OTP কোড');
  }
  await env.DB.prepare('DELETE FROM otp_codes WHERE phone = ?').bind(phone).run();

  const admin = await isAdminPhone(env, phone);
  const role = admin ? 'admin' : 'donor';
  const donor = await env.DB.prepare('SELECT id FROM donors WHERE phone = ?').bind(phone).first();
  const token = await createSession(env, phone, role);
  await writeAudit(env, 'LOGIN', phone, role);

  return new Response(JSON.stringify({ success: true, role, hasProfile: !!donor }), {
    status: 200,
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'Set-Cookie': sessionCookieHeader(token)
    }
  });
}
