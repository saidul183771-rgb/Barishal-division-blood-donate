import { json, fail, readJson, genOtp, sha256Hex } from '../../_lib/common.js';

const PHONE_RE = /^01[3-9]\d{8}$/;

export async function onRequestPost({ request, env }){
  const body = await readJson(request);
  const phone = String(body.phone || '').trim();
  if(!PHONE_RE.test(phone)) return fail('সঠিক ১১-সংখ্যার নম্বর দিন');

  // Rate-limit: একই নম্বরে ৩০ সেকেন্ডে একবার
  const existing = await env.DB.prepare('SELECT sent_at FROM otp_codes WHERE phone = ?').bind(phone).first();
  if(existing && (Date.now() - existing.sent_at) < 30000){
    return fail('একটু অপেক্ষা করুন, আবার চেষ্টা করুন');
  }

  const code = genOtp();
  const codeHash = await sha256Hex(phone + ':' + code);
  const now = Date.now();
  await env.DB.prepare(
    'INSERT INTO otp_codes (phone, code_hash, expires_at, attempts, sent_at) VALUES (?, ?, ?, 0, ?) ' +
    'ON CONFLICT(phone) DO UPDATE SET code_hash=excluded.code_hash, expires_at=excluded.expires_at, attempts=0, sent_at=excluded.sent_at'
  ).bind(phone, codeHash, now + 5*60000, now).run();

  // ── SMS গেটওয়ে ইন্টিগ্রেশন এখানে যোগ করুন ──
  // যদি env.SMS_API_KEY সেট করা থাকে, তাহলে বাস্তব SMS পাঠান (উদাহরণ: BulkSMSBD, Twilio ইত্যাদি)।
  // env var সেট না থাকলে dev মোডে OTP response-এ ফেরত পাঠানো হয় (শুধুই টেস্টিং/ডেমোর জন্য —
  // প্রোডাকশনে অবশ্যই একটি SMS provider যোগ করে devOTP বাদ দিন)।
  let devOTP;
  if(env.SMS_API_KEY && env.SMS_SEND_URL){
    try{
      await fetch(env.SMS_SEND_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + env.SMS_API_KEY },
        body: JSON.stringify({ to: phone, message: 'বরিশাল রক্তদাতা OTP: ' + code })
      });
    }catch(e){ /* SMS ব্যর্থ হলেও OTP সংরক্ষিত আছে; লগ-এ দেখা যাবে */ }
  } else {
    devOTP = code;
  }

  return json({ success: true, message: 'OTP পাঠানো হয়েছে', devOTP });
}
