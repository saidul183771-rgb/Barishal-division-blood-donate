import { json, donorRowToApi } from '../../_lib/common.js';

export async function onRequestGet({ request, env }){
  const url = new URL(request.url);
  const blood = url.searchParams.get('blood');
  const district = url.searchParams.get('district');
  const upazila = url.searchParams.get('upazila');

  let sql = 'SELECT * FROM donors WHERE suspended = 0';
  const binds = [];
  if(blood){ sql += ' AND blood = ?'; binds.push(blood); }
  if(district){ sql += ' AND district = ?'; binds.push(district); }
  if(upazila){ sql += ' AND upazila = ?'; binds.push(upazila); }
  sql += ' LIMIT 1000';

  const stmt = env.DB.prepare(sql).bind(...binds);
  const { results } = await stmt.all();
  return json({ success: true, donors: (results || []).map(donorRowToApi) });
}
