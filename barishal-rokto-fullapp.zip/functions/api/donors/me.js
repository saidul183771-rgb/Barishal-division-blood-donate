import { json, fail, getSession, donorRowToApi } from '../../_lib/common.js';

export async function onRequestGet({ request, env }){
  const session = await getSession(request, env);
  if(!session) return fail('সেশন নেই', 401);
  const row = await env.DB.prepare('SELECT * FROM donors WHERE phone = ?').bind(session.phone).first();
  return json({ success: true, role: session.role, donor: row ? donorRowToApi(row) : null });
}
