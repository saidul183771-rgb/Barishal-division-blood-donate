import { json, fail, readJson, getSession, genId, writeAudit } from '../../_lib/common.js';

export async function onRequestPost({ request, env }){
  const session = await getSession(request, env);
  if(!session) return fail('আগে ফোন verify করুন', 401);

  const b = await readJson(request);
  if(!b.name || !b.blood || !b.district || !b.upazila){
    return fail('সব * চিহ্নিত ঘর পূরণ করুন');
  }

  const existing = await env.DB.prepare('SELECT id FROM donors WHERE phone = ?').bind(session.phone).first();
  const now = Date.now();

  if(existing){
    await env.DB.prepare(
      `UPDATE donors SET name=?, blood=?, district=?, upazila=?, age=?, weight=?, gender=?, emergency=?,
       last_donation=?, nid_number=COALESCE(?, nid_number), nid_photo=COALESCE(?, nid_photo),
       verified=0, nid_rejected=0, nid_reject_reason=NULL
       WHERE phone=?`
    ).bind(
      b.name, b.blood, b.district, b.upazila, b.age || null, b.weight || null, b.gender || null,
      b.emergency || 'yes', b.lastDonation || null, b.nidNumber || null, b.nidPhoto || null, session.phone
    ).run();
    await writeAudit(env, 'DONOR_UPDATED', session.phone, b.name);
    return json({ success: true, id: existing.id, status: 'updated' });
  }

  const id = genId('d');
  await env.DB.prepare(
    `INSERT INTO donors (id, phone, name, blood, district, upazila, age, weight, gender, emergency,
      last_donation, nid_number, nid_photo, verified, blood_verified, nid_rejected, suspended,
      donations, response_rate, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 0, ?)`
  ).bind(
    id, session.phone, b.name, b.blood, b.district, b.upazila, b.age || null, b.weight || null,
    b.gender || null, b.emergency || 'yes', b.lastDonation || null, b.nidNumber || null, b.nidPhoto || null, now
  ).run();
  await writeAudit(env, 'DONOR_REGISTERED', session.phone, b.name);
  return json({ success: true, id, status: 'created' });
}
